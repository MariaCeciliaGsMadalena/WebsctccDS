<?php
// Arquivo: save_appointment.php

// Habilita a exibição de todos os erros PHP para depuração.
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start(); // Inicia a sessão para acessar dados do usuário logado
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

header('Content-Type: application/json'); // Define o cabeçalho para indicar que a resposta é JSON

$response = ['success' => false, 'error' => ''];

// Verifica se a requisição foi feita via método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decodifica o JSON enviado no corpo da requisição
    $data = json_decode(file_get_contents('php://input'), true);

    // Validação e obtenção dos dados do agendamento
    // Garante que os IDs do paciente e do médico logado estejam disponíveis
    $id_paciente = $_SESSION['usuario']['id_paciente'] ?? null;
    $cpf_paciente = $_SESSION['usuario']['cpf'] ?? null;

    // Dados enviados do frontend via chatState
    $nome_paciente = $data['nome'] ?? null;
    $idade_paciente = $data['idade'] ?? null;
    $genero_paciente = $data['genero'] ?? null;
    $alergias = $data['alergias'] ?? null;
    $doenca_existente = $data['doenca_existente'] ?? null;
    $motivo_consulta = $data['motivo'] ?? null;
    $nivel_urgencia = $data['urgencia'] ?? null;
    $especialidades_desejadas = $data['especialidades'] ?? '[]'; // Já deve vir como JSON string
    $id_medico_agendado = $data['id_medico_agendado'] ?? null;
    $nome_medico_agendado = $data['nome_medico_agendado'] ?? null;
    $especialidade_medico_agendado = $data['especialidade_medico_agendado'] ?? null;
    $data_agendamento = $data['data_agendamento'] ?? null; // Formato YYYY-MM-DD HH:MM:SS

    // Validação básica dos campos obrigatórios
    if (
        !$id_paciente || !$cpf_paciente || !$nome_paciente || !$idade_paciente ||
        !$genero_paciente || !$motivo_consulta || !$nivel_urgencia ||
        !$data_agendamento
    ) {
        $response['error'] = 'Dados incompletos para agendar a consulta. Por favor, preencha todos os campos obrigatórios.';
        echo json_encode($response);
        exit;
    }

    // Gerar uma chave de consulta única
    $chave_consulta = 'CONSULTA_' . uniqid();

    try {
        // Obtém a conexão PDO
        $pdo = getPdoConnection();

        // Prepara a query SQL para inserção
        $sql = "INSERT INTO agendamentos (
                    id_paciente, cpf_paciente, id_medico_agendado, nome_medico_agendado,
                    especialidade_medico_agendado, data_agendamento, motivo_consulta,
                    nivel_urgencia, especialidades_desejadas, status_agendamento,
                    chave_consulta, nome_paciente, idade_paciente, genero_paciente,
                    alergias, doenca_existente
                ) VALUES (
                    :id_paciente, :cpf_paciente, :id_medico_agendado, :nome_medico_agendado,
                    :especialidade_medico_agendado, :data_agendamento, :motivo_consulta,
                    :nivel_urgencia, :especialidades_desejadas, 'Pendente',
                    :chave_consulta, :nome_paciente, :idade_paciente, :genero_paciente,
                    :alergias, :doenca_existente
                )";

        $stmt = $pdo->prepare($sql);

        // Binda os parâmetros
        $stmt->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
        $stmt->bindParam(':cpf_paciente', $cpf_paciente, PDO::PARAM_STR);
        $stmt->bindParam(':id_medico_agendado', $id_medico_agendado, PDO::PARAM_INT);
        $stmt->bindParam(':nome_medico_agendado', $nome_medico_agendado, PDO::PARAM_STR);
        $stmt->bindParam(':especialidade_medico_agendado', $especialidade_medico_agendado, PDO::PARAM_STR);
        $stmt->bindParam(':data_agendamento', $data_agendamento, PDO::PARAM_STR);
        $stmt->bindParam(':motivo_consulta', $motivo_consulta, PDO::PARAM_STR);
        $stmt->bindParam(':nivel_urgencia', $nivel_urgencia, PDO::PARAM_STR);
        $stmt->bindParam(':especialidades_desejadas', $especialidades_desejadas, PDO::PARAM_STR);
        $stmt->bindParam(':chave_consulta', $chave_consulta, PDO::PARAM_STR);
        $stmt->bindParam(':nome_paciente', $nome_paciente, PDO::PARAM_STR);
        $stmt->bindParam(':idade_paciente', $idade_paciente, PDO::PARAM_INT);
        $stmt->bindParam(':genero_paciente', $genero_paciente, PDO::PARAM_STR);
        $stmt->bindParam(':alergias', $alergias, PDO::PARAM_STR);
        $stmt->bindParam(':doenca_existente', $doenca_existente, PDO::PARAM_STR);

        // Executa a query
        $stmt->execute();

        $response['success'] = true;
        $response['message'] = 'Consulta agendada com sucesso!';
        $response['chave_consulta'] = $chave_consulta; // Retorna a chave gerada para o frontend

    } catch (PDOException $e) {
        // Captura e loga erros do PDO
        error_log("Erro PDO em save_appointment.php: " . $e->getMessage());
        $response['error'] = 'Erro de banco de dados: ' . $e->getMessage();
    } catch (Exception $e) {
        // Captura outros erros gerais
        error_log("Erro geral em save_appointment.php: " . $e->getMessage());
        $response['error'] = 'Erro interno do servidor: ' . $e->getMessage();
    }
} else {
    $response['error'] = 'Método de requisição inválido. Apenas requisições POST são permitidas.';
}

echo json_encode($response); // Retorna a resposta JSON
?>