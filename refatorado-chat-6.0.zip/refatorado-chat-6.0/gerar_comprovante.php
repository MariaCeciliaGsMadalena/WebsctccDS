<?php
require('fpdf.php');
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

// Função para limpar e sanitizar os dados
function limpar($dado) {
    return htmlspecialchars(trim($dado));
}

// Classe para o PDF personalizado
class ComprovantePDF extends FPDF {
    private $primaryColor = [0, 92, 175]; // Azul similar a passagens aéreas
    private $secondaryColor = [241, 241, 241]; // Cinza claro
    // Placeholder para a imagem da logo. Em um ambiente real, você usaria o caminho para sua imagem PNG.
    private $logoPath = 'AGILIXMEDTECH.png'; 

    // Construtor modificado para habilitar o suporte a UTF-8
    function __construct($orientation='P', $unit='mm', $size='A4') {
        parent::__construct($orientation, $unit, $size, true); // O 'true' habilita o suporte a UTF-8
        // Adiciona as fontes Arial com suporte a UTF-8.
        // Certifique-se de que os arquivos 'arial.ttf' e 'arialbd.ttf' estão no diretório 'font' da sua instalação FPDF.
        $this->AddFont('Arial', '', 'arial.ttf', true); 
        $this->AddFont('Arial', 'B', 'arialbd.ttf', true); 
    }

    function Header() {
        // Logo da empresa - ajustado para o estilo de passagem de ônibus
        // Posicionado no canto superior esquerdo
        $this->Image($this->logoPath, 10, 8, 30); // x, y, largura (altura será ajustada automaticamente)
        
        // Título principal do comprovante
        $this->SetFont('Arial', 'B', 16);
        $this->SetFillColor($this->primaryColor[0], $this->primaryColor[1], $this->primaryColor[2]);
        $this->SetTextColor(255);
        $this->Cell(0, 15, 'COMPROVANTE DE AGENDAMENTO', 0, 1, 'C', true);
        
        // Linha de informações superiores (data de emissão)
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(0);
        $this->Cell(0, 8, 'Emitido em: ' . date('d/m/Y H:i'), 0, 1, 'R'); // Move para a direita
        $this->Ln(5);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Documento gerado automaticamente em ' . $this->PageNo(), 0, 0, 'C');
    }
    
    function addSectionTitle($title) {
        $this->SetFillColor($this->secondaryColor[0], $this->secondaryColor[1], $this->secondaryColor[2]);
        $this->SetTextColor($this->primaryColor[0], $this->primaryColor[1], $this->primaryColor[2]);
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, $title, 0, 1, 'L', true);
        $this->SetTextColor(0);
    }
    
    function addInfoRow($label, $value, $icon = '') {
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(40, 8, $icon . ' ' . $label, 0, 0);
        $this->SetFont('Arial', '', 10); // Garante que a fonte normal seja UTF-8
        $this->Cell(0, 8, $value, 0, 1);
    }
    
    function addBarcode($code) {
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor($this->primaryColor[0], $this->primaryColor[1], $this->primaryColor[2]);
        $this->Cell(0, 10, 'CODIGO DO AGENDAMENTO', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 24);
        $this->Cell(0, 15, $code, 0, 1, 'C');
        
        // Simulação de código de barras (simples)
        $this->SetFillColor(0);
        for($i=0; $i<20; $i++) {
            $height = rand(5, 15);
            $this->Rect(50 + ($i*5), $this->GetY(), 3, $height, 'F');
        }
        $this->Ln(20);
    }
    
    function addSpecialties($especialidades) {
        $this->addSectionTitle('ESPECIALIDADES SELECIONADAS'); // Título mais genérico
        
        if(empty($especialidades) || $especialidades == '[]') { // Verifica se está vazio ou é JSON vazio
            $this->SetFont('Arial', 'I', 10); // Garante que a fonte itálica seja UTF-8
            $this->Cell(0, 8, 'Nenhuma especialidade selecionada', 0, 1);
            $this->SetFont('Arial', '', 10); // Volta para a fonte normal UTF-8
        } else {
            // Decodifica a string JSON de especialidades
            $especialidades_array = json_decode($especialidades, true);
            if (is_array($especialidades_array)) {
                foreach($especialidades_array as $esp) {
                    $this->Cell(5, 8, '', 0, 0);
                    $this->SetFont('Arial', '', 10); // Garante que a fonte seja UTF-8
                    $this->Cell(0, 8, '• ' . $esp, 0, 1);
                }
            } else {
                $this->SetFont('Arial', 'I', 10); // Garante que a fonte itálica seja UTF-8
                $this->Cell(0, 8, 'Formato de especialidades inválido', 0, 1);
                $this->SetFont('Arial', '', 10); // Volta para a fonte normal UTF-8
            }
        }
    }
}

// Verifica se a chave de consulta foi passada via GET
if (isset($_GET['chave_consulta']) && !empty($_GET['chave_consulta'])) {
    $chave_consulta = limpar($_GET['chave_consulta']);

    try {
        $pdo = getPdoConnection(); // Obtém a conexão PDO

        // Busca os dados do agendamento no banco de dados
        $sql = "SELECT ag.nome_completo, ag.idade, ag.cpf, ag.data_nascimento, ag.motivo_consulta, ag.nivel_urgencia, ag.especialidades_selecionadas, ag.data_agendamento, m.nome AS nome_medico_agendado
                FROM agendamentos ag
                LEFT JOIN medicos m ON ag.id_medico_agendado = m.id_medico
                WHERE ag.chave_consulta = :chave_consulta";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':chave_consulta', $chave_consulta);
        $stmt->execute();
        $agendamento = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($agendamento) {
            // Dados do agendamento
            $nome_completo = $agendamento['nome_completo'];
            $idade = $agendamento['idade'];
            $cpf = $agendamento['cpf'];
            $data_nascimento = $agendamento['data_nascimento'];
            $motivo = $agendamento['motivo_consulta'];
            $urgencia = $agendamento['nivel_urgencia'];
            $especialidades = $agendamento['especialidades_selecionadas']; // Já é uma string JSON
            $data_agendamento = $agendamento['data_agendamento'];
            $nome_medico_agendado = $agendamento['nome_medico_agendado'];

            // Criar PDF
            $pdf = new ComprovantePDF();
            $pdf->AddPage();

            // Seção de informações do paciente
            $pdf->addSectionTitle('DADOS DO PACIENTE');
            $pdf->addInfoRow('Nome completo', $nome_completo, '');
            $pdf->addInfoRow('Idade', $idade . ' anos', '');
            $pdf->addInfoRow('CPF', $cpf, '');
            $pdf->addInfoRow('Data de Nascimento', date('d/m/Y', strtotime($data_nascimento)), '');
            $pdf->addInfoRow('Motivo da Consulta', $motivo, '');
            $pdf->addInfoRow('Nível de Urgência', $urgencia, '');
            if ($nome_medico_agendado) {
                $pdf->addInfoRow('Médico Agendado', $nome_medico_agendado, '');
            }
            $pdf->addInfoRow('Data do Agendamento', date('d/m/Y H:i', strtotime($data_agendamento)), '');


            // Seção de especialidades
            $pdf->addSpecialties($especialidades);

            // Código de confirmação
            $pdf->addBarcode($chave_consulta); // Usa a chave real do banco de dados

            // Notas importantes
            $pdf->addSectionTitle('INFORMAÇÕES IMPORTANTES');
            $pdf->SetFont('Arial', '', 10); // Define a fonte Arial com suporte a UTF-8
            $pdf->MultiCell(0, 6, " Apresente este comprovante no dia da consulta\n Chegue com 15 minutos de antecedência\n Em caso de desistência, favor cancelar com 24h de antecedência\nTrazer documentos originais e exames anteriores, se houver");
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'I', 10); // Define a fonte Arial Itálico com suporte a UTF-8
            $pdf->Cell(0, 6, 'Agradecemos sua preferência!', 0, 1, 'C');

            // Saída do PDF
            $pdf->Output('I', 'comprovante_agendamento_' . $chave_consulta . '.pdf');
        } else {
            // Agendamento não encontrado
            header('Location: index.html?error=agendamento_nao_encontrado');
            exit;
        }

    } catch (PDOException $e) {
        error_log("Erro de PDO em gerar_comprovante.php: " . $e->getMessage());
        header('Location: index.html?error=db_error');
        exit;
    } catch (Exception $e) {
        error_log("Erro geral em gerar_comprovante.php: " . $e->getMessage());
        header('Location: index.html?error=general_error');
        exit;
    }

} else {
    // Redirecionar se acessado diretamente sem chave de consulta
    header('Location: index.html?error=chave_nao_fornecida');
    exit;
}
?>