-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 03-Ago-2025 às 00:59
-- Versão do servidor: 5.7.36
-- versão do PHP: 8.0.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agilixmdtechbd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agendamentos`
--

CREATE TABLE `agendamentos` (
  `id_agendamento` int(11) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `cpf_paciente` varchar(14) NOT NULL,
  `id_medico_agendado` int(11) DEFAULT NULL,
  `nome_medico_agendado` varchar(255) DEFAULT NULL,
  `especialidade_medico_agendado` varchar(100) DEFAULT NULL,
  `data_agendamento` datetime NOT NULL,
  `motivo_consulta` text,
  `nivel_urgencia` varchar(50) DEFAULT NULL,
  `especialidades_desejadas` text,
  `status_agendamento` enum('Pendente','Confirmado','Cancelado','Realizado') NOT NULL DEFAULT 'Pendente',
  `chave_consulta` varchar(255) NOT NULL,
  `data_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nome_paciente` varchar(255) DEFAULT NULL,
  `idade_paciente` int(11) DEFAULT NULL,
  `genero_paciente` enum('Masculino','Feminino','Outro') DEFAULT NULL,
  `alergias` text,
  `doenca_existente` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `atestados_medicos`
--

CREATE TABLE `atestados_medicos` (
  `id_atestado` int(11) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `data_emissao` date NOT NULL,
  `data_inicio_afastamento` date NOT NULL,
  `dias_afastamento` int(11) NOT NULL,
  `diagnostico` text NOT NULL,
  `cid` varchar(10) DEFAULT NULL,
  `observacoes` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `chat_mensagens`
--

CREATE TABLE `chat_mensagens` (
  `id_mensagem` int(11) NOT NULL,
  `id_remetente` int(11) NOT NULL COMMENT 'ID do remetente (medico ou estabelecimento_exame)',
  `tipo_remetente` enum('medico','estabelecimento_exame') NOT NULL,
  `id_destinatario` int(11) NOT NULL COMMENT 'ID do destinatário (medico ou estabelecimento_exame)',
  `tipo_destinatario` enum('medico','estabelecimento_exame') NOT NULL,
  `mensagem` text,
  `data_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lida` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `horarios_atendimento_medico`
--

CREATE TABLE `horarios_atendimento_medico` (
  `id_horario` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `dia_semana` varchar(20) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `em_almoco` tinyint(1) DEFAULT '0',
  `indisponivel_temporariamente` tinyint(1) DEFAULT '0',
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `horarios_data_especifica`
--

CREATE TABLE `horarios_data_especifica` (
  `id_horario_data` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `data_atendimento` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `em_almoco` tinyint(1) DEFAULT '0',
  `indisponivel_temporariamente` tinyint(1) DEFAULT '0',
  `observacao` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `horarios_data_especifica`
--

INSERT INTO `horarios_data_especifica` (`id_horario_data`, `id_medico`, `data_atendimento`, `hora_inicio`, `hora_fim`, `em_almoco`, `indisponivel_temporariamente`, `observacao`) VALUES
(1, 6, '2025-08-02', '09:00:00', '12:00:00', 0, 0, ''),
(2, 2, '2025-08-09', '10:00:00', '18:00:00', 0, 0, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicos`
--

CREATE TABLE `medicos` (
  `id_medico` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `cnpj` varchar(18) NOT NULL,
  `genero` enum('Masculino','Feminino','Outro') DEFAULT 'Outro',
  `crm` varchar(20) NOT NULL,
  `especialidade` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `medicos`
--

INSERT INTO `medicos` (`id_medico`, `nome`, `cpf`, `cnpj`, `genero`, `crm`, `especialidade`, `email`, `senha`, `cidade`, `data_cadastro`) VALUES
(1, 'Eduardo Lira Amorim', '123.456.789-01', '12.345.678/0001-01', 'Masculino', 'SP123456', 'Cardiologia', 'eduardo.amorim@agilixmed.com', 'senha123', 'Batatais', '2025-07-12 23:44:05'),
(2, 'Caio de Souza Anhezini', '234.567.890-12', '23.456.789/0001-02', 'Masculino', 'SP789012', 'Oftalmologia', 'caio.anhezini@agilixmed.com', 'senha123', 'Batatais', '2025-07-12 23:44:05'),
(3, 'JOAO PEDRO CUSTODIO', '345.678.901-23', '34.567.890/0001-03', 'Masculino', 'SP345678', 'Urologista', 'joao.custodio@agilixmed.com', 'senha123', 'Batatais', '2025-07-12 23:44:05'),
(4, 'KAIO GALATTI LIBANORE', '456.789.012-34', '45.678.901/0001-04', 'Masculino', 'SP901234', 'Ortopedia', 'kaio.libanore@agilixmed.com', 'senha123', 'Batatais', '2025-07-12 23:44:05'),
(5, 'JOÃO VICTOR DA SILVA', '567.890.123-45', '56.789.012/0001-05', 'Masculino', 'SP567890', 'Clínica geral', 'joao.silva@agilixmed.com', 'senha123', 'Batatais', '2025-07-12 23:44:05'),
(6, 'MARIA CECILIA GOMES DA SILVA MADALENA', '678.901.234-56', '67.890.123/0001-06', 'Feminino', 'SP234567', 'Ginecologia', 'maria.madalena@agilixmed.com', 'senha123', 'Ribeirão Preto', '2025-07-12 23:44:05');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id_mensagem` int(11) NOT NULL,
  `id_remetente` int(11) NOT NULL,
  `id_destinatario` int(11) NOT NULL,
  `tipo_remetente` varchar(10) NOT NULL COMMENT 'medico ou paciente',
  `tipo_destinatario` varchar(10) NOT NULL COMMENT 'medico ou paciente',
  `mensagem` text NOT NULL,
  `data_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_leitura` int(1) DEFAULT '0' COMMENT '0=nao lida, 1=lida'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mensagens`
--

INSERT INTO `mensagens` (`id_mensagem`, `id_remetente`, `id_destinatario`, `tipo_remetente`, `tipo_destinatario`, `mensagem`, `data_envio`, `status_leitura`) VALUES
(7, 1, 6, 'paciente', 'medico', 'a', '2025-08-02 19:09:32', 1),
(8, 1, 6, 'paciente', 'medico', 'oi', '2025-08-02 20:02:32', 1),
(9, 1, 6, 'paciente', 'medico', 'vou cagar', '2025-08-02 20:04:35', 1),
(10, 1, 6, 'paciente', 'medico', 'Olá Dr(a). MARIA CECILIA GOMES DA SILVA MADALENA, gostaria de verificar a disponibilidade para uma consulta em 08/08/2025 às 09:00.', '2025-08-02 20:31:00', 1),
(11, 6, 1, 'medico', 'paciente', 'ta disponsivel', '2025-08-02 20:32:37', 0),
(12, 6, 1, 'medico', 'paciente', 'a', '2025-08-02 20:50:33', 0),
(13, 6, 4, 'medico', 'paciente', 'aa', '2025-08-02 21:41:20', 0),
(14, 3, 6, 'paciente', 'medico', 'aaa', '2025-08-02 22:11:42', 1),
(15, 3, 2, 'paciente', 'medico', 'Olá Dr(a). Caio de Souza Anhezini, gostaria de verificar a disponibilidade para uma consulta em 09/08/2025 às 07:25.', '2025-08-02 23:11:13', 1),
(16, 2, 3, 'medico', 'paciente', 'nao vou pode ter te atender esse horario', '2025-08-02 23:23:41', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pacientes`
--

CREATE TABLE `pacientes` (
  `id_paciente` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `data_nascimento` date NOT NULL,
  `genero` enum('Masculino','Feminino','Outro') DEFAULT 'Outro',
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(255) NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comorbidade` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `alergia` text,
  `chave_recuperacao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pacientes`
--

INSERT INTO `pacientes` (`id_paciente`, `nome`, `cpf`, `data_nascimento`, `genero`, `telefone`, `email`, `senha`, `data_cadastro`, `comorbidade`, `cidade`, `alergia`, `chave_recuperacao`) VALUES
(1, 'Lucas Martins', '111.222.333-44', '1990-03-10', 'Masculino', '(16) 91234-5678', 'lucas.martins@gmail.com', 'senha123', '2025-08-02 21:16:07', 'Hipertensão', 'Ribeirão Preto', 'Dipirona', NULL),
(2, 'Mariana Oliveira', '555.666.777-88', '1995-07-25', 'Feminino', '(16) 92345-6789', 'mariana.oliveira@gmail.com', 'senha456', '2025-08-02 21:16:07', 'Asma', 'Batatais', 'Amoxicilina', NULL),
(3, 'Carlos Eduardo', '999.000.111-22', '1988-11-30', 'Masculino', '(16) 93456-7890', 'carlos.edu@gmail.com', 'senha789', '2025-08-02 21:16:07', '', 'Brodowski', 'Nenhuma', NULL),
(4, 'Aline Souza', '333.444.555-66', '2001-01-15', 'Feminino', '(16) 94567-8901', 'aline.souza@gmail.com', 'senhaabc', '2025-08-02 21:16:07', 'Diabetes tipo 2', 'Jardinópolis', 'Insulina', NULL),
(5, 'Fernanda Lima', '777.888.999-00', '1992-06-05', 'Feminino', '(16) 95678-9012', 'fernanda.lima@gmail.com', 'senhadef', '2025-08-02 21:16:07', '', 'Franca', 'Glúten', NULL),
(8, 'Maria Cecilia Gomes da Silva Madalena', '45974615824', '2007-08-02', 'Feminino', NULL, 'mcgsmadalena0123@gmail.com', 'senha123', '2025-08-02 22:00:22', 'cu', 'Jardinópolis', 'cu', 'LJrDC24k');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pre_consultas`
--

CREATE TABLE `pre_consultas` (
  `id_pre_consulta` int(11) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `data_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `queixa_principal` text,
  `tempo_queixa` varchar(255) DEFAULT NULL,
  `medicamentos_alergias` text,
  `historico_doencas_cirurgias_familia` text,
  `sintomas_atuais_detalhes` text,
  `rotina_estilo_vida` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pre_consultas`
--

INSERT INTO `pre_consultas` (`id_pre_consulta`, `id_paciente`, `data_envio`, `queixa_principal`, `tempo_queixa`, `medicamentos_alergias`, `historico_doencas_cirurgias_familia`, `sintomas_atuais_detalhes`, `rotina_estilo_vida`) VALUES
(1, 1, '2025-08-02 03:23:52', 'a', 's', 'a', 'a', 'a', 'a'),
(2, 1, '2025-08-02 03:29:56', 'dores menstruais fortes,corrimento vermelho grande', '2 meses', 'uso valeato de estaridol e tenho alergia a tramadol', 'ja tive cancer no endometrio ,sim ja faz dois anos.', 'dor muito perto do utero e dores de cabeça fortes e isso começou do nada', 'durmo mal'),
(3, 1, '2025-08-02 03:48:31', 's', 's', 's', 's', 's', 's'),
(4, 1, '2025-08-02 03:58:56', 'aa', 'a', 'aa', 'aa', 'a', 'aa'),
(5, 1, '2025-08-02 12:49:37', 'nao', 'nao', 'nao', 'nao', 'nao', 'nao'),
(6, 1, '2025-08-02 13:03:58', 'nao', 'nao', 'nao', 'nao', 'nao', 'nao'),
(7, 1, '2025-08-02 15:12:25', 'sim', 'sim', 'sim', 'sim', 'sim', 'sim'),
(8, 1, '2025-08-02 15:27:38', 'nao', 'nao', 'nao', 'nao', 'nao', 'nao'),
(9, 1, '2025-08-02 15:33:34', 'sim', 'sim', 'sim', 'sim', 'sim', 'sim'),
(10, 1, '2025-08-02 15:41:39', 'nao', 'nao', 'sim', 'sim', 'teste', 'teste'),
(11, 1, '2025-08-02 20:30:19', 'sim', 'sim', 'sim', 'sim', 'sim', 'sim'),
(12, 3, '2025-08-02 22:32:44', 'dor nos olhos', '20 dias', 'nao', 'tive que colocar lente', 'dor nos olhos forte e dor de cabeça e começou do nada', 'como mal'),
(13, 3, '2025-08-02 22:44:45', 'dor forte nos olhos,dor de cabeça muito forte e muita tontura', '3 meses', 'nao', 'tirei o rim', 'dor forte no rosto,ainda continua dor forte nos olhos,dor de cabeça muito forte e muita tontura e cada vez piora', 'dorme mal,come mal,nao faz academia'),
(14, 3, '2025-08-02 23:01:14', 'dor forte nos olhos e faz uma semana', 'uma semana', 'nao', 'nao', 'dor fortes nos olhos e tontura e isso piorou', 'como mal'),
(15, 3, '2025-08-02 23:06:11', 'dor nos olhos', 'Duas semanas', 'nao', 'nao', 'dor nos olhos e dor de cabeça,pioram', 'dorme mal'),
(16, 3, '2025-08-02 23:10:16', 'dor nos olhos e ha duas semanas que apareceu', 'duas semanas', 'nao', 'nao', 'dor nos olhos e dor de cabeça e piorou', 'dorme mal e nao come bem');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD PRIMARY KEY (`id_agendamento`),
  ADD UNIQUE KEY `chave_consulta` (`chave_consulta`),
  ADD KEY `fk_agendamentos_paciente` (`id_paciente`),
  ADD KEY `fk_agendamentos_medico` (`id_medico_agendado`);

--
-- Índices para tabela `atestados_medicos`
--
ALTER TABLE `atestados_medicos`
  ADD PRIMARY KEY (`id_atestado`),
  ADD KEY `id_paciente` (`id_paciente`),
  ADD KEY `id_medico` (`id_medico`);

--
-- Índices para tabela `chat_mensagens`
--
ALTER TABLE `chat_mensagens`
  ADD PRIMARY KEY (`id_mensagem`),
  ADD KEY `id_remetente` (`id_remetente`),
  ADD KEY `id_destinatario` (`id_destinatario`);

--
-- Índices para tabela `horarios_atendimento_medico`
--
ALTER TABLE `horarios_atendimento_medico`
  ADD PRIMARY KEY (`id_horario`),
  ADD KEY `id_medico` (`id_medico`);

--
-- Índices para tabela `horarios_data_especifica`
--
ALTER TABLE `horarios_data_especifica`
  ADD PRIMARY KEY (`id_horario_data`),
  ADD KEY `fk_horarios_data_especifica_medico` (`id_medico`);

--
-- Índices para tabela `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`id_medico`),
  ADD UNIQUE KEY `cpf` (`cpf`),
  ADD UNIQUE KEY `cnpj` (`cnpj`),
  ADD UNIQUE KEY `crm` (`crm`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id_mensagem`);

--
-- Índices para tabela `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`id_paciente`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Índices para tabela `pre_consultas`
--
ALTER TABLE `pre_consultas`
  ADD PRIMARY KEY (`id_pre_consulta`),
  ADD KEY `fk_pre_consultas_paciente` (`id_paciente`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  MODIFY `id_agendamento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `atestados_medicos`
--
ALTER TABLE `atestados_medicos`
  MODIFY `id_atestado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `chat_mensagens`
--
ALTER TABLE `chat_mensagens`
  MODIFY `id_mensagem` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `horarios_atendimento_medico`
--
ALTER TABLE `horarios_atendimento_medico`
  MODIFY `id_horario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `horarios_data_especifica`
--
ALTER TABLE `horarios_data_especifica`
  MODIFY `id_horario_data` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `medicos`
--
ALTER TABLE `medicos`
  MODIFY `id_medico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id_mensagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `id_paciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `pre_consultas`
--
ALTER TABLE `pre_consultas`
  MODIFY `id_pre_consulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD CONSTRAINT `fk_agendamentos_medico` FOREIGN KEY (`id_medico_agendado`) REFERENCES `medicos` (`id_medico`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_agendamentos_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`id_paciente`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `atestados_medicos`
--
ALTER TABLE `atestados_medicos`
  ADD CONSTRAINT `atestados_medicos_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`id_paciente`) ON DELETE CASCADE,
  ADD CONSTRAINT `atestados_medicos_ibfk_2` FOREIGN KEY (`id_medico`) REFERENCES `medicos` (`id_medico`);

--
-- Limitadores para a tabela `horarios_atendimento_medico`
--
ALTER TABLE `horarios_atendimento_medico`
  ADD CONSTRAINT `horarios_atendimento_medico_ibfk_1` FOREIGN KEY (`id_medico`) REFERENCES `medicos` (`id_medico`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `horarios_data_especifica`
--
ALTER TABLE `horarios_data_especifica`
  ADD CONSTRAINT `fk_horarios_data_especifica_medico` FOREIGN KEY (`id_medico`) REFERENCES `medicos` (`id_medico`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `pre_consultas`
--
ALTER TABLE `pre_consultas`
  ADD CONSTRAINT `fk_pre_consultas_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`id_paciente`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
