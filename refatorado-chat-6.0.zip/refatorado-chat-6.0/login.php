<?php
session_start();
include_once 'conexao.php'; // Inclui o arquivo de conexão

$erro = false;
$cadastro_sucesso = false;
$mensagem_erro = '';
$conn = null; // Inicializa $conn como null
$recovery_password_success = false;
$new_generated_password = '';

try {
    // Tenta obter a conexão PDO. Esta é a correção principal.
    $conn = getPdoConnection();
} catch (Exception $e) {
    // Se houver um erro na conexão, define a mensagem de erro e impede o processamento do formulário.
    $erro = true;
    $mensagem_erro = 'Erro crítico ao conectar ao banco de dados: ' . $e->getMessage();
    error_log("Erro crítico de conexão em login.php: " . $e->getMessage());
}

if (!$erro && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'login') {
            $email = $_POST['email'];
            $senha = $_POST['senha'];
            $tipo  = $_POST['tipo'];

            // Validação PHP para campos de login vazios (caso o required do HTML falhe ou seja burlado)
            if (empty($email) || empty($senha)) {
                $erro = true;
                $mensagem_erro = 'Por favor, preencha o email e a senha para fazer login.';
            } else {
                try {
                    if ($tipo === 'paciente') {
                        $stmt = $conn->prepare("SELECT * FROM pacientes WHERE email = :email AND senha = :senha");
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':senha', $senha);
                        $stmt->execute();

                        if ($stmt->rowCount() > 0) {
                            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                            $_SESSION['usuario'] = $usuario;
                            $_SESSION['tipo_usuario'] = 'paciente';
                            header("Location: acesspacdata.php");
                            exit();
                        } else {
                            $erro = true;
                            $mensagem_erro = 'Email ou senha incorretos para Paciente.';
                        }
                    } elseif ($tipo === 'medico') {
                        $stmt = $conn->prepare("SELECT * FROM medicos WHERE email = :email AND senha = :senha");
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':senha', $senha);
                        $stmt->execute();

                        if ($stmt->rowCount() > 0) {
                            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                            $_SESSION['usuario'] = $usuario;
                            $_SESSION['tipo_usuario'] = 'medico';
                            header("Location: acessmedicdata.php");
                            exit();
                        } else {
                            $erro = true;
                            $mensagem_erro = 'Email ou senha incorretos para Médico.';
                        }
                    }
                    // A lógica para 'exame' não está incluída, conforme sua solicitação.
                } catch (PDOException $e) {
                    $erro = true;
                    $mensagem_erro = 'Erro no servidor. Tente novamente mais tarde.';
                    error_log("Erro de login: " . $e->getMessage());
                }
            }
        } elseif ($_POST['action'] === 'cadastro_paciente') {
            // Campos para cadastro de paciente
            $nome_paciente = $_POST['nome_paciente'];
            $email_paciente = $_POST['email_paciente'];
            $senha_paciente = $_POST['senha_paciente'];
            $cpf_paciente = $_POST['cpf_paciente'];
            $data_nascimento_paciente = $_POST['data_nascimento_paciente'];
            $genero_paciente = $_POST['genero_paciente'];
            $comorbidade_paciente = isset($_POST['comorbidade_paciente']) ? $_POST['comorbidade_paciente'] : null;
            $alergia_paciente = isset($_POST['alergia_paciente']) ? $_POST['alergia_paciente'] : null;
            
            // O endereço é um único campo 'cidade_uf'
            $cidade_uf_paciente = isset($_POST['cidade_uf']) ? $_POST['cidade_uf'] : '';

            $aceite_privacidade = isset($_POST['aceite_privacidade']);

            // Validação PHP: Formato do CPF e aceite da política de privacidade
            if (!preg_match('/^\d{11}$/', $cpf_paciente)) {
                echo json_encode(['success' => false, 'message' => 'CPF inválido. Digite apenas 11 números.', 'field' => 'cpf_paciente']);
                exit();
            } elseif (!$aceite_privacidade) {
                echo json_encode(['success' => false, 'message' => 'Você deve aceitar a política de privacidade para se cadastrar.', 'field' => 'aceite_privacidade']);
                exit();
            } else {
                try {
                    // Verificar se o CPF já existe
                    $stmt_check_cpf = $conn->prepare("SELECT COUNT(*) FROM pacientes WHERE cpf = :cpf");
                    $stmt_check_cpf->bindParam(':cpf', $cpf_paciente);
                    $stmt_check_cpf->execute();
                    if ($stmt_check_cpf->fetchColumn() > 0) {
                        echo json_encode(['success' => false, 'message' => 'CPF já cadastrado.', 'field' => 'cpf_paciente']);
                        exit();
                    }

                    // Verificar se o email já existe
                    $stmt_check_email = $conn->prepare("SELECT COUNT(*) FROM pacientes WHERE email = :email");
                    $stmt_check_email->bindParam(':email', $email_paciente);
                    $stmt_check_email->execute();
                    if ($stmt_check_email->fetchColumn() > 0) {
                        echo json_encode(['success' => false, 'message' => 'Email já cadastrado.', 'field' => 'email_paciente']);
                        exit();
                    }

                    if (!$erro) {
                        // ATENÇÃO: EM PRODUÇÃO, SEMPRE FAÇA HASH DA SENHA!
                        // Exemplo: $senha_hash = password_hash($senha_paciente, PASSWORD_DEFAULT);

                        // Gerar chave de recuperação de 8 dígitos
                        $chave_recuperacao = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

                        // Atualiza a query de INSERT para incluir 'comorbidade', 'alergia' e 'cidade'
                        $stmt = $conn->prepare("INSERT INTO pacientes (nome, cpf, data_nascimento, genero, comorbidade, alergia, email, senha, cidade, chave_recuperacao) VALUES (:nome, :cpf, :data_nascimento, :genero, :comorbidade, :alergia, :email, :senha, :cidade, :chave_recuperacao)");
                        $stmt->bindParam(':nome', $nome_paciente);
                        $stmt->bindParam(':cpf', $cpf_paciente);
                        $stmt->bindParam(':data_nascimento', $data_nascimento_paciente);
                        $stmt->bindParam(':genero', $genero_paciente);
                        $stmt->bindParam(':comorbidade', $comorbidade_paciente);
                        $stmt->bindParam(':alergia', $alergia_paciente);
                        $stmt->bindParam(':email', $email_paciente);
                        $stmt->bindParam(':senha', $senha_paciente); // Mudar para $senha_hash em produção
                        $stmt->bindParam(':cidade', $cidade_uf_paciente); // Bind para a coluna 'cidade'
                        $stmt->bindParam(':chave_recuperacao', $chave_recuperacao);
                        $stmt->execute();
                        
                        echo json_encode(['success' => true, 'message' => 'Cadastro realizado com sucesso!', 'recovery_key' => $chave_recuperacao]);
                        exit();
                    }
                } catch (PDOException $e) {
                    echo json_encode(['success' => false, 'message' => 'Erro ao cadastrar. Tente novamente.']);
                    error_log("Erro de cadastro: " . $e->getMessage());
                    exit();
                }
            }
        } elseif ($_POST['action'] === 'recover_password') {
            $email_recovery = $_POST['email_recovery'];
            $recovery_key = $_POST['recovery_key'];

            try {
                // Check if email and recovery key match for a patient
                $stmt = $conn->prepare("SELECT * FROM pacientes WHERE email = :email AND chave_recuperacao = :chave_recuperacao");
                $stmt->bindParam(':email', $email_recovery);
                $stmt->bindParam(':chave_recuperacao', $recovery_key);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {
                    // Generate a new random password (for demonstration purposes)
                    $new_password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
                    // In a real application, you would hash this password:
                    // $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    // Update the patient's password
                    $update_stmt = $conn->prepare("UPDATE pacientes SET senha = :new_password WHERE email = :email");
                    $update_stmt->bindParam(':new_password', $new_password); // Use $new_password_hash in production
                    $update_stmt->bindParam(':email', $email_recovery);
                    $update_stmt->execute();

                    $recovery_password_success = true;
                    $new_generated_password = $new_password; // Display the new password for demo
                    echo json_encode(['success' => true, 'message' => 'Sua nova senha é: ' . $new_password . '. Por favor, faça login com a nova senha e altere-a em seguida.', 'new_password' => $new_password]);
                    exit();
                } else {
                    echo json_encode(['success' => false, 'message' => 'Email ou chave de recuperação incorretos.']);
                    exit();
                }
            } catch (PDOException $e) {
                error_log("Erro na recuperação de senha: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Erro no servidor ao recuperar a senha. Tente novamente mais tarde.']);
                exit();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - AgilixMedtech</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<div class="container d-flex flex-grow-1 align-items-center justify-content-center py-4">
    <div class="card shadow-lg p-4 p-md-5 w-100" style="max-width: 450px;">
        <div class="text-center mb-4">
            <h1 class="h4 card-title text-primary">Login</h1>
        </div>

        <?php if ($erro): ?>
            <div class="alert alert-danger text-center" role="alert">
                <?php echo htmlspecialchars($mensagem_erro); ?>
            </div>
        <?php endif; ?>
        
        <div class="d-flex justify-content-center mb-4 gap-2">
            <button type="button" onclick="showLoginType('paciente')" class="btn btn-primary active" id="btn-paciente">Paciente</button>
            <button type="button" onclick="showLoginType('medico')" class="btn btn-success" id="btn-medico">Médico</button>
            <!-- O botão para 'Exame' foi removido, conforme sua solicitação. -->
        </div>

        <div id="paciente-login" class="login-form">
            <h2 class="h6 text-center text-primary mb-3">Login Paciente</h2>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="paciente">
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email" required autocomplete="off">
                    <div class="invalid-feedback">
                        Por favor, insira um email válido.
                    </div>
                </div>
                <div class="mb-3">
                    <input type="password" name="senha" class="form-control" placeholder="Senha" required autocomplete="off">
                    <div class="invalid-feedback">
                        Por favor, insira sua senha.
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Entrar</button>
            </form>
            <p class="text-center mt-3 mb-0">Não tem uma conta? <a href="#" onclick="openCadastroModal(); return false;" class="text-primary fw-bold text-decoration-none">Cadastre-se</a></p>
        </div>

        <div id="medico-login" class="login-form d-none">
            <h2 class="h6 text-center text-success mb-3">Login Médico</h2>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="medico">
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email Profissional" required autocomplete="off">
                    <div class="invalid-feedback">
                        Por favor, insira um email válido.
                    </div>
                </div>
                <div class="mb-3">
                    <input type="password" name="senha" class="form-control" placeholder="Senha" required autocomplete="off">
                    <div class="invalid-feedback">
                        Por favor, insira sua senha.
                    </div>
                </div>
                <button type="submit" class="btn btn-success w-100">Entrar</button>
            </form>
            <p class="text-center mt-3 mb-0">Não tem uma conta? <a href="#" onclick="openCadastroModal(); return false;" class="text-primary fw-bold text-decoration-none">Cadastre-se</a></p>
        </div>

        <!-- O formulário de login para 'Exame' foi removido, conforme sua solicitação. -->

        <div class="text-center mt-4">
            <a href="#" onclick="openRecoveryModal(); return false;" class="text-primary text-decoration-none">Esqueceu a senha?</a>
        </div>
    </div>
</div>

<!-- Modal de Erro -->
<div class="modal fade" id="modalErro" tabindex="-1" aria-labelledby="modalErroLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalErroLabel">😢 Não foi sua culpa, tente novamente!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body text-danger fw-bold">
                <p id="modalErroMensagem"></p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Cadastro de Paciente -->
<div class="modal fade" id="modalCadastroPaciente" tabindex="-1" aria-labelledby="modalCadastroPacienteLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalCadastroPacienteLabel">Cadastre-se como Paciente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form id="formCadastroPaciente" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="cadastro_paciente">
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <input type="text" name="nome_paciente" class="form-control" placeholder="Nome Completo" required>
                            <div class="invalid-feedback">
                                Por favor, insira seu nome completo.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <input type="email" name="email_paciente" class="form-control" placeholder="Email" required autocomplete="off">
                            <div class="invalid-feedback">
                                Por favor, insira um email válido.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <input type="password" name="senha_paciente" class="form-control" placeholder="Senha" required autocomplete="off">
                            <div class="invalid-feedback">
                                Por favor, insira sua senha.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="cpf_paciente" class="form-control" placeholder="CPF (somente números)" required pattern="\d{11}" title="Digite apenas 11 números para o CPF">
                            <div class="invalid-feedback">
                                Por favor, insira um CPF válido (11 números).
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="data_nascimento_paciente" class="form-label visually-hidden">Data de Nascimento</label>
                            <input type="date" name="data_nascimento_paciente" id="data_nascimento_paciente" class="form-control" required>
                            <div class="invalid-feedback">
                                Por favor, insira sua data de nascimento.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <select name="genero_paciente" class="form-select" required>
                                <option value="">Gênero</option>
                                <option value="Masculino">Masculino</option>
                                <option value="Feminino">Feminino</option>
                                <option value="Outro">Outro</option>
                            </select>
                            <div class="invalid-feedback">
                                Por favor, selecione seu gênero.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="comorbidade_paciente" class="form-control" placeholder="Comorbidade (Opcional)">
                        </div>
                        
                        <!-- Novo campo para Alergia -->
                        <div class="col-12">
                            <input type="text" name="alergia_paciente" class="form-control" placeholder="Alergia (Opcional)">
                        </div>

                        <!-- Campo único para Cidade (UF) -->
                        <div class="col-12">
                            <label for="cidade_uf" class="form-label">Cidade (UF)</label>
                            <input type="text" name="cidade_uf" id="cidade_uf" class="form-control" placeholder="Ex: São Paulo (SP)" required>
                            <div class="invalid-feedback">
                                Por favor, insira a cidade e o estado (UF).
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="aceite_privacidade" id="aceite_privacidade" required>
                                <label class="form-check-label" for="aceite_privacidade">
                                    Li e aceito a Política de Privacidade
                                </label>
                                <div class="invalid-feedback">
                                    Você deve aceitar a política de privacidade.
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary w-50">Cadastrar</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Cadastro Sucesso -->
<div class="modal fade" id="modalCadastroSucesso" tabindex="-1" aria-labelledby="modalCadastroSucessoLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalCadastroSucessoLabel">🎉 Cadastro realizado com sucesso!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body text-center">
                <p>Agora você pode fazer login com suas credenciais.</p>
                <p id="recovery-key-display" class="mt-3 fw-bold"></p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<!-- Novo Modal de Recuperação de Senha -->
<div class="modal fade" id="modalRecoveryPassword" tabindex="-1" aria-labelledby="modalRecoveryPasswordLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalRecoveryPasswordLabel">Recuperar Senha</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form id="formRecoveryPassword" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="recover_password">
                    <div class="mb-3">
                        <label for="email_recovery" class="form-label">Email</label>
                        <input type="email" name="email_recovery" id="email_recovery" class="form-control" placeholder="Seu email cadastrado" required autocomplete="off">
                        <div class="invalid-feedback">
                            Por favor, insira um email válido.
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="recovery_key" class="form-label">Chave de Recuperação</label>
                        <input type="text" name="recovery_key" id="recovery_key" class="form-control" placeholder="Sua chave de recuperação de 8 dígitos" required minlength="8" maxlength="8">
                        <div class="invalid-feedback">
                            Por favor, insira sua chave de recuperação (8 dígitos).
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Recuperar Senha</button>
                    <div id="recoveryMessage" class="mt-3 text-center"></div>
                </form>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Bundle com Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Função para mostrar o formulário de login de acordo com o tipo
    function showLoginType(type) {
        // Oculta todos os formulários de login
        document.querySelectorAll('.login-form').forEach(form => {
            form.classList.add('d-none');
        });

        // Remove a classe 'active' de todos os botões de tipo de login
        document.querySelectorAll('.btn').forEach(btn => {
            btn.classList.remove('active');
        });

        // Mostra o formulário de login do tipo selecionado
        document.getElementById(`${type}-login`).classList.remove('d-none');
        // Adiciona a classe 'active' ao botão do tipo selecionado
        document.getElementById(`btn-${type}`).classList.add('active');
    }

    // Função para abrir o modal de cadastro de paciente
    function openCadastroModal() {
        const modalCadastro = new bootstrap.Modal(document.getElementById('modalCadastroPaciente'));
        modalCadastro.show();
        // Limpa o formulário e validação ao abrir
        const form = document.getElementById('formCadastroPaciente');
        form.reset();
        form.classList.remove('was-validated');
        // Remove feedback de validação anterior
        form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    }

    // Função para abrir o modal de recuperação de senha
    function openRecoveryModal() {
        const modalRecovery = new bootstrap.Modal(document.getElementById('modalRecoveryPassword'));
        modalRecovery.show();
        // Limpa mensagens anteriores ao abrir o modal
        document.getElementById('recoveryMessage').innerHTML = '';
        document.getElementById('formRecoveryPassword').reset();
        document.getElementById('formRecoveryPassword').classList.remove('was-validated');
    }

    // Lógica de validação de formulário do Bootstrap
    (function () {
        'use strict'

        // Busca todos os formulários que queremos aplicar estilos de validação Bootstrap personalizados
        var forms = document.querySelectorAll('.needs-validation')

        // Loop sobre eles e impede o envio
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    // A validação de campos vazios é feita pelo atributo 'required' no HTML
                    // Se o formulário não for válido, impede o envio e mostra as mensagens de feedback
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
    })()

    // Evento DOMContentLoaded para inicialização
    document.addEventListener('DOMContentLoaded', () => {
        // Mostra o tipo de login padrão (paciente)
        showLoginType('paciente');

        // Lógica para mostrar modal de erro se houver erro PHP (para erros de login ou conexão)
        <?php if ($erro): ?>
            const modalErroElement = document.getElementById('modalErro');
            modalErroElement.querySelector('#modalErroMensagem').textContent = <?php echo json_encode($mensagem_erro); ?>;
            const modalErro = new bootstrap.Modal(modalErroElement);
            modalErro.show();
        <?php endif; ?>
    });

    // Lógica de envio do formulário de cadastro de paciente via AJAX
    document.getElementById('formCadastroPaciente').addEventListener('submit', async function(event) {
        event.preventDefault(); // Impede o envio padrão do formulário
        event.stopPropagation();

        const form = this;
        const modalCadastro = bootstrap.Modal.getInstance(document.getElementById('modalCadastroPaciente'));
        const modalSucesso = new bootstrap.Modal(document.getElementById('modalCadastroSucesso'));
        const modalErroElement = document.getElementById('modalErro');
        const modalErroInstance = new bootstrap.Modal(modalErroElement);
        const recoveryKeyDisplay = document.getElementById('recovery-key-display');
        const modalErroMensagem = document.getElementById('modalErroMensagem');

        // Limpa feedback de validação anterior de todos os campos
        form.querySelectorAll('.is-invalid').forEach(el => {
            el.classList.remove('is-invalid');
            // Opcional: resetar a mensagem padrão se for um feedback genérico
            // if (el.nextElementSibling && el.nextElementSibling.classList.contains('invalid-feedback')) {
            //     el.nextElementSibling.textContent = 'Este campo é obrigatório.'; // Ou a mensagem padrão original
            // }
        });


        if (!form.checkValidity()) {
            form.classList.add('was-validated');
            return; // Sai se a validação do lado do cliente falhar
        }

        const formData = new FormData(form);
        // Opcional: Adicionar um spinner de carregamento ou desabilitar o botão
        // button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Carregando...';
        // button.disabled = true;

        try {
            const response = await fetch('<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>', {
                method: 'POST',
                body: formData
            });
            const result = await response.json(); // Espera uma resposta JSON

            if (result.success) {
                if (modalCadastro) modalCadastro.hide(); // Fecha o modal de cadastro
                recoveryKeyDisplay.textContent = `Sua chave de recuperação é: ${result.recovery_key}. Guarde-a em local seguro.`;
                modalSucesso.show(); // Mostra o modal de sucesso

                // Define um temporizador para fechar o modal de sucesso após 5 segundos
                setTimeout(() => {
                    modalSucesso.hide();
                }, 5000); // 5000 milissegundos = 5 segundos

                form.reset();
                form.classList.remove('was-validated');
            } else {
                // Se a resposta JSON incluir um campo específico para o erro
                if (result.field) {
                    const targetInput = form.querySelector(`[name="${result.field}"]`);
                    if (targetInput) {
                        targetInput.classList.add('is-invalid');
                        if (targetInput.nextElementSibling && targetInput.nextElementSibling.classList.contains('invalid-feedback')) {
                            targetInput.nextElementSibling.textContent = result.message;
                        } else if (targetInput.parentElement.querySelector('.invalid-feedback')) { // Para o checkbox
                            targetInput.parentElement.querySelector('.invalid-feedback').textContent = result.message;
                        }
                    }
                    // Mantém o modal de cadastro aberto para o usuário corrigir
                    form.classList.add('was-validated'); // Re-aplica a validação para mostrar o feedback
                } else {
                    // Para outros erros gerais, mostra o modal de erro genérico
                    if (modalCadastro) modalCadastro.hide(); // Esconde o modal de cadastro
                    modalErroMensagem.textContent = result.message;
                    modalErroInstance.show(); // Mostra o modal de erro
                }
            }
        } catch (error) {
            console.error('Erro ao cadastrar paciente:', error);
            if (modalCadastro) modalCadastro.hide(); // Fecha o modal de cadastro
            modalErroMensagem.textContent = 'Erro de comunicação com o servidor. Tente novamente.';
            modalErroInstance.show(); // Mostra o modal de erro
        } finally {
            // Opcional: Reabilitar o botão e remover o spinner
            // button.innerHTML = 'Cadastrar';
            // button.disabled = false;
        }
    });

    // Lógica de envio do formulário de recuperação de senha via AJAX
    document.getElementById('formRecoveryPassword').addEventListener('submit', async function(event) {
        event.preventDefault();
        event.stopPropagation();

        const form = this;
        const recoveryMessage = document.getElementById('recoveryMessage');
        recoveryMessage.innerHTML = ''; // Limpa mensagens anteriores

        if (!form.checkValidity()) {
            form.classList.add('was-validated');
            return;
        }

        const formData = new FormData(form);
        // Adiciona um spinner de carregamento
        recoveryMessage.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Carregando...</span></div>';

        try {
            const response = await fetch('<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }, // Adicionado para indicar JSON no request
                body: JSON.stringify(Object.fromEntries(formData)) // Converte FormData para JSON
            });
            const result = await response.json();

            if (result.success) {
                recoveryMessage.innerHTML = `<div class="alert alert-success mt-3" role="alert">${result.message}</div>`;
                form.reset();
                form.classList.remove('was-validated');
            } else {
                recoveryMessage.innerHTML = `<div class="alert alert-danger mt-3" role="alert">${result.message}</div>`;
            }
        } catch (error) {
            console.error('Erro ao recuperar senha:', error);
            recoveryMessage.innerHTML = `<div class="alert alert-danger mt-3" role="alert">Erro de comunicação com o servidor. Tente novamente.</div>`;
        }
    });
</script>

</body>
</html>
