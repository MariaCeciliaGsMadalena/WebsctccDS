<?php
// chat_controller.php
// Controlador unificado para envio e recuperação de mensagens entre médico e paciente

// Certifique-se de que 'conexao.php' está configurado corretamente para sua base de dados.
// A função getPdoConnection é esperada de conexao.php
// Se conexao.php não definir getPdoConnection, você pode adicionar uma definição aqui
// ou garantir que conexao.php seja incluído antes deste arquivo.

/**
 * Envia uma mensagem de chat e a armazena no banco de dados.
 * @param PDO $pdo Conexão PDO com o banco de dados.
 * @param int $senderId ID do remetente.
 * @param string $senderType Tipo do remetente ('medico' ou 'paciente').
 * @param int $receiverId ID do destinatário.
 * @param string $receiverType Tipo do destinatário ('medico' ou 'paciente').
 * @param string $messageText O texto da mensagem.
 * @return array Um array associativo com 'success' e 'id_mensagem'.
 */
function sendChatMessage($pdo, $senderId, $senderType, $receiverId, $receiverType, $messageText) {
    $stmt = $pdo->prepare(
        "INSERT INTO mensagens (id_remetente, tipo_remetente, id_destinatario, tipo_destinatario, mensagem, data_envio, status_leitura)
         VALUES (:id_remetente, :tipo_remetente, :id_destinatario, :tipo_destinatario, :mensagem, NOW(), 0)"
    );
    $stmt->execute([
        ':id_remetente'    => $senderId,
        ':tipo_remetente'  => $senderType,
        ':id_destinatario' => $receiverId,
        ':tipo_destinatario' => $receiverType,
        ':mensagem'        => $messageText
    ]);
    return ['success' => true, 'id_mensagem' => $pdo->lastInsertId()];
}

/**
 * Recupera o histórico de mensagens entre dois usuários e marca as mensagens como lidas.
 * Adaptação para médico e paciente.
 * @param PDO $pdo Conexão PDO com o banco de dados.
 * @param int $meId ID do usuário logado.
 * @param string $meType Tipo do usuário logado ('medico' ou 'paciente').
 * @param int $themId ID do outro usuário na conversa.
 * @param string $themType Tipo do outro usuário na conversa ('medico' ou 'paciente').
 * @return array Um array associativo com 'success' e 'history' (array de mensagens).
 */
function getChatHistory($pdo, $meId, $meType, $themId, $themType) {
    // Marcar mensagens como lidas (mensagens enviadas pelo "them" para "me")
    $sqlUpdate = "UPDATE mensagens SET status_leitura = 1
                  WHERE id_remetente = :them_id AND tipo_remetente = :them_type
                  AND id_destinatario = :me_id AND tipo_destinatario = :me_type AND status_leitura = 0";
    $stmtUpdate = $pdo->prepare($sqlUpdate);
    $stmtUpdate->execute([
        ':them_id'    => $themId,
        ':them_type'  => $themType,
        ':me_id'      => $meId,
        ':me_type'    => $meType
    ]);

    // Obter mensagens
    $sql = "SELECT m.id_mensagem, m.id_remetente, m.tipo_remetente, m.mensagem, m.data_envio, m.status_leitura,
                    CASE
                        WHEN m.tipo_remetente = 'paciente' THEN p.nome
                        WHEN m.tipo_remetente = 'medico' THEN med.nome
                    END as nome_remetente
                    FROM mensagens m
                    LEFT JOIN pacientes p ON m.tipo_remetente = 'paciente' AND m.id_remetente = p.id_paciente
                    LEFT JOIN medicos med ON m.tipo_remetente = 'medico' AND m.id_remetente = med.id_medico
                    WHERE ((m.id_remetente = :me_id_1 AND m.tipo_remetente = :me_type_1 AND m.id_destinatario = :them_id_1 AND m.tipo_destinatario = :them_type_1)
                    OR (m.id_remetente = :them_id_2 AND m.tipo_remetente = :them_type_2 AND m.id_destinatario = :me_id_2 AND m.tipo_destinatario = :me_type_2))
                    ORDER BY m.data_envio ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':me_id_1'    => $meId,
        ':me_type_1'  => $meType,
        ':them_id_1'  => $themId,
        ':them_type_1' => $themType,
        ':me_id_2'    => $meId,
        ':me_type_2'  => $meType,
        ':them_id_2'  => $themId,
        ':them_type_2' => $themType
    ]);

    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['success' => true, 'history' => $mensagens];
}

/**
 * Obtém a contagem de mensagens não lidas para um usuário específico.
 * Adaptação para médico e paciente.
 * @param PDO $pdo Conexão PDO com o banco de dados.
 * @param int $userId ID do usuário.
 * @param string $userType Tipo do usuário ('medico' ou 'paciente').
 * @return array Um array associativo com 'success' e 'unread_counts' (array de contagens).
 */
function getUnreadMessageCounts($pdo, $userId, $userType) {
    $sql = "SELECT m.id_remetente, m.tipo_remetente,
                   CASE
                       WHEN m.tipo_remetente = 'paciente' THEN p.nome
                       WHEN m.tipo_remetente = 'medico' THEN med.nome
                   END as nome_remetente,
                   COUNT(*) as count
            FROM mensagens m
            LEFT JOIN pacientes p ON m.tipo_remetente = 'paciente' AND m.id_remetente = p.id_paciente
            LEFT JOIN medicos med ON m.tipo_remetente = 'medico' AND m.id_remetente = med.id_medico
            WHERE m.id_destinatario = :user_id
            AND m.tipo_destinatario = :user_type
            AND m.status_leitura = 0
            GROUP BY m.id_remetente, m.tipo_remetente, nome_remetente";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $userId,
        ':user_type' => $userType
    ]);

    return ['success' => true, 'unread_counts' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}
?>
