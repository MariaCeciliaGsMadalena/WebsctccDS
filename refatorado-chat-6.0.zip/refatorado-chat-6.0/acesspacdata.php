<?php
// Habilita a exibição de todos os erros PHP para depuração.
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
// Inclui o arquivo de conexão com o banco de dados.
include_once 'conexao.php';
// Inclui o controlador de chat, que contém funções para enviar e buscar mensagens.
include_once 'chat_controller.php';

// Verifica se o usuário está logado e se o tipo de usuário for 'paciente'.
if (!isset($_SESSION['usuario']) || (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] !== 'paciente')) {
    header('Location: login.php');
    exit;
}

// Obtém o nome, CPF e data de nascimento do paciente logado da sessão
$nome_paciente_logado = htmlspecialchars($_SESSION['usuario']['nome'] ?? 'Paciente');
$cpf_paciente_logado = htmlspecialchars($_SESSION['usuario']['cpf'] ?? 'N/A');
$data_nascimento_paciente = htmlspecialchars($_SESSION['usuario']['data_nascimento'] ?? '');
$id_paciente_logado = $_SESSION['usuario']['id_paciente'] ?? null;

// Inicializa a conexão PDO
try {
    $pdo = getPdoConnection();
} catch (Exception $e) {
    error_log("Erro ao conectar ao banco de dados em acesspacdata.php: " . $e->getMessage());
    echo "<h1>Erro de Conexão com o Banco de Dados</h1>";
    echo "<p>Não foi possível conectar ao banco de dados. Por favor, verifique as configurações de conexão e tente novamente. Detalhes: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}

// Lógica para ações AJAX (para buscar médicos por especialidade, agendamentos, e agora chat)
if (isset($_GET['action'])) {
    header('Content-Type: application/json');

    try {
        if ($_GET['action'] === 'get_medicos_by_especialidade') {
            $especialidade = $_GET['especialidade'] ?? '';
            $medicos = [];

            if (!empty($especialidade)) {
                // CORREÇÃO: Usar LOWER() para garantir busca sem distinção entre maiúsculas e minúsculas
                $sql = "SELECT id_medico, nome, crm, especialidade FROM medicos WHERE LOWER(especialidade) LIKE LOWER(:especialidade) ORDER BY nome ASC";
                $stmt = $pdo->prepare($sql);
                $searchTerm = '%' . $especialidade . '%';
                $stmt->bindParam(':especialidade', $searchTerm);
                $stmt->execute();
                $medicos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            echo json_encode(['success' => true, 'medicos' => $medicos]);
            exit;
        } elseif ($_GET['action'] === 'get_patient_appointments') {
            $id_paciente_logado = $_SESSION['usuario']['id_paciente'] ?? null;
            $agendamentos = [];

            if ($id_paciente_logado) {
                $cpf_paciente = $_SESSION['usuario']['cpf'] ?? null;

                if ($cpf_paciente) {
                    $sql = "SELECT ag.data_agendamento, ag.motivo_consulta, ag.nivel_urgencia,
                                   ag.nome_medico_agendado, ag.especialidade_medico_agendado, ag.chave_consulta, ag.status_agendamento
                            FROM agendamentos ag
                            LEFT JOIN medicos m ON ag.id_medico_agendado = m.id_medico
                            WHERE ag.cpf_paciente = :cpf_paciente
                            ORDER BY ag.data_agendamento DESC";
                    $stmt = $pdo->prepare($sql);
                    $stmt->bindParam(':cpf_paciente', $cpf_paciente, PDO::PARAM_STR);
                    $stmt->execute();
                    $agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
            }
            echo json_encode($agendamentos);
            exit;
        } elseif ($_GET['action'] === 'send_direct_message') {
            $data = json_decode(file_get_contents('php://input'), true);
            $id_remetente = $data['id_remetente'] ?? null;
            $id_destinatario = $data['id_destinatario'] ?? null;
            $mensagem = $data['mensagem'] ?? '';
            $tipo_remetente = 'paciente';
            $tipo_destinatario = 'medico';

            if (!empty($mensagem) && $id_remetente && $id_destinatario) {
                $result = sendChatMessage($pdo, $id_remetente, $tipo_remetente, $id_destinatario, $tipo_destinatario, $mensagem);
                echo json_encode($result);
            } else {
                echo json_encode(['success' => false, 'error' => 'Dados incompletos para enviar mensagem.']);
            }
            exit;
        } elseif ($_GET['action'] === 'get_direct_chat_history') {
            $id_paciente = $_GET['id_paciente'] ?? null;
            $id_medico = $_GET['id_medico'] ?? null;
            
            if ($id_paciente && $id_medico) {
                $chat_result = getChatHistory($pdo, $id_paciente, 'paciente', $id_medico, 'medico');
                echo json_encode($chat_result);
            } else {
                echo json_encode(['success' => false, 'error' => 'IDs de paciente ou médico ausentes.']);
            }
            exit;
        } elseif ($_GET['action'] === 'get_all_doctors_for_chat') {
            $medicos = [];
            $sql = "SELECT id_medico, nome, especialidade FROM medicos ORDER BY nome ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $medicos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'doctors' => $medicos]);
            exit;
        } elseif ($_GET['action'] === 'check_doctor_availability') {
            $id_medico = $_GET['id_medico'] ?? null;
            $data_consulta = $_GET['data_consulta'] ?? null; // Formato YYYY-MM-DD
            $hora_consulta = $_GET['hora_consulta'] ?? null; // Formato HH:MM

            $is_available = false;
            $reason = '';

            if ($id_medico && $data_consulta && $hora_consulta) {
                $dia_semana = date('N', strtotime($data_consulta)); // 1 (for Monday) through 7 (for Sunday)
                $dias_semana_map = [
                    1 => 'Segunda-feira',
                    2 => 'Terça-feira',
                    3 => 'Quarta-feira',
                    4 => 'Quinta-feira',
                    5 => 'Sexta-feira',
                    6 => 'Sábado',
                    7 => 'Domingo'
                ];
                $dia_semana_nome = $dias_semana_map[$dia_semana];

                // 1. Verificar horários de atendimento cadastrados (horarios_atendimento_medico)
                $sql_horarios = "SELECT hora_inicio, hora_fim, em_almoco, indisponivel_temporariamente
                                 FROM horarios_atendimento_medico
                                 WHERE id_medico = :id_medico AND dia_semana = :dia_semana";
                $stmt_horarios = $pdo->prepare($sql_horarios);
                $stmt_horarios->execute([
                    ':id_medico' => $id_medico,
                    ':dia_semana' => $dia_semana_nome
                ]);
                $horarios_medico = $stmt_horarios->fetchAll(PDO::FETCH_ASSOC);

                $requested_time_obj = new DateTime($hora_consulta);
                $found_matching_slot = false;

                foreach ($horarios_medico as $horario) {
                    $start_time_obj = new DateTime($horario['hora_inicio']);
                    $end_time_obj = new DateTime($horario['hora_fim']);

                    if ($requested_time_obj >= $start_time_obj && $requested_time_obj < $end_time_obj) {
                        $found_matching_slot = true;
                        if ($horario['em_almoco'] == 1) {
                            $is_available = false;
                            $reason = 'O médico estará em horário de almoço neste período.';
                            break;
                        }
                        if ($horario['indisponivel_temporariamente'] == 1) {
                            $is_available = false;
                            $reason = 'O médico estará temporariamente indisponível neste período.';
                            break;
                        }
                        // Se chegou aqui, o horário está dentro de um slot disponível e não é almoço/indisponível
                        $is_available = true;
                        break;
                    }
                }

                if (!$found_matching_slot) {
                    // Se não encontrou em horários fixos, verificar horários por data específica
                    $sql_horarios_data = "SELECT hora_inicio, hora_fim, em_almoco, indisponivel_temporariamente
                                          FROM horarios_data_especifica
                                          WHERE id_medico = :id_medico AND data_atendimento = :data_atendimento";
                    $stmt_horarios_data = $pdo->prepare($sql_horarios_data);
                    $stmt_horarios_data->execute([
                        ':id_medico' => $id_medico,
                        ':data_atendimento' => $data_consulta
                    ]);
                    $horarios_data_especifica = $stmt_horarios_data->fetchAll(PDO::FETCH_ASSOC);

                    $found_matching_slot_data = false;
                    foreach ($horarios_data_especifica as $horario_data) {
                        $start_time_obj_data = new DateTime($horario_data['hora_inicio']);
                        $end_time_obj_data = new DateTime($horario_data['hora_fim']);

                        if ($requested_time_obj >= $start_time_obj_data && $requested_time_obj < $end_time_obj_data) {
                            $found_matching_slot_data = true;
                            if ($horario_data['em_almoco'] == 1) {
                                $is_available = false;
                                $reason = 'O médico estará em horário de almoço neste período.';
                                break;
                            }
                            if ($horario_data['indisponivel_temporariamente'] == 1) {
                                $is_available = false;
                                $reason = 'O médico estará temporariamente indisponível neste período.';
                                break;
                            }
                            $is_available = true;
                            break;
                        }
                    }

                    if (!$found_matching_slot_data) {
                        $is_available = false;
                        $reason = 'O médico não possui horário de atendimento cadastrado para este dia e hora.';
                    }
                }


                // 2. Verificar agendamentos existentes no mesmo dia e hora
                if ($is_available) { // Só verifica se já passou pela primeira validação
                    $sql_agendamentos = "SELECT COUNT(*) FROM agendamentos
                                         WHERE id_medico_agendado = :id_medico
                                         AND data_agendamento = :data_agendamento_completa";
                    
                    $data_agendamento_completa = $data_consulta . ' ' . $hora_consulta . ':00'; // Combina data e hora
                    
                    $stmt_agendamentos = $pdo->prepare($sql_agendamentos);
                    $stmt_agendamentos->execute([
                        ':id_medico' => $id_medico,
                        ':data_agendamento_completa' => $data_agendamento_completa
                    ]);
                    $count_existing_appointments = $stmt_agendamentos->fetchColumn();

                    if ($count_existing_appointments > 0) {
                        $is_available = false;
                        $reason = 'Já existe um agendamento para este médico nesta data e hora.';
                    }
                }

            } else {
                $is_available = false;
                $reason = 'Dados de médico, data ou hora incompletos.';
            }

            echo json_encode(['success' => true, 'available' => $is_available, 'reason' => $reason]);
            exit;
        }

    } catch (PDOException $e) {
        error_log("Erro de PDO em acesspacdata.php (AJAX): " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Erro de banco de dados: ' . $e->getMessage()]);
        exit;
    } catch (Exception $e) {
        error_log("Erro geral em acesspacdata.php (AJAX): " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// Determina a seção ativa para o carregamento inicial da página.
$activeSection = $_GET['section'] ?? 'agendar-consulta-chat';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Paciente - Aglix MedTech</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Estilos personalizados para elementos Bootstrap não cobertos pelo Tailwind */
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: var(--bs-light-bg-subtle);
            color: var(--bs-body-color);
        }

        /* Modo escuro para elementos Bootstrap */
        .dark-mode {
            background-color: #1a202c;
            color: #e2e8f0;
        }
        .dark-mode .card, .dark-mode .bg-light {
            background-color: #2d3748 !important;
            color: #e2e8f0;
        }
        .dark-mode .form-control, .dark-mode .form-select {
            background-color: #2d3748;
            color: #e2e8f0;
            border-color: #4a5568;
        }
        .dark-mode .form-control:focus, .dark-mode .form-select:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
        }
        .dark-mode .text-muted {
            color: #a0aec0 !important;
        }
        .dark-mode .border-secondary {
            border-color: #4a5568 !important;
        }
        .dark-mode .list-group-item {
            background-color: #2d3748;
            color: #e2e8f0;
        }
        .dark-mode .list-group-item:hover {
            background-color: #4a5568 !important;
        }
        .dark-mode .btn-primary {
            background-color: #3b82f6;
            border-color: #3b82f6;
        }
        .dark-mode .btn-primary:hover {
            background-color: #2563eb;
            border-color: #2563eb;
        }
        .dark-mode .btn-outline-primary {
            color: #3b82f6;
            border-color: #3b82f6;
        }
        .dark-mode .btn-outline-primary:hover {
            background-color: #3b82f6;
            color: white;
        }
        .dark-mode .text-primary {
            color: #3b82f6 !important;
        }
        .dark-mode .text-secondary-bootstrap {
            color: #8b5cf6 !important;
        }
        .dark-mode .text-danger {
            color: #ef4444 !important;
        }
        .dark-mode .text-success {
            color: #22c55e !important;
        }
        .dark-mode .text-warning {
            color: #f59e0b !important;
        }
        .dark-mode .bg-info-subtle {
            background-color: rgba(59, 130, 246, 0.2) !important;
            border-color: rgba(59, 130, 246, 0.4) !important;
        }
        .dark-mode .bg-success-subtle {
            background-color: rgba(34, 197, 94, 0.2) !important;
            border-color: rgba(34, 197, 94, 0.4) !important;
        }
        .dark-mode .bg-danger-subtle {
            background-color: rgba(239, 68, 68, 0.2) !important;
            border-color: rgba(239, 68, 68, 0.4) !important;
        }
        .dark-mode .bg-purple-subtle {
            background-color: rgba(139, 92, 246, 0.2) !important;
            border-color: rgba(139, 92, 246, 0.4) !important;
        }
        .dark-mode .bg-warning-subtle {
            background-color: rgba(249, 115, 22, 0.2) !important;
            border-color: rgba(249, 115, 22, 0.4) !important;
        }
        .dark-mode .bg-pink-subtle {
            background-color: rgba(236, 72, 153, 0.2) !important;
            border-color: rgba(236, 72, 153, 0.4) !important;
        }
        .dark-mode .bg-teal-subtle {
            background-color: rgba(20, 184, 166, 0.2) !important;
            border-color: rgba(20, 184, 166, 0.4) !important;
        }
        .dark-mode .bg-yellow-subtle {
            background-color: rgba(234, 179, 8, 0.2) !important;
            border-color: rgba(234, 179, 8, 0.4) !important;
        }

        #agendar-consulta .row > div {
            margin-bottom: 1rem;
        }
        #agendar-consulta .row > div:last-child {
            margin-bottom: 0;
        }

        .sidebar-custom-width {
            width: 100%;
        }
        @media (min-width: 768px) {
            .sidebar-custom-width {
                width: 200px;
            }
        }

        .sidebar-item.sidebar-active {
            background-color: #3b82f6;
            color: white !important;
            font-weight: 600;
        }
        .dark-mode .sidebar-item.sidebar-active {
            background-color: #2563eb;
        }

        .chat-container {
            display: flex;
            flex-direction: column;
            height: 100%;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            overflow: hidden;
        }

        .chat-header {
            padding: 1rem;
            background-color: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
            font-weight: bold;
            color: #1a202c;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .dark-mode .chat-header {
            background-color: #2d3748;
            border-bottom-color: #4a5568;
            color: #e2e8f0;
        }

        .chat-messages, #doctors-for-direct-chat {
            flex-grow: 1;
            overflow-y: scroll;
            padding: 1rem;
            background-color: #f8fafc;

            &::-webkit-scrollbar {
                width: 8px;
                height: 8px;
            }

            &::-webkit-scrollbar-track {
                background: #f1f1f1;
                border-radius: 10px;
            }

            &::-webkit-scrollbar-thumb {
                background: #888;
                border-radius: 10px;
            }

            &::-webkit-scrollbar-thumb:hover {
                background: #555;
            }
        }

        .dark-mode .chat-messages, .dark-mode #doctors-for-direct-chat {
            background-color: #2d3748;

            &::-webkit-scrollbar-track {
                background: #4a5568;
            }

            &::-webkit-scrollbar-thumb {
                background: #64748b;
            }

            &::-webkit-scrollbar-thumb:hover {
                background: #94a3b8;
            }
        }

        .chat-message-bubble {
            max-width: 80%;
            padding: 0.75rem 1rem;
            border-radius: 1.25rem;
            margin-bottom: 0.5rem;
            word-wrap: break-word;
        }

        .chat-message-user {
            background-color: #3b82f6;
            color: white;
            align-self: flex-end;
            margin-left: auto;
        }

        .chat-message-bot {
            background-color: #e2e8f0;
            color: #1a202c;
            align-self: flex-start;
            margin-right: auto;
        }

        .dark-mode .chat-messages {
            background-color: #2d3748;
        }

        .dark-mode .chat-message-bot {
            background-color: #4a5568;
            color: #e2e8f0;
        }

        .chat-input-area {
            display: flex;
            padding: 1rem;
            border-top: 1px solid #e2e8f0;
            background-color: #fff;
            flex-shrink: 0;
        }

        .dark-mode .chat-input-area {
            background-color: #2d3748;
            border-top-color: #4a5568;
        }

        .chat-input-area input {
            flex-grow: 1;
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            outline: none;
        }

        .dark-mode .chat-input-area input {
            background-color: #4a5568;
            border-color: #64748b;
            color: #e2e8f0;
        }

        .chat-input-area button {
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            margin-left: 0.5rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .chat-input-area button:hover {
            background-color: #2563eb;
        }
    </style>
</head>

<body class="bg-light">

    <div class="d-flex flex-column flex-md-row min-vh-100">

        <!-- Menu Lateral (Tailwind CSS) -->
        <aside class="sidebar-custom-width bg-white shadow-lg flex flex-col p-4 md:p-4 sticky top-0 h-screen z-50 transition-all duration-300 dark:bg-gray-800">
            <div class="flex flex-col items-center border-b border-gray-300 pb-4 mb-4 flex-shrink-0 dark:border-gray-700">
                <input type="file" id="profilePicInput" class="hidden" accept="image/*" onchange="changeProfilePic()">
         
                <h2 class="text-xl font-bold mt-3 text-gray-800 dark:text-gray-200"><?php echo $nome_paciente_logado; ?></h2>
                <p class="text-sm text-gray-500 mt-2 dark:text-gray-400">
                    <i class="fas fa-id-card mr-1"></i> CPF: <?php echo $cpf_paciente_logado; ?>
                </p>
            </div>

            <nav class="flex flex-col flex-grow overflow-y-auto">
                <a href="?section=agendar-consulta-chat" id="nav-agendar-consulta-chat" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700 mb-2 <?php echo ($activeSection == 'agendar-consulta-chat') ? 'sidebar-active' : ''; ?>">
                    <i class="fas fa-comments text-xl"></i> <span class="text-base">Chat </span>
                </a>
              
                <a href="?section=consultas-anteriores" id="nav-consultas-anteriores" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700 mb-2 <?php echo ($activeSection == 'consultas-anteriores') ? 'sidebar-active' : ''; ?>">
                    <i class="fas fa-history text-xl"></i> <span class="text-base">Consultas agendadas</span>
                </a>
                
            
                <a href="?section=configuracoes" id="nav-configuracoes" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700 mb-2 <?php echo ($activeSection == 'configuracoes') ? 'sidebar-active' : ''; ?>">
                    <i class="fas fa-cogs text-xl"></i> <span class="text-base">Configurações</span>
                </a>
            </nav>

            <div class="mt-auto pt-4 border-t border-gray-300 flex-shrink-0 dark:border-gray-700">
                <button onclick="toggleDarkMode()" class="flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline w-full text-left text-sm font-medium hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
                    <i class="fas fa-adjust text-xl"></i> <span class="text-base">Modo Claro/Escuro</span>
                </button>
                <a href="login.php" class="flex items-center space-x-3 p-3 rounded-lg text-red-500 no-underline w-full text-left text-sm font-medium hover:bg-red-100 dark:text-red-400 dark:hover:bg-red-900 mt-2">
                    <i class="fas fa-sign-out-alt text-xl"></i> <span class="text-base">Sair</span>
                </a>
            </div>
        </aside>

        <main class="flex-grow-1 p-4 p-md-5 overflow-y-auto">
            <!-- Seção: Agendar Consulta (Chat) -->
            <section id="agendar-consulta-chat" class="content-section card p-4 shadow-sm mb-4 flex-grow-1 d-flex flex-column <?php echo ($activeSection !== 'agendar-consulta-chat') ? 'd-none' : ''; ?>">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-comments me-3 text-primary"></i> Selecione o Modo de Chat
                </h2>

                <div id="chat-mode-selection" class="mb-4 flex-shrink-0">
                    <button class="btn btn-outline-primary me-2" onclick="showChatMode('bot')">
                        <i class="fas fa-robot me-1"></i> Chat Agendamento (Bot)
                    </button>
                    <button class="btn btn-outline-success" onclick="showChatMode('direct')">
                        <i class="fas fa-user-md me-1"></i> Chat Direto com Médico
                    </button>
                </div>

                <!-- Chatbot de Agendamento -->
                <div id="chatbot-view" class="chat-container bg-white rounded-lg shadow-md flex-grow-1" style="display: block;">
                    <div class="chat-header">
                        Chat com Assistente de Agendamento
                    </div>
                    <div class="chat-messages" id="chatMessages">
                        <!-- Mensagens do chat serão adicionadas aqui -->
                        <div class="chat-message-bubble chat-message-bot">Olá! Eu sou o assistente de agendamento. Para começar, qual é o seu nome completo?</div>
                    </div>
                    <div class="chat-input-area">
                        <input type="text" id="chatInput" placeholder="Envie uma mensagem..." class="flex-grow-1">
                        <button id="sendChatBtn"><i class="fas fa-paper-plane"></i> Enviar</button>
                    </div>
                </div>

                <!-- Chat Direto com Médico -->
                <div id="direct-chat-view" class="d-none flex-grow-1">
                    <div id="doctor-list-for-chat" class="mb-4">
                        <h4 class="fs-5 fw-bold mb-3">Selecione um médico para conversar:</h4>
                        <ul class="list-group list-group-flush" id="doctors-for-direct-chat">
                            <!-- Médicos serão carregados aqui via JavaScript -->
                            <li class="list-group-item text-muted text-center">Carregando médicos...</li>
                        </ul>
                    </div>

                    <div id="selected-doctor-chat" class="chat-container bg-white rounded-lg shadow-md d-none">
                        <div class="chat-header">
                            Chat com <span id="direct-chat-doctor-name"></span>
                            <button class="btn btn-sm btn-secondary" onclick="showChatMode('direct')"><i class="fas fa-arrow-left me-1"></i> Voltar à lista</button>
                        </div>
                        <div class="chat-messages" id="directChatMessages">
                            <!-- Mensagens diretas serão carregadas aqui -->
                        </div>
                        <div class="chat-input-area">
                            <input type="text" id="directChatInput" placeholder="Envie uma mensagem..." class="flex-grow-1">
                            <button id="sendDirectChatBtn"><i class="fas fa-paper-plane"></i> Enviar</button>
                        </div>
                    </div>
                </div>


                <!-- Formulário oculto para enviar os dados da consulta -->
                <form id="appointmentFormHidden" onsubmit="submitAppointment(event)" class="d-none">
                    <input type="hidden" name="nome" id="hiddenNome" value="<?php echo $nome_paciente_logado; ?>">
                    <input type="hidden" name="cpf" id="hiddenCpf" value="<?php echo $cpf_paciente_logado; ?>">
                    <input type="hidden" name="idade" id="hiddenIdade">
                    <input type="hidden" name="genero" id="hiddenGenero">
                    <input type="hidden" name="alergias" id="hiddenAlergias">
                    <input type="hidden" name="doenca_existente" id="hiddenDoencaExistente">
                    <input type="hidden" name="data_nascimento" id="hiddenDataNascimento" value="<?php echo $data_nascimento_paciente; ?>">
                    <input type="hidden" name="motivo" id="hiddenMotivo">
                    <input type="hidden" name="urgencia" id="hiddenUrgencia">
                    <input type="hidden" name="especialidades" id="hiddenEspecialidades">
                    <input type="hidden" name="id_medico_agendado" id="hiddenIdMedicoAgendado">
                    <input type="hidden" name="nome_medico_agendado" id="hiddenNomeMedicoAgendado">
                    <input type="hidden" name="especialidade_medico_agendado" id="hiddenEspecialidadeMedicoAgendado">
                    <input type="hidden" name="data_agendamento" id="hiddenDataAgendamento">
                    <button type="submit" id="submitHiddenFormBtn"></button>
                </form>
            </section>

            <!-- A seção "Minhas Receitas" foi removida conforme solicitado -->
            <!-- <section id="minhas-receitas" class="content-section card p-4 shadow-sm mb-4 d-none">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-notes-medical me-3 text-primary"></i> Minhas Receitas
                </h2>
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fs-5 fw-semibold">Receitas Ativas</h3>
                    <button onclick="gerarNovaReceita()" class="btn btn-primary d-flex align-items-center gap-2">
                        <i class="fas fa-plus"></i> Solicitar Nova Receita
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover rounded overflow-hidden shadow-sm">
                        <thead class="bg-light">
                            <tr>
                                <th scope="col" class="py-3 px-4 text-start small fw-semibold text-muted">Medicamento</th>
                                <th scope="col" class="py-3 px-4 text-start small fw-semibold text-muted">Data da Prescrição</th>
                                <th scope="col" class="py-3 px-4 text-start small fw-semibold text-muted">Status</th>
                                <th scope="col" class="py-3 px-4 text-start small fw-semibold text-muted">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="listaReceitas">
                            <tr class="border-bottom border-secondary-subtle">
                                <td class="py-3 px-4">Carbonato de Lítio (300mg)</td>
                                <td class="py-3 px-4">10/01/2025</td>
                                <td class="py-3 px-4"><span class="badge bg-info text-info-emphasis rounded-pill">Ativa</span></td>
                                <td class="py-3 px-4">
                                    <button class="btn btn-link text-secondary-bootstrap text-decoration-none small"><i class="fas fa-redo-alt me-1"></i> Renovar</button>
                                    <button class="btn btn-link text-primary text-decoration-none small ms-2" onclick="openDetailsModal('recipe', 'Carbonato de Lítio (300mg)', '10 de janeiro de 2025', 'Tomar 1 cápsula via oral, 2 vezes ao dia (a cada 12h), após as refeições. Uso contínuo. Monitorar níveis séricos de lítio.', 'Link para PDF da Receita de Lítio')"><i class="fas fa-file-alt me-1"></i> Detalhes</button>
                                </td>
                            </tr>
                            <tr class="border-bottom border-secondary-subtle">
                                <td class="py-3 px-4">Metilfenidato (10mg)</td>
                                <td class="py-3 px-4">20/01/2025</td>
                                <td class="py-3 px-4"><span class="badge bg-danger text-danger-emphasis rounded-pill">Vencida</span></td>
                                <td class="py-3 px-4">
                                    <button class="btn btn-link text-secondary-bootstrap text-decoration-none small"><i class="fas fa-redo-alt me-1"></i> Renovar</button>
                                    <button class="btn btn-link text-primary text-decoration-none small ms-2" onclick="openDetailsModal('recipe', 'Metilfenidato (10mg)', '20 de janeiro de 2025', 'Tomar 1 comprimido via oral, pela manhã. Não exceder a dose prescrita. Não tomar à noite. Receita controlada.', 'Link para PDF da Receita de Metilfenidato')"><i class="fas fa-file-alt me-1"></i> Detalhes</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section> -->

            
            <section id="consultas-anteriores" class="content-section card p-4 shadow-sm mb-4 d-none">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-history me-3 text-primary"></i> Consultas Agendadas
                </h2>
                <ul id="previous-appointments-list" class="list-group list-group-flush">
                    <!-- Agendamentos serão carregados aqui via JavaScript -->
                    <li class="list-group-item text-muted text-center">Carregando agendamentos...</li>
                </ul>
            </section>

            <!-- A seção "Feedback" foi removida conforme solicitado -->
            <!-- <section id="feedback" class="content-section card p-4 shadow-sm mb-4 d-none">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-comment-dots me-3 text-primary"></i> Enviar Feedback
                </h2>
                <p class="text-muted mb-4">Sua opinião é muito importante para nós! Ajude-nos a melhorar nossos serviços.</p>
                <form onsubmit="submitFeedback(event)">
                    <div class="mb-3">
                        <label for="feedbackSubject" class="form-label small fw-medium text-muted">Assunto</label>
                        <input type="text" id="feedbackSubject" class="form-control" placeholder="Ex: Sugestão para agendamento">
                    </div>
                    <div class="mb-3">
                        <label for="feedbackMessage" class="form-label small fw-medium text-muted">Sua Mensagem</label>
                        <textarea id="feedbackMessage" rows="5" class="form-control" placeholder="Descreva sua sugestão, elogio ou problema..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane me-2"></i> Enviar Feedback</button>
                </form>
            </section> -->

            <section id="configuracoes" class="content-section card p-4 shadow-sm mb-4 d-none">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-cogs me-3 text-primary"></i> Configurações da Conta
                </h2>
                <div class="space-y-4">
                    <div>
                        <h3 class="fs-5 fw-semibold mb-3">Informações Pessoais</h3>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="nomeCompleto" class="form-label small fw-medium text-muted">Nome Completo</label>
                                <input type="text" id="nomeCompleto" class="form-control bg-light" value="<?php echo $nome_paciente_logado; ?>" disabled>
                            </div>
                            <div class="col-md-6">
                                <label for="cpfPaciente" class="form-label small fw-medium text-muted">CPF</label>
                                <input type="text" id="cpfPaciente" class="form-control bg-light" value="<?php echo $cpf_paciente_logado; ?>" disabled>
                            </div>
                            <div class="col-md-6">
                                <label for="emailPaciente" class="form-label small fw-medium text-muted">Email</label>
                                <input type="email" id="emailPaciente" class="form-control" value="teste.pessoa@email.com">
                            </div>
                            <div class="col-md-6">
                                <label for="telefonePaciente" class="form-label small fw-medium text-muted">Telefone</label>
                                <input type="text" id="telefonePaciente" class="form-control" value="(11) 98765-4321">
                            </div>
                        </div>
                        <button class="btn btn-primary mt-4"><i class="fas fa-save me-2"></i> Salvar Alterações</button>
                    </div>

                    <div class="border-top border-secondary pt-4 mt-4">
                        <h3 class="fs-5 fw-semibold mb-3">Preferências</h3>
                        <div class="d-flex align-items-center justify-content-between">
                            <span class="text-muted">Receber notificações por e-mail</span>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="emailNotificationsSwitch" checked>
                                <label class="form-check-label" for="emailNotificationsSwitch"></label>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </main>
    </div>

    <!-- Modal de Detalhes Existente -->
    <div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detailsModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <h3 id="modalTitle" class="fs-4 fw-bold mb-3 text-dark"></h3>
                    <p class="text-muted mb-2">
                        <span class="fw-semibold">Data:</span> <span id="modalDate"></span>
                    </p>
                    <div class="mb-3">
                        <p id="modalDescription" class="text-muted whitespace-pre-wrap"></p>
                    </div>
                    <a id="modalDownloadLink" href="#" target="_blank" class="btn btn-primary mt-3 d-none"><i class="fas fa-download me-2"></i> Baixar PDF Completo</a>
                    <p id="modalNoPdfMessage" class="small text-muted mt-2 d-none"><i class="fas fa-info-circle me-1"></i> Não há um PDF disponível para este item.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Novo Modal para Mensagens (substitui alert) -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <h3 id="messageModalTitle" class="fs-4 fw-bold mb-3 text-dark"></h3>
                    <p id="messageModalContent" class="text-muted mb-4"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Agendamento e Chat com Médico -->
    <div class="modal fade" id="appointmentConfirmationModal" tabindex="-1" aria-labelledby="appointmentConfirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="appointmentConfirmationModalLabel">Verificar Disponibilidade e Confirmar</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <p>Você deseja agendar a consulta com <strong id="modalDoctorName"></strong> para <strong id="modalAppointmentDate"></strong> às <strong id="modalAppointmentTime"></strong>?</p>
                    <p id="modalAvailabilityStatus" class="fw-bold mt-3"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <!-- O botão 'Confirmar Agendamento' é exibido apenas se o horário estiver disponível -->
                    <button type="button" class="btn btn-primary" id="confirmAppointmentBtn">Confirmar Agendamento</button>
                    <!-- O botão 'Falar com o Médico' é exibido se o horário NÃO estiver disponível -->
                    <button type="button" class="btn btn-info text-white" id="chatWithDoctorBtn"><i class="fas fa-comment-dots me-2"></i>Falar com o Médico</button>
                </div>
            </div>
        </div>
    </div>


    <!-- O Modal de Pré-Consulta foi mantido no HTML, mas não será mais aberto automaticamente pelo chat. -->
    <div class="modal fade" id="preConsultaModal" tabindex="-1" aria-labelledby="preConsultaModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="preConsultaModalLabel">Formulário de Pré-Consulta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <form id="preConsultaForm">
                        <input type="hidden" name="id_paciente" value="<?php echo $id_paciente_logado; ?>">
                        
                        <div class="mb-3">
                            <label for="queixa_principal" class="form-label small fw-medium text-muted">1. Qual a sua principal queixa e há quanto tempo isso apareceu?</label>
                            <textarea class="form-control" id="queixa_principal" name="queixa_principal" rows="3" placeholder="Conte-nos sobre sua principal queixa..." required></textarea>
                            <div class="invalid-feedback">Por favor, preencha este campo.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="tempo_queixa" class="form-label small fw-medium text-muted">Há quanto tempo o problema te persegue?</label>
                            <input type="text" class="form-control" id="tempo_queixa" name="tempo_queixa" placeholder="Ex: 3 dias, 1 semana, 2 meses" required>
                            <div class="invalid-feedback">Por favor, preencha este campo.</div>
                        </div>

                        <div class="mb-3">
                            <label for="medicamentos_alergias" class="form-label small fw-medium text-muted">2. Já usa remédio ou tem alergia a alguma coisa?</label>
                            <textarea class="form-control" id="medicamentos_alergias" name="medicamentos_alergias" rows="3" placeholder="Liste medicamentos em uso e alergias..." required></textarea>
                            <div class="invalid-feedback">Por favor, preencha este campo.</div>
                        </div>

                        <div class="mb-3">
                            <label for="historico_doencas_cirurgias_familia" class="form-label small fw-medium text-muted">3. Já teve alguma doença, passou por cirurgia ou conhece que doença rola na família?</label>
                            <textarea class="form-control" id="historico_doencas_cirurgias_familia" name="historico_doencas_cirurgias_familia" rows="3" placeholder="Histórico médico pessoal e familiar..." required></textarea>
                            <div class="invalid-feedback">Por favor, preencha este campo.</div>
                        </div>

                        <div class="mb-3">
                            <label for="sintomas_atuais_detalhes" class="form-label small fw-medium text-muted">4. Quais são os sintomas agora? Quando e como eles começaram? Melhoram ou pioram se fizer algo?</label>
                            <textarea class="form-control" id="sintomas_atuais_detalhes" name="sintomas_atuais_detalhes" rows="4" placeholder="Detalhes dos sintomas atuais..." required></textarea>
                            <div class="invalid-feedback">Por favor, preencha este campo.</div>
                        </div>

                        <div class="mb-3">
                            <label for="rotina_estilo_vida" class="form-label small fw-medium text-muted">5. Qual é a sua rotina: dorme bem, come direito, se exercita?</label>
                            <textarea class="form-control" id="rotina_estilo_vida" name="rotina_estilo_vida" rows="3" placeholder="Descreva sua rotina diária..." required></textarea>
                            <div class="invalid-feedback">Por favor, preencha este campo.</div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" form="preConsultaForm" class="btn btn-primary me-2"><i class="fas fa-save me-2"></i> Salvar Pré-Consulta</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Bootstrap Bundle com Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Funções JavaScript básicas para evitar ReferenceError
        function showSection(sectionId, element) {
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.add('d-none');
                section.classList.remove('d-block');
            });

            const activeSection = document.getElementById(sectionId);
            if (activeSection) {
                activeSection.classList.remove('d-none');
                activeSection.classList.add('d-block');

                if (sectionId === 'consultas-anteriores') {
                    loadPreviousAppointments();
                }
            }

            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('sidebar-active');
            });

            if (element) {
                element.classList.add('sidebar-active');
            }
        }

        function changeProfilePic() {
            console.log('Função changeProfilePic chamada.');
        }

        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            console.log('Modo escuro alternado.');
        }

        function openDetailsModal(type, title, date, description, downloadLink) {
            const modalElement = new bootstrap.Modal(document.getElementById('detailsModal'));
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalDate').textContent = date;
            document.getElementById('modalDescription').textContent = description;
            document.getElementById('detailsModalLabel').textContent = title;

            const downloadLinkElement = document.getElementById('modalDownloadLink');
            const noPdfMessageElement = document.getElementById('modalNoPdfMessage');

            if (downloadLink && downloadLink !== 'N/A') {
                downloadLinkElement.href = downloadLink;
                downloadLinkElement.classList.remove('d-none');
                noPdfMessageElement.classList.add('d-none');
            } else {
                downloadLinkElement.classList.add('d-none');
                noPdfMessageElement.classList.remove('d-none');
            }

            modalElement.show();
            console.log('Modal de detalhes aberto.');
        }

        function closeDetailsModal() {
            const modalElement = bootstrap.Modal.getInstance(document.getElementById('detailsModal'));
            if (modalElement) {
                modalElement.hide();
            }
            console.log('Modal de detalhes fechado.');
        }

        function showMessageModal(title, message) {
            const modalElement = new bootstrap.Modal(document.getElementById('messageModal'));
            document.getElementById('messageModalTitle').innerHTML = title;
            document.getElementById('messageModalContent').innerHTML = message;
            document.getElementById('messageModalLabel').textContent = title;
            modalElement.show();
        }

        function closeMessageModal() {
            const modalElement = bootstrap.Modal.getInstance(document.getElementById('messageModal'));
            if (modalElement) {
                modalElement.hide();
            }
        }

        function gerarNovaReceita() {
            console.log('Função gerarNovaReceita chamada.');
            showMessageModal('Solicitação de Receita', 'Funcionalidade de solicitação de nova receita em desenvolvimento!');
        }

        function submitFeedback(event) {
            event.preventDefault();
            console.log('Função submitFeedback chamada.');
            const subject = document.getElementById('feedbackSubject').value;
            const message = document.getElementById('feedbackMessage').value;
            showMessageModal('Feedback Enviado', `Seu feedback foi enviado com sucesso!<br>Assunto: ${subject}<br>Mensagem: ${message}`);
            document.getElementById('feedbackSubject').value = '';
            document.getElementById('feedbackMessage').value = '';
        }

        function toggleDesc(id) {
            const desc = document.getElementById(id);
            const icon = document.getElementById(id.replace('Desc', 'Icon'));
            if (desc.classList.contains('d-none')) {
                desc.classList.remove('d-none');
                icon.classList.remove('bi-plus-lg');
                icon.classList.add('bi-dash-lg');
            } else {
                desc.classList.add('d-none');
                icon.classList.remove('bi-dash-lg');
                icon.classList.add('bi-plus-lg');
            }
        }

        function calculateAge() {
            const birthDateInput = document.getElementById('dataNascimento');
            const ageInput = document.getElementById('idade');
            const birthDate = new Date(birthDateInput.value);

            if (isNaN(birthDate.getTime()) || birthDateInput.value === '') {
                ageInput.value = '';
                return;
            }

            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const m = today.getMonth() - birthDate.getMonth();

            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            ageInput.value = age >= 0 ? age : '';
        }

        async function loadPreviousAppointments() {
            const appointmentList = document.getElementById('previous-appointments-list');
            appointmentList.innerHTML = '<li class="list-group-item text-muted text-center">Carregando agendamentos...</li>';

            try {
                const response = await fetch('acesspacdata.php?action=get_patient_appointments');
                const appointments = await response.json();

                if (appointments.success === false) {
                    appointmentList.innerHTML = `<li class="list-group-item text-danger text-center">Erro ao carregar agendamentos: ${appointments.error}</li>`;
                    return;
                }

                if (appointments.length === 0) {
                    appointmentList.innerHTML = '<li class="list-group-item text-muted text-center">Nenhum agendamento anterior encontrado.</li>';
                } else {
                    appointmentList.innerHTML = '';
                    appointments.forEach(appointment => {
                        const date = new Date(appointment.data_agendamento).toLocaleDateString('pt-BR', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                        const doctorInfo = appointment.nome_medico_agendado ? ` com <span class="fw-medium">${appointment.nome_medico_agendado} (${appointment.especialidade_medico_agendado})</span>` : ' (Médico não atribuído)';
                        const appointmentItem = `
                            <li class="list-group-item d-flex justify-content-between align-items-center border-bottom border-secondary-subtle">
                                <div>
                                    <p class="fw-semibold fs-6 mb-1">${appointment.motivo_consulta}</p>
                                    <p class="small text-muted mb-0">
                                        Data: <span class="fw-medium">${date}</span>${doctorInfo}<br>
                                        Urgência: <span class="fw-medium">${appointment.nivel_urgencia}</span><br>
                                        Status: <span class="fw-medium">${appointment.status_agendamento}</span>
                                    </p>
                                </div>
                                <button class="btn btn-link text-primary text-decoration-none small" onclick="openDetailsModal('appointment', 'Detalhes do Agendamento', '${date}', 'Motivo: ${appointment.motivo_consulta}\\nNível de Urgência: ${appointment.nivel_urgencia}\\nMédico: ${appointment.nome_medico_agendado || 'Não atribuído'}\\nEspecialidade: ${appointment.especialidade_medico_agendado || 'Não atribuído'}\\nStatus: ${appointment.status_agendamento}\\nChave: ${appointment.chave_consulta}', 'gerar_comprovante.php?chave_consulta=${appointment.chave_consulta}')">
                                    <i class="fas fa-info-circle me-1"></i> Detalhes
                                </button>
                            </li>
                        `;
                        appointmentList.innerHTML += appointmentItem;
                    });
                }
            } catch (error) {
                console.error('Erro ao buscar agendamentos:', error);
                appointmentList.innerHTML = '<li class="list-group-item text-danger text-center">Não foi possível carregar os agendamentos. Tente novamente mais tarde.</li>';
            }
        }

        async function submitAppointment(event) {
            event.preventDefault();

            const form = event.target;
            const formData = new FormData(form);
            const data = {};
            for (let [key, value] of formData.entries()) {
                if (key === 'especialidades[]') {
                    if (!data['especialidades']) {
                        data['especialidades'] = [];
                    }
                    data['especialidades'].push(value);
                } else {
                    data[key] = value;
                }
            }

            if (data['especialidades']) {
                data['especialidades'] = JSON.stringify(data['especialidades']);
            } else {
                data['especialidades'] = '[]';
            }

            data['data_agendamento'] = document.getElementById('hiddenDataAgendamento').value;
            data['id_medico_agendado'] = document.getElementById('hiddenIdMedicoAgendado').value;
            data['nome_medico_agendado'] = document.getElementById('hiddenNomeMedicoAgendado').value;
            data['especialidade_medico_agendado'] = document.getElementById('hiddenEspecialidadeMedicoAgendado').value;


            try {
                const response = await fetch('save_appointment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                if (result.success) {
                    const preConsultaSummary = `Pré-consulta completa:\n` +
                                                `Queixa Principal: ${chatState.queixa_principal}\n` +
                                                `Tempo da Queixa: ${chatState.tempo_queixa}\n` +
                                                `Medicamentos/Alergias: ${chatState.medicamentos_alergias}\n` +
                                                `Histórico Médico/Familiar: ${chatState.historico_doencas_cirurgias_familia}\n` +
                                                `Sintomas Atuais: ${chatState.sintomas_atuais_detalhes}\n` +
                                                `Rotina/Estilo de Vida: ${chatState.rotina_estilo_vida}\n\n` +
                                                `Agendamento Solicitado:\n` +
                                                `Urgência: ${chatState.urgencia}\n` +
                                                `Especialidade: ${chatState.especialidades[0]}\n` +
                                                `Médico: Dr(a). ${chatState.nomeMedicoAgendado}\n` +
                                                `Data: ${new Date(chatState.dataConsulta).toLocaleDateString('pt-BR')} às ${chatState.horaConsulta}`;
                    
                    await sendDirectMessage(chatState.idMedicoAgendado, preConsultaSummary);

                    const comprovanteUrl = `gerar_comprovante.php?chave_consulta=${result.chave_consulta}`;
                    window.open(comprovanteUrl, '_blank');

                    showMessageModal('Agendamento Confirmado!', `Sua consulta foi agendada com sucesso! Chave de Consulta: <strong>${result.chave_consulta}</strong>. Por favor, anote esta chave para referência. O comprovante foi aberto em uma nova aba. Um resumo da sua pré-consulta foi enviado ao Dr(a). ${chatState.nomeMedicoAgendado}.`);
                    form.reset();
                    calculateAge();
                } else {
                    showMessageModal('Erro no Agendamento', `Não foi possível agendar sua consulta: ${result.error}. Por favor, tente novamente.`);
                }
            } catch (error) {
                console.error('Erro ao enviar agendamento:', error);
                showMessageModal('Erro de Conexão', 'Ocorreu um erro ao tentar agendar sua consulta. Verifique sua conexão e tente novamente.');
            }
        }

        let preConsultaModalInstance; 

        function openPreConsultaModal() {
            if (!preConsultaModalInstance) {
                preConsultaModalInstance = new bootstrap.Modal(document.getElementById('preConsultaModal'));
            }
            preConsultaModalInstance.show();
            console.log('Modal de Pré-Consulta aberto.'); 
        }

        function closePreConsultaModal() {
            if (preConsultaModalInstance) {
                preConsultaModalInstance.hide();
            }
            console.log('Modal de Pré-Consulta fechado.'); 
        }

        async function savePreConsultaData() {
            const data = {
                id_paciente: <?php echo json_encode($id_paciente_logado); ?>,
                queixa_principal: chatState.queixa_principal,
                tempo_queixa: chatState.tempo_queixa,
                medicamentos_alergias: chatState.medicamentos_alergias,
                historico_doencas_cirurgias_familia: chatState.historico_doencas_cirurgias_familia,
                sintomas_atuais_detalhes: chatState.sintomas_atuais_detalhes,
                rotina_estilo_vida: chatState.rotina_estilo_vida
            };

            try {
                const response = await fetch('save_pre_consulta.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    console.log('Pré-consulta salva com sucesso via chat.');
                } else {
                    console.error('Erro ao salvar pré-consulta via chat:', result.error);
                    showMessageModal('Erro!', `Erro ao salvar pré-consulta: ${result.error}. Por favor, tente novamente.`);
                }
            } catch (error) {
                console.error('Erro de conexão ao salvar pré-consulta via chat:', error);
                    showMessageModal('Erro de Conexão!', 'Ocorreu um erro ao tentar salvar a pré-consulta. Verifique sua conexão e tente novamente.');
            }
        }

        async function submitPreConsultaForm(event) {
            if (event) {
                event.preventDefault(); 
            }
            
            const form = document.getElementById('preConsultaForm'); 
            let isValid = true; 

            const requiredFields = [
                'queixa_principal',
                'tempo_queixa',
                'medicamentos_alergias',
                'historico_doencas_cirurgias_familia',
                'sintomas_atuais_detalhes',
                'rotina_estilo_vida'
            ];

            requiredFields.forEach(fieldId => {
                const input = document.getElementById(fieldId);
                if (input) {
                    if (input.value.trim() === '') {
                        input.classList.add('is-invalid'); 
                        isValid = false;
                    } else {
                        input.classList.remove('is-invalid');
                    }
                }
            });

            if (!isValid) {
                console.log('submitPreConsultaForm: Validação falhou. Campos obrigatórios não preenchidos.');
                showMessageModal('Erro de Validação', 'Por favor, preencha todos os campos obrigatórios do formulário de pré-consulta.');
                return; 
            }

            const formData = new FormData(form);
            const data = {};
            for (let [key, value] of formData.entries()) {
                data[key] = value;
            }

            try {
                const response = await fetch('save_pre_consulta.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    showMessageModal('Sucesso!', 'Pré-consulta salva com sucesso!');
                    closePreConsultaModal();
                    form.reset(); 
                } else {
                    showMessageModal('Erro!', `Erro ao salvar pré-consulta: ${result.error}`);
                }
            } catch (error) {
                console.error('submitPreConsultaForm: Erro ao enviar pré-consulta:', error); 
                showMessageModal('Erro de Conexão!', 'Ocorreu um erro ao tentar salvar a pré-consulta. Verifique sua conexão e tente novamente.');
            }
        }


        // Lógica do Chatbot de Agendamento
        const chatMessages = document.getElementById('chatMessages');
        const chatInput = document.getElementById('chatInput');
        const sendChatBtn = document.getElementById('sendChatBtn');
        const hiddenForm = document.getElementById('appointmentFormHidden');
        const submitHiddenFormBtn = document.getElementById('submitHiddenFormBtn');

        let chatState = {
            step: 0,
            nome: "<?php echo $nome_paciente_logado; ?>",
            cpf: "<?php echo $cpf_paciente_logado; ?>",
            idade: "",
            genero: "",
            alergias: "",
            doenca_existente: "",
            dataNascimento: "<?php echo $data_nascimento_paciente; ?>",
            motivo: "",
            urgencia: "",
            especialidades: [],
            idMedicoAgendado: null,
            nomeMedicoAgendado: "",
            especialidadeMedicoAgendado: "",
            dataConsulta: "",
            horaConsulta: "",
            queixa_principal: "",
            tempo_queixa: "",
            medicamentos_alergias: "",
            historico_doencas_cirurgias_familia: "",
            sintomas_atuais_detalhes: "",
            rotina_estilo_vida: "",
            availableDoctors: []
        };

        const botResponses = [
            "Olá! Eu sou o assistente de agendamento. Para começar, qual é o seu nome completo?",
            "Qual é o seu CPF? (apenas números)",
            "Qual é a sua idade?",
            "Qual é o seu gênero? (Masculino, Feminino, Outro)",
            "Você tem alguma alergia a medicamentos ou alimentos? Se sim, por favor, especifique.",
            "Você possui alguma doença existente ou condição de saúde crônica? Se sim, por favor, descreva.",
            "Qual a sua principal queixa e há quanto tempo isso apareceu?",
            "Há quanto tempo o problema te persegue?",
            "Já usa remédio ?",
            "Já teve algum cancer,  ja passou por alguma cirurgia ?",
            "Quais são os sintomas agora? pioram?",
            "Qual é a sua rotina: dorme bem, come direito, se exercita?",
            "Obrigado por fornecer as informações da pré-consulta! Qual o nível de urgência da sua consulta? (Baixa, Média, Alta, Emergência)",
            "Para qual categoria de medico você gostaria de agendar?cardiologia, urologia, oftalmologia, ortopedia, ginecologia, clinico geral.", // Adicionado "Clínico Geral"
            "Por favor, escolha o número do médico desejado na lista abaixo:",
            "Por favor, confirme a data desejada para a consulta (DD/MM/AAAA).",
            "E qual horário você prefere? (HH:MM)",
            "Perfeito! Posso confirmar os dados: [NOME], CPF [CPF], idade [IDADE], gênero [GENERO], alergias [ALERGIAS], doença existente [DOENCA_EXISTENTE], motivo [MOTIVO], urgência [URGENCIA], especialidade [ESPECIALIDADE], com Dr(a). [NOME_MEDICO] em [DATA] às [HORA]. Está correto? (Sim/Não)"
        ];

        function addMessage(sender, message, targetChat = chatMessages) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('chat-message-bubble');
            if (sender === 'user') {
                messageDiv.classList.add('chat-message-user');
            } else {
                messageDiv.classList.add('chat-message-bot');
            }
            messageDiv.innerHTML = message;
            targetChat.appendChild(messageDiv);
            targetChat.scrollTop = targetChat.scrollHeight;
        }

        function resetChatState() {
            chatState = {
                step: 0,
                nome: "<?php echo $nome_paciente_logado; ?>",
                cpf: "<?php echo $cpf_paciente_logado; ?>",
                idade: "",
                genero: "",
                alergias: "",
                doenca_existente: "",
                dataNascimento: "<?php echo $data_nascimento_paciente; ?>",
                motivo: "",
                urgencia: "",
                especialidades: [],
                idMedicoAgendado: null,
                nomeMedicoAgendado: "",
                especialidadeMedicoAgendado: "",
                dataConsulta: "",
                horaConsulta: "",
                queixa_principal: "",
                tempo_queixa: "",
                medicamentos_alergias: "",
                historico_doencas_cirurgias_familia: "",
                sintomas_atuais_detalhes: "",
                rotina_estilo_vida: "",
                availableDoctors: []
            };
        }

        async function fetchDoctorsBySpecialty(specialty) {
            try {
                const response = await fetch(`acesspacdata.php?action=get_medicos_by_especialidade&especialidade=${encodeURIComponent(specialty)}`);
                const result = await response.json();
                if (result.success) {
                    chatState.availableDoctors = result.medicos;
                    if (result.medicos.length > 0) {
                        let doctorList = "Aqui estão os médicos disponíveis para esta especialidade:<br>";
                        result.medicos.forEach((medico, index) => {
                            doctorList += `${index + 1}. Dr(a). ${medico.nome} (CRM: ${medico.crm})<br>`;
                        });
                        addMessage('bot', doctorList + botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "Não encontramos médicos para esta especialidade. Por favor, tente outra especialidade.");
                        // Não decrementa o step aqui, para que o usuário possa tentar novamente a especialidade
                        // ou o bot pode dar uma dica de especialidades válidas.
                        // Se o step for decrementado, ele voltaria para a pergunta anterior (urgência)
                        // o que não é o comportamento desejado.
                    }
                } else {
                    addMessage('bot', "Ocorreu um erro ao buscar médicos. Por favor, tente novamente.");
                    console.error("Erro na resposta da API ao buscar médicos:", result.error);
                    // Não decrementa o step aqui, para que o usuário possa tentar novamente a especialidade
                }
            } catch (error) {
                console.error("Erro ao buscar médicos:", error);
                addMessage('bot', "Ocorreu um erro de conexão ao buscar médicos. Por favor, tente novamente.");
                // Não decrementa o step aqui, para que o usuário possa tentar novamente a especialidade
            }
        }

        function handleUserInput(message) {
            addMessage('user', message);

            switch (chatState.step) {
                case 0:
                    chatState.nome = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 1:
                    const cpfRegex = /^\d{11}$/;
                    if (message.match(cpfRegex)) {
                        chatState.cpf = message;
                        chatState.step++;
                        addMessage('bot', botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "CPF inválido. Por favor, digite apenas 11 números.");
                    }
                    break;
                case 2:
                    const age = parseInt(message);
                    if (!isNaN(age) && age > 0 && age < 120) {
                        chatState.idade = age;
                        chatState.step++;
                        addMessage('bot', botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "Idade inválida. Por favor, digite um número válido para sua idade.");
                    }
                    break;
                case 3:
                    const generoOptions = ['masculino', 'feminino', 'outro'];
                    if (generoOptions.includes(message.toLowerCase())) {
                        chatState.genero = message;
                        chatState.step++;
                        addMessage('bot', botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "Gênero inválido. Por favor, escolha entre Masculino, Feminino ou Outro.");
                    }
                    break;
                case 4:
                    chatState.alergias = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 5:
                    chatState.doenca_existente = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 6:
                    chatState.queixa_principal = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 7:
                    chatState.tempo_queixa = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 8:
                    chatState.medicamentos_alergias = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 9:
                    chatState.historico_doencas_cirurgias_familia = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 10:
                    chatState.sintomas_atuais_detalhes = message;
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 11:
                    chatState.rotina_estilo_vida = message;
                    savePreConsultaData();
                    chatState.motivo = "Pré-consulta preenchida via chat";
                    chatState.step++;
                    addMessage('bot', botResponses[chatState.step]);
                    break;
                case 12:
                    const urgenciaOptions = ['baixa', 'media', 'alta', 'emergencia'];
                    if (urgenciaOptions.includes(message.toLowerCase())) {
                        chatState.urgencia = message;
                        chatState.step++;
                        addMessage('bot', botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "Por favor, escolha entre Baixa, Média, Alta ou Emergência.");
                    }
                    break;
                case 13:
                    const especialidadeOptions = ['cardiologia', 'urologia', 'dermatologia', 'oftalmologia', 'ortopedia', 'ginecologia', 'clinico geral', 'endocrinologia'];
                    if (especialidadeOptions.includes(message.toLowerCase())) {
                        chatState.especialidades = [message];
                        chatState.step++;
                        fetchDoctorsBySpecialty(message);
                    } else {
                        addMessage('bot', "Especialidade inválida. Por favor, escolha uma das opções listadas: " + especialidadeOptions.join(', ') + ".");
                    }
                    break;
                case 14:
                    const doctorIndex = parseInt(message) - 1;
                    if (!isNaN(doctorIndex) && doctorIndex >= 0 && doctorIndex < chatState.availableDoctors.length) {
                        const selectedDoctor = chatState.availableDoctors[doctorIndex];
                        chatState.idMedicoAgendado = selectedDoctor.id_medico;
                        chatState.nomeMedicoAgendado = selectedDoctor.nome;
                        chatState.especialidadeMedicoAgendado = selectedDoctor.especialidade;
                        chatState.step++;
                        addMessage('bot', botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "Seleção inválida. Por favor, digite o número correspondente ao médico desejado.");
                        // Não decrementa o step aqui, para que o usuário possa tentar novamente a seleção do médico
                    }
                    break;
                case 15:
                    const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
                    const matchDate = message.match(dateRegex);
                    if (matchDate) {
                        const [_, day, month, year] = matchDate;
                        chatState.dataConsulta = `${year}-${month}-${day}`;
                        chatState.step++;
                        addMessage('bot', botResponses[chatState.step]);
                    } else {
                        addMessage('bot', "Formato de data inválido. Por favor, use DD/MM/AAAA.");
                    }
                    break;
                case 16:
                    const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
                    if (message.match(timeRegex)) {
                        chatState.horaConsulta = message;
                        // Agora, antes de abrir o modal, verificamos a disponibilidade
                        checkDoctorAvailability(
                            chatState.idMedicoAgendado,
                            chatState.dataConsulta,
                            chatState.horaConsulta,
                            chatState.nomeMedicoAgendado
                        );
                    } else {
                        addMessage('bot', "Formato de hora inválido. Por favor, use HH:MM.");
                    }
                    break;
                case 17:
                    if (message.toLowerCase() === 'sim') {
                        // Preencher o formulário oculto e submeter
                        document.getElementById('hiddenNome').value = chatState.nome;
                        document.getElementById('hiddenCpf').value = chatState.cpf;
                        document.getElementById('hiddenIdade').value = chatState.idade;
                        document.getElementById('hiddenGenero').value = chatState.genero;
                        document.getElementById('hiddenAlergias').value = chatState.alergias;
                        document.getElementById('hiddenDoencaExistente').value = chatState.doenca_existente;
                        document.getElementById('hiddenDataNascimento').value = chatState.dataNascimento;
                        document.getElementById('hiddenMotivo').value = chatState.motivo;
                        document.getElementById('hiddenUrgencia').value = chatState.urgencia;
                        document.getElementById('hiddenEspecialidades').value = JSON.stringify(chatState.especialidades);
                        document.getElementById('hiddenIdMedicoAgendado').value = chatState.idMedicoAgendado;
                        document.getElementById('hiddenNomeMedicoAgendado').value = chatState.nomeMedicoAgendado;
                        document.getElementById('hiddenEspecialidadeMedicoAgendado').value = chatState.especialidadeMedicoAgendado;
                        document.getElementById('hiddenDataAgendamento').value = `${chatState.dataConsulta} ${chatState.horaConsulta}:00`;

                        submitHiddenFormBtn.click(); // Dispara a submissão do formulário
                        resetChatState();
                        chatState.step = 0; // Reinicia o fluxo do bot
                    } else if (message.toLowerCase() === 'não' || message.toLowerCase() === 'nao') {
                        addMessage('bot', "Ok. Por favor, me diga o que precisa ser corrigido ou se deseja recomeçar.");
                        chatState.step = 0; // Reinicia o fluxo para o início
                        resetChatState();
                        addMessage('bot', botResponses[chatState.step]); // Repete a primeira pergunta
                    } else {
                        addMessage('bot', "Por favor, responda 'Sim' ou 'Não'.");
                    }
                    break;
                default:
                    addMessage('bot', "Desculpe, não entendi. Por favor, tente novamente.");
                    break;
            }
        }

        sendChatBtn.addEventListener('click', () => {
            const message = chatInput.value.trim();
            if (message) {
                handleUserInput(message);
                chatInput.value = '';
            }
        });

        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendChatBtn.click();
            }
        });

        // --- Lógica do Chat Direto ---
        let currentDirectChatDoctorId = null;
        let currentDirectChatDoctorName = '';

        const directChatMessagesDiv = document.getElementById('directChatMessages');
        const directChatInput = document.getElementById('directChatInput');
        const sendDirectChatBtn = document.getElementById('sendDirectChatBtn');
        const directChatDoctorNameSpan = document.getElementById('direct-chat-doctor-name');

        async function loadDoctorsForChat() {
            const doctorsListDiv = document.getElementById('doctors-for-direct-chat');
            doctorsListDiv.innerHTML = '<li class="list-group-item text-muted text-center">Carregando médicos...</li>';
            try {
                const response = await fetch('acesspacdata.php?action=get_all_doctors_for_chat');
                const result = await response.json();
                if (result.success && result.doctors.length > 0) {
                    doctorsListDiv.innerHTML = '';
                    result.doctors.forEach(doctor => {
                        const listItem = document.createElement('li');
                        listItem.classList.add('list-group-item', 'list-group-item-action');
                        listItem.innerHTML = `
                            <a href="#" class="d-block text-decoration-none text-dark" 
                               onclick="event.preventDefault(); openDirectChat(${doctor.id_medico}, '${doctor.nome}');">
                                Dr(a). ${doctor.nome} (${doctor.especialidade})
                            </a>
                        `;
                        doctorsListDiv.appendChild(listItem);
                    });
                } else {
                    doctorsListDiv.innerHTML = '<li class="list-group-item text-muted text-center">Nenhum médico disponível para chat.</li>';
                }
            } catch (error) {
                console.error('Erro ao carregar médicos para chat:', error);
                doctorsListDiv.innerHTML = '<div class="list-group-item text-danger text-center">Erro de conexão ao carregar médicos.</div>';
            }
        }

        async function openDirectChat(doctorId, doctorName) {
            currentDirectChatDoctorId = doctorId;
            currentDirectChatDoctorName = doctorName;
            directChatDoctorNameSpan.textContent = doctorName;

            document.getElementById('doctor-list-for-chat').classList.add('d-none');
            document.getElementById('selected-doctor-chat').classList.remove('d-none');
            document.getElementById('selected-doctor-chat').classList.add('d-flex');

            await fetchDirectChatHistory();
            directChatInput.focus();
        }

        async function fetchDirectChatHistory() {
            if (!currentDirectChatDoctorId) return;

            directChatMessagesDiv.innerHTML = '<div class="text-muted text-center">Carregando histórico...</div>';

            try {
                const response = await fetch(`acesspacdata.php?action=get_direct_chat_history&id_paciente=<?php echo $id_paciente_logado; ?>&id_medico=${currentDirectChatDoctorId}`);
                const result = await response.json();

                if (result.success) {
                    directChatMessagesDiv.innerHTML = '';
                    if (result.history.length > 0) {
                        result.history.forEach(msg => {
                            const sender = (msg.tipo_remetente === 'paciente') ? 'user' : 'bot';
                            addMessage(sender, msg.mensagem + `<div class="text-end" style="font-size: 0.75rem; color: ${sender === 'user' ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.5)'};">${new Date(msg.data_envio).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}</div>`, directChatMessagesDiv);
                        });
                    } else {
                        directChatMessagesDiv.innerHTML = '<div class="text-muted text-center">Nenhuma mensagem nesta conversa.</div>';
                    }
                } else {
                    directChatMessagesDiv.innerHTML = `<div class="text-danger text-center">Erro ao carregar histórico: ${result.error}</div>`;
                }
            } catch (error) {
                console.error('Erro ao buscar histórico de chat:', error);
                directChatMessagesDiv.innerHTML = '<div class="text-danger text-center">Erro de conexão ao carregar histórico.</div>';
            }
        }

        async function sendDirectMessage(targetDoctorId, messageContent) {
            if (!targetDoctorId || !messageContent.trim()) return;

            const data = {
                id_remetente: <?php echo json_encode($id_paciente_logado); ?>,
                id_destinatario: targetDoctorId,
                mensagem: messageContent
            };

            try {
                const response = await fetch('acesspacdata.php?action=send_direct_message', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    console.log('Mensagem direta enviada com sucesso!');
                    if (targetDoctorId === currentDirectChatDoctorId) {
                        addMessage('user', messageContent + `<div class="text-end" style="font-size: 0.75rem; color: rgba(255,255,255,0.7);">Agora</div>`, directChatMessagesDiv);
                        directChatInput.value = '';
                    }
                } else {
                    console.error('Erro ao enviar mensagem direta:', result.error);
                    showMessageModal('Erro ao Enviar Mensagem', `Não foi possível enviar sua mensagem: ${result.error}`);
                }
            } catch (error) {
                console.error('Erro de conexão ao enviar mensagem direta:', error);
                showMessageModal('Erro de Conexão', 'Ocorreu um erro ao tentar enviar a mensagem. Verifique sua conexão e tente novamente.');
            }
        }

        sendDirectChatBtn.addEventListener('click', () => {
            const message = directChatInput.value.trim();
            if (message && currentDirectChatDoctorId) {
                sendDirectMessage(currentDirectChatDoctorId, message);
            }
        });

        directChatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendDirectChatBtn.click();
            }
        });

        function showChatMode(mode) {
            const chatbotView = document.getElementById('chatbot-view');
            const directChatView = document.getElementById('direct-chat-view');
            const doctorListForChat = document.getElementById('doctor-list-for-chat');
            const selectedDoctorChat = document.getElementById('selected-doctor-chat');

            if (mode === 'bot') {
                chatbotView.style.display = 'block';
                directChatView.classList.add('d-none');
                selectedDoctorChat.classList.add('d-none');
                selectedDoctorChat.classList.remove('d-flex');
                resetChatState();
                // Limpa o chat e inicia a conversa do bot
                chatMessages.innerHTML = ''; 
                addMessage('bot', botResponses[0]);
            } else if (mode === 'direct') {
                chatbotView.style.display = 'none';
                directChatView.classList.remove('d-none');
                doctorListForChat.classList.remove('d-none');
                selectedDoctorChat.classList.add('d-none');
                selectedDoctorChat.classList.remove('d-flex');
                loadDoctorsForChat();
            }
        }

        let appointmentConfirmationModalInstance;

        async function checkDoctorAvailability(doctorId, date, time, doctorName) {
            try {
                const response = await fetch(`acesspacdata.php?action=check_doctor_availability&id_medico=${doctorId}&data_consulta=${date}&hora_consulta=${time}`);
                const result = await response.json();

                const availabilityStatusElement = document.getElementById('modalAvailabilityStatus');
                const confirmAppointmentButton = document.getElementById('confirmAppointmentBtn');
                const chatWithDoctorButton = document.getElementById('chatWithDoctorBtn');

                document.getElementById('modalDoctorName').textContent = doctorName;
                document.getElementById('modalAppointmentDate').textContent = new Date(date + 'T00:00:00').toLocaleDateString('pt-BR'); // Adiciona T00:00:00 para evitar problemas de fuso horário
                document.getElementById('modalAppointmentTime').textContent = time;

                if (result.success && result.available) {
                    availabilityStatusElement.textContent = "Este horário está disponível!";
                    availabilityStatusElement.classList.remove('text-danger');
                    availabilityStatusElement.classList.add('text-success');
                    confirmAppointmentButton.classList.remove('d-none'); // Exibe o botão de confirmar
                    chatWithDoctorButton.classList.add('d-none'); // Esconde o botão de falar com o médico
                } else {
                    availabilityStatusElement.textContent = `Este horário não está disponível. ${result.reason || 'Por favor, tente outro ou fale com o médico.'}`;
                    availabilityStatusElement.classList.remove('text-success');
                    availabilityStatusElement.classList.add('text-danger');
                    confirmAppointmentButton.classList.add('d-none'); // Esconde o botão de confirmar
                    chatWithDoctorButton.classList.remove('d-none'); // Exibe o botão de falar com o médico
                }

                if (!appointmentConfirmationModalInstance) {
                    appointmentConfirmationModalInstance = new bootstrap.Modal(document.getElementById('appointmentConfirmationModal'));
                }
                appointmentConfirmationModalInstance.show();

            } catch (error) {
                console.error('Erro ao verificar disponibilidade do médico:', error);
                showMessageModal('Erro de Conexão', 'Não foi possível verificar a disponibilidade do médico. Tente novamente.');
            }
        }

        function closeAppointmentConfirmationModal() {
            if (appointmentConfirmationModalInstance) {
                appointmentConfirmationModalInstance.hide();
            }
        }

        document.getElementById('confirmAppointmentBtn').addEventListener('click', () => {
            closeAppointmentConfirmationModal();
            chatState.step = 17;
            const confirmationMessage = botResponses[chatState.step]
                .replace('[NOME]', chatState.nome)
                .replace('[CPF]', chatState.cpf)
                .replace('[IDADE]', chatState.idade)
                .replace('[GENERO]', chatState.genero)
                .replace('[ALERGIAS]', chatState.alergias || 'Nenhuma')
                .replace('[DOENCA_EXISTENTE]', chatState.doenca_existente || 'Nenhuma')
                .replace('[MOTIVO]', chatState.motivo)
                .replace('[URGENCIA]', chatState.urgencia)
                .replace('[ESPECIALIDADE]', chatState.especialidades[0])
                .replace('[NOME_MEDICO]', chatState.nomeMedicoAgendado)
                .replace('[DATA]', new Date(chatState.dataConsulta + 'T00:00:00').toLocaleDateString('pt-BR')) // Adiciona T00:00:00
                .replace('[HORA]', chatState.horaConsulta);
            addMessage('bot', confirmationMessage);
        });

        document.getElementById('chatWithDoctorBtn').addEventListener('click', async () => {
            closeAppointmentConfirmationModal();
            showChatMode('direct');
            await openDirectChat(chatState.idMedicoAgendado, chatState.nomeMedicoAgendado);

            const messageToDoctor = `Olá Dr(a). ${chatState.nomeMedicoAgendado}, gostaria de verificar a disponibilidade para uma consulta em ${new Date(chatState.dataConsulta + 'T00:00:00').toLocaleDateString('pt-BR')} às ${chatState.horaConsulta}.`; // Adiciona T00:00:00
            await sendDirectMessage(chatState.idMedicoAgendado, messageToDoctor);
            addMessage('bot', `Mensagem enviada ao Dr(a). ${chatState.nomeMedicoAgendado}. Você pode continuar a conversa no chat direto.`);
            chatState.step = 0;
        });


        document.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const initialSection = urlParams.get('section') || 'agendar-consulta-chat';
            const initialNavLink = document.getElementById(`nav-${initialSection}`);
            if (initialNavLink) {
                showSection(initialSection, initialNavLink);
            } else {
                showSection('agendar-consulta-chat', document.getElementById('nav-agendar-consulta-chat'));
            }

            document.getElementById('nav-agendar-consulta-chat').addEventListener('click', function(e) {
                e.preventDefault();
                showSection('agendar-consulta-chat', this);
                showChatMode('bot');
            });
            // Removido o listener para 'minhas-receitas' pois não existe mais no menu
            // document.getElementById('nav-minhas-receitas').addEventListener('click', function(e) {
            //     e.preventDefault();
            //     showSection('minhas-receitas', this);
            // });
            document.getElementById('nav-consultas-anteriores').addEventListener('click', function(e) {
                e.preventDefault();
                showSection('consultas-anteriores', this);
            });
            // Removido o listener para 'feedback' pois não existe mais no menu
            // document.getElementById('nav-feedback').addEventListener('click', function(e) {
            //     e.preventDefault();
            //     showSection('feedback', this);
            // });
            document.getElementById('nav-configuracoes').addEventListener('click', function(e) {
                e.preventDefault();
                showSection('configuracoes', this);
            });

            calculateAge();

            showChatMode('bot');
        });

    </script>
</body>
</html>