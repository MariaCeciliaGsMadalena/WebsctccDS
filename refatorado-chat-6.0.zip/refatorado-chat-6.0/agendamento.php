<?php
session_start(); // Inicia a sessão PHP
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

$patientsData = []; // Inicializa um array vazio para os dados dos pacientes

// Verifica se a conexão com o banco de dados foi estabelecida
if (isset($conn) && $conn->ping()) { // $conn é definida em conexao.php
    // Prepara a consulta SQL para buscar nome, cpf e data_nascimento da tabela 'pacientes'
    $sql = "SELECT nome, cpf, data_nascimento FROM pacientes";
    $result = $conn->query($sql); // Executa a consulta

    if ($result->rowCount() > 0) {
        // Se houver resultados, itera sobre eles e os adiciona ao array $patientsData
        while($row = $result->fetch(PDO::FETCH_ASSOC)) {
            // Concatena nome e sobrenome (se houver) para formar o nome completo
            // No seu SQL dump, a tabela 'pacientes' tem apenas 'nome', então usamos apenas 'nome'
            $fullName = $row['nome']; 
            $patientsData[] = [
                'nomeCompleto' => $fullName,
                'cpf' => $row['cpf'],
                'dataNascimento' => $row['data_nascimento']
            ];
        }
    }
    $conn->close(); // Fecha a conexão com o banco de dados
} else {
    // Exibe um erro se a conexão não foi bem-sucedida (apenas para depuração)
    error_log("Erro: Conexão com o banco de dados não estabelecida em agendamento.php");
}

// Converte os dados dos pacientes para JSON para serem usados no JavaScript
$patientsDataJson = json_encode($patientsData);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Agendamento Médico</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      /* Define um fundo gradiente suave para o corpo da página */
      background: linear-gradient(to right, #e0f7fa, #b2ebf2);
    }
    /* Estilo para ocultar e mostrar descrições */
    .slide {
      display: none;
    }
    .active {
      display: block;
    }
  </style>
  <script>
   // Função para alternar a visibilidade da descrição e o ícone de cada especialidade
  function toggleDesc(id) {
    const desc = document.getElementById(id); // Pega o elemento da descrição
    const icon = document.getElementById(id.replace('Desc', 'Icon')); // Pega o elemento do ícone
    if (desc.classList.contains('hidden')) {
      desc.classList.remove('hidden'); // Remove a classe 'hidden' para mostrar a descrição
      icon.classList.remove('bi-plus-lg'); // Troca o ícone de '+' para '-'
      icon.classList.add('bi-dash-lg');
    } else {
      desc.classList.add('hidden'); // Adiciona a classe 'hidden' para ocultar a descrição
      icon.classList.remove('bi-dash-lg'); // Troca o ícone de '-' para '+'
      icon.classList.add('bi-plus-lg');
    }
  }

  // Dados de pacientes carregados dinamicamente do PHP
  // O PHP irá preencher esta variável com os dados do banco de dados
  const patientsData = <?php echo $patientsDataJson; ?>;

  // Função para calcular a idade a partir da data de nascimento
  function calculateAge(birthDate) {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  }

  // Função para autopreencher os campos do paciente
  function autofillPatientData() {
    // Pega o valor do campo nome e sobrenome, e combina para formar o nome completo
    const nome = document.getElementById('nome').value.trim();
    // No seu SQL dump, a tabela 'pacientes' tem apenas 'nome', então o sobrenome pode ser ignorado na busca.
    // No entanto, mantemos o campo sobrenome no formulário se você planeja usá-lo para outros fins.
    const sobrenome = document.getElementById('sobrenome').value.trim();
    const fullName = `${nome} ${sobrenome}`.trim(); 

    const cpfInput = document.getElementById('cpf');
    const idadeInput = document.getElementById('idade');
    const dataNascimentoInput = document.getElementById('dataNascimento');

    // Limpa os valores anteriores dos campos
    cpfInput.value = '';
    idadeInput.value = '';
    dataNascimentoInput.value = '';

    if (fullName.length > 0) {
      // Procura um paciente que corresponda ao nome completo digitado (ignorando maiúsculas/minúsculas)
      const foundPatient = patientsData.find(patient =>
        patient.nomeCompleto.toLowerCase() === fullName.toLowerCase()
      );

      if (foundPatient) {
        // Preenche os campos se um paciente for encontrado
        cpfInput.value = foundPatient.cpf;
        dataNascimentoInput.value = foundPatient.dataNascimento;
        idadeInput.value = calculateAge(foundPatient.dataNascimento);
      }
    }
  }
  </script>
</head>
<body class="font-sans text-gray-800">

  <!-- Seção de Agendamento -->
  <section id="agendamento" class="max-w-xl mx-auto p-4">
    <h2 class="text-xl font-semibold mb-4 text-center text-blue-700"><i class="fas fa-calendar-check"></i> Agendamento Médico</h2>
    <!-- O formulário envia os dados para 'gerar_comprovante.php' -->
    <form action="gerar_comprovante.php" method="POST" class="bg-white p-6 rounded-lg shadow-lg space-y-4">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Nome</label>
          <!-- Adicionado id e oninput para autopreenchimento -->
          <input name="nome" id="nome" placeholder="Nome" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required oninput="autofillPatientData()">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Sobrenome</label>
          <!-- Adicionado id e oninput para autopreenchimento -->
          <input name="sobrenome" id="sobrenome" placeholder="Sobrenome" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required oninput="autofillPatientData()">
        </div>
      </div>
      
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Idade</label>
          <!-- Adicionado id para autopreenchimento e readonly para evitar edição manual -->
          <input name="idade" id="idade" type="number" placeholder="Idade" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required readonly>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">CPF</label>
          <!-- Adicionado id para autopreenchimento e readonly para evitar edição manual -->
          <input name="cpf" id="cpf" placeholder="CPF" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required readonly>
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Data de Nascimento</label>
        <!-- Novo campo para Data de Nascimento, adicionado id e readonly -->
        <input name="data_nascimento" id="dataNascimento" type="date" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required readonly>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Motivo da Consulta</label>
        <input name="motivo" placeholder="Motivo da Consulta" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nível de Urgência</label>
        <select name="urgencia" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
          <option value="">Selecione</option>
          <option value="Baixa">Baixa</option>
          <option value="Média">Média</option>
          <option value="Alta">Alta</option>
          <option value="Emergência">Emergência</option>
        </select>
      </div>

      <div>
        <p class="mb-2 font-medium text-gray-700">Especialidades:</p>
        <div class="grid grid-cols-2 gap-4">
          
          <!-- Cardiologia -->
          <div class="bg-blue-50 p-4 rounded-lg border border-blue-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('cardioDesc')">
              <div class="flex items-center">
                <i class="bi bi-heart-pulse text-blue-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Cardiologia" class="mr-2 align-middle"> Cardiologia
                </label>
              </div>
              <i id="cardioIcon" class="bi bi-plus-lg text-blue-600 text-xl"></i>
            </div>
            <p id="cardioDesc" class="mt-2 text-blue-700 text-sm hidden">
              Cardiologia é a especialidade médica que cuida do diagnóstico e tratamento das doenças do coração e do sistema circulatório.
            </p>
          </div>
      
          <!-- Urologia -->
          <div class="bg-green-50 p-4 rounded-lg border border-green-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('uroDesc')">
              <div class="flex items-center">
                <i class="bi bi-gender-male text-green-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Urologia" class="mr-2 align-middle"> Urologia
                </label>
              </div>
              <i id="uroIcon" class="bi bi-plus-lg text-green-600 text-xl"></i>
            </div>
            <p id="uroDesc" class="mt-2 text-green-700 text-sm hidden">
              Urologia é a especialidade médica que trata do sistema urinário e do sistema reprodutor masculino.
            </p>
          </div>
      
          <!-- Dermatologia -->
          <div class="bg-red-50 p-4 rounded-lg border border-red-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('dermaDesc')">
              <div class="flex items-center">
                <i class="bi bi-patch-check text-red-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Dermatologia" class="mr-2 align-middle"> Dermatologia
                </label>
              </div>
              <i id="dermaIcon" class="bi bi-plus-lg text-red-600 text-xl"></i>
            </div>
            <p id="dermaDesc" class="mt-2 text-red-700 text-sm hidden">
              Dermatologia é o ramo da medicina que estuda, diagnostica e trata doenças da pele, cabelo e unhas.
            </p>
          </div>
      
          <!-- Oftalmologia -->
          <div class="bg-purple-50 p-4 rounded-lg border border-purple-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('oftalmoDesc')">
              <div class="flex items-center">
                <i class="bi bi-eye text-purple-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Oftalmologia" class="mr-2 align-middle"> Oftalmologia
                </label>
              </div>
              <i id="oftalmoIcon" class="bi bi-plus-lg text-purple-600 text-xl"></i>
            </div>
            <p id="oftalmoDesc" class="mt-2 text-purple-700 text-sm hidden">
              Oftalmologia trata das doenças e cuidados dos olhos, incluindo exames, cirurgias e correções visuais.
            </p>
          </div>
      
          <!-- Ortopedia -->
          <div class="bg-orange-50 p-4 rounded-lg border border-orange-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('ortopediaDesc')">
              <div class="flex items-center">
                <i class="bi bi-bandaid text-orange-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Ortopedia" class="mr-2 align-middle"> Ortopedia
                </label>
              </div>
              <i id="ortopediaIcon" class="bi bi-plus-lg text-orange-600 text-xl"></i>
            </div>
            <p id="ortopediaDesc" class="mt-2 text-orange-700 text-sm hidden">
              Ortopedia cuida das doenças e lesões do sistema musculoesquelético, como ossos, articulações e músculos.
            </p>
          </div>
      
          <!-- Ginecologia -->
          <div class="bg-pink-50 p-4 rounded-lg border border-pink-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('ginecoDesc')">
              <div class="flex items-center">
                <i class="bi bi-gender-female text-pink-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Ginecologia" class="mr-2 align-middle"> Ginecologia
                </label>
              </div>
              <i id="ginecoIcon" class="bi bi-plus-lg text-pink-600 text-xl"></i>
            </div>
            <p id="ginecoDesc" class="mt-2 text-pink-700 text-sm hidden">
              Ginecologia é a especialidade médica que cuida da saúde do sistema reprodutor feminino.
            </p>
          </div>
      
          <!-- Clínico Geral -->
          <div class="bg-teal-50 p-4 rounded-lg border border-teal-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('clinicoDesc')">
              <div class="flex items-center">
                <i class="bi bi-file-earmark-medical text-teal-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Clínico Geral" class="mr-2 align-middle"> Clínico Geral
                </label>
              </div>
              <i id="clinicoIcon" class="bi bi-plus-lg text-teal-600 text-xl"></i>
            </div>
            <p id="clinicoDesc" class="mt-2 text-teal-700 text-sm hidden">
              O clínico geral é o médico que faz o primeiro atendimento e encaminha para especialistas quando necessário.
            </p>
          </div>
      
          <!-- Endocrinologia -->
          <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('endocrinoDesc')">
              <div class="flex items-center">
                <i class="bi bi-clipboard-pulse text-yellow-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Endocrinologia" class="mr-2 align-middle"> Endocrinologia
                </label>
              </div>
              <i id="endocrinoIcon" class="bi bi-plus-lg text-yellow-600 text-xl"></i>
            </div>
            <p id="endocrinoDesc" class="mt-2 text-yellow-700 text-sm hidden">
              Endocrinologia trata dos hormônios e glândulas, como diabetes e distúrbios metabólicos.
            </p>
          </div>
        </div>
      </div>

      <button type="submit" class="w-full bg-blue-600 text-white p-3 rounded-md hover:bg-blue-700 transition-colors duration-300 flex items-center justify-center gap-2">
        <i class="fas fa-file-pdf"></i> Gerar Comprovante
      </button>
    </form>
  </section>

</body>
</html>
