<?php
// Habilita a exibição de todos os erros PHP para depuração.
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include_once 'conexao.php'; // Inclui o arquivo de conexão

header('Content-Type: application/json'); // Define o cabeçalho para indicar que a resposta é JSON.

$response = ['success' => false, 'error' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Verifica se os dados foram recebidos corretamente
    if (json_last_error() !== JSON_ERROR_NONE) {
        $response['error'] = 'Erro ao decodificar JSON: ' . json_last_error_msg();
        echo json_encode($response);
        exit;
    }

    $id_paciente = $_SESSION['usuario']['id_paciente'] ?? null;

    if (!$id_paciente) {
        $response['error'] = 'ID do paciente não encontrado na sessão.';
        echo json_encode($response);
        exit;
    }

    // Coleta os dados do formulário
    $queixa_principal = $data['queixa_principal'] ?? null;
    $tempo_queixa = $data['tempo_queixa'] ?? null;
    $medicamentos_alergias = $data['medicamentos_alergias'] ?? null;
    $historico_doencas_cirurgias_familia = $data['historico_doencas_cirurgias_familia'] ?? null;
    $sintomas_atuais_detalhes = $data['sintomas_atuais_detalhes'] ?? null;
    $rotina_estilo_vida = $data['rotina_estilo_vida'] ?? null;

    try {
        $pdo = getPdoConnection();

        // Prepara a consulta SQL para inserir os dados na tabela pre_consultas
        $sql = "INSERT INTO pre_consultas (id_paciente, queixa_principal, tempo_queixa, medicamentos_alergias, historico_doencas_cirurgias_familia, sintomas_atuais_detalhes, rotina_estilo_vida)
                VALUES (:id_paciente, :queixa_principal, :tempo_queixa, :medicamentos_alergias, :historico_doencas_cirurgias_familia, :sintomas_atuais_detalhes, :rotina_estilo_vida)";
        
        $stmt = $pdo->prepare($sql);

        // Binda os parâmetros
        $stmt->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
        $stmt->bindParam(':queixa_principal', $queixa_principal, PDO::PARAM_STR);
        $stmt->bindParam(':tempo_queixa', $tempo_queixa, PDO::PARAM_STR);
        $stmt->bindParam(':medicamentos_alergias', $medicamentos_alergias, PDO::PARAM_STR);
        $stmt->bindParam(':historico_doencas_cirurgias_familia', $historico_doencas_cirurgias_familia, PDO::PARAM_STR);
        $stmt->bindParam(':sintomas_atuais_detalhes', $sintomas_atuais_detalhes, PDO::PARAM_STR);
        $stmt->bindParam(':rotina_estilo_vida', $rotina_estilo_vida, PDO::PARAM_STR);

        // Executa a consulta
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Pré-consulta salva com sucesso!';
        } else {
            $response['error'] = 'Erro ao executar a inserção no banco de dados.';
        }

    } catch (PDOException $e) {
        $response['error'] = 'Erro de banco de dados: ' . $e->getMessage();
        error_log("Erro ao salvar pré-consulta: " . $e->getMessage());
    } catch (Exception $e) {
        $response['error'] = 'Erro geral: ' . $e->getMessage();
        error_log("Erro geral ao salvar pré-consulta: " . $e->getMessage());
    }
} else {
    $response['error'] = 'Método de requisição inválido.';
}

echo json_encode($response);
?>
