<?php
// Arquivo: conexao.php

// Definições de conexão com o banco de dados
define('DB_SERVER', 'localhost'); // Geralmente 'localhost' para USBWebserver
define('DB_DATABASE', 'agilixmdtechbd');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'usbw'); // Senha do seu USBWebserver

/**
 * Estabelece e retorna uma conexão PDO com o banco de dados.
 *
 * @return PDO Objeto PDO de conexão com o banco de dados.
 * @throws PDOException Se houver um erro na conexão com o banco de dados.
 */
function getPdoConnection() {
    $host = DB_SERVER;
    $db = DB_DATABASE;
    $user = DB_USERNAME;
    $pass = DB_PASSWORD;
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Lança exceções em caso de erro
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Define o modo de busca padrão como array associativo
        PDO::ATTR_EMULATE_PREPARES   => false,                  // Desativa a emulação de prepared statements para melhor segurança e desempenho
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
        // Opcional: Para depuração, pode-se logar a conexão bem-sucedida, mas evite em produção para não expor detalhes.
        // error_log('Conexão PDO bem-sucedida!');
        return $pdo;
    } catch (\PDOException $e) {
        // Registra o erro detalhado no log de erros do servidor
        error_log("Erro de conexão PDO: " . $e->getMessage() . " - Código: " . $e->getCode());
        // Lança uma nova exceção PDO para ser capturada pelo script que chamou getPdoConnection()
        // Isso permite que o script chamador (e.g., acesspacdata.php) trate o erro de forma apropriada.
        throw new \PDOException("Não foi possível conectar ao banco de dados. Por favor, tente novamente mais tarde.", (int)$e->getCode());
    }
}

// Removido o bloco try-catch direto aqui, pois a função getPdoConnection() já lida com a conexão
// e lança uma exceção que deve ser tratada pelo script que a chama (acesspacdata.php).
?>

