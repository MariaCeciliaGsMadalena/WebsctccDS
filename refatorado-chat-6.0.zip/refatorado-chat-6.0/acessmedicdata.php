<?php
// Habilita a exibição de todos os erros PHP para depuração.
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
// Inclui o arquivo de conexão com o banco de dados.
include_once 'conexao.php';
// Inclui o controlador de chat, que contém funções para enviar e buscar mensagens.
include_once 'chat_controller.php'; // Certifique-se de que este caminho está correto

// Verifica se o usuário está logado e se o tipo de usuário é 'medico'.
if (!isset($_SESSION['usuario']) || (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] !== 'medico')) {
    header('Location: login.php');
    exit;
}

// Obtém os dados do médico logado
$nome_medico = 'Dr(a). ' . htmlspecialchars($_SESSION['usuario']['nome'] ?? '');
$especialidade_medico = htmlspecialchars($_SESSION['usuario']['especialidade'] ?? '');
$crm_medico = htmlspecialchars($_SESSION['usuario']['crm'] ?? '');
$id_medico_logado = $_SESSION['usuario']['id_medico'] ?? null;

// Inicializa a conexão PDO
try {
    $pdo = getPdoConnection(); // Usando a função do chat_controller.php
} catch (Exception $e) {
    error_log("Erro ao conectar ao banco de dados em acessmedicdata.php: " . $e->getMessage());
    echo "<h1>Erro de Conexão com o Banco de Dados</h1>";
    echo "<p>Não foi possível conectar ao banco de dados. Por favor, verifique as configurações de conexão e tente novamente. Detalhes: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}

// --- Lógica para requisições AJAX ---
if (isset($_GET['action'])) {
    header('Content-Type: application/json'); // Garante que a resposta seja JSON

    try {
        if ($_GET['action'] === 'get_horarios_atendimento') {
            // Busca horários de atendimento para o médico logado
            $sql = "SELECT id_horario, dia_semana, hora_inicio, hora_fim, em_almoco, indisponivel_temporariamente
                    FROM horarios_atendimento_medico
                    WHERE id_medico = :id_medico
                    ORDER BY FIELD(dia_semana, 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo'), hora_inicio ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':id_medico' => $id_medico_logado]);
            $horarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'horarios' => $horarios]);
            exit;

        } elseif ($_GET['action'] === 'add_horario_atendimento' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $dia_semana = $data['dia_semana'] ?? '';
            $hora_inicio = $data['hora_inicio'] ?? '';
            $hora_fim = $data['hora_fim'] ?? '';
            $em_almoco = $data['em_almoco'] ?? 0;
            $indisponivel_temporariamente = $data['indisponivel_temporariamente'] ?? 0;

            if ($id_medico_logado && !empty($dia_semana) && !empty($hora_inicio) && !empty($hora_fim)) {
                $sql = "INSERT INTO horarios_atendimento_medico (id_medico, dia_semana, hora_inicio, hora_fim, em_almoco, indisponivel_temporariamente)
                        VALUES (:id_medico, :dia_semana, :hora_inicio, :hora_fim, :em_almoco, :indisponivel_temporariamente)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':id_medico' => $id_medico_logado,
                    ':dia_semana' => $dia_semana,
                    ':hora_inicio' => $hora_inicio,
                    ':hora_fim' => $hora_fim,
                    ':em_almoco' => $em_almoco,
                    ':indisponivel_temporariamente' => $indisponivel_temporariamente
                ]);
                echo json_encode(['success' => true, 'id_horario' => $pdo->lastInsertId()]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Dados incompletos para adicionar horário.']);
            }
            exit;

        } elseif ($_GET['action'] === 'remove_horario_atendimento' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $id_horario = $data['id_horario'] ?? null;

            if ($id_horario && $id_medico_logado) {
                // Garante que o médico só pode remover seus próprios horários
                $sql = "DELETE FROM horarios_atendimento_medico WHERE id_horario = :id_horario AND id_medico = :id_medico";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':id_horario' => $id_horario,
                    ':id_medico' => $id_medico_logado
                ]);
                if ($stmt->rowCount() > 0) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Horário não encontrado ou não pertence a este médico.']);
                }
            } else {
                echo json_encode(['success' => false, 'error' => 'ID do horário ausente.']);
            }
            exit;
        } elseif ($_GET['action'] === 'get_horarios_data_especifica') {
            $data_especifica = $_GET['data'] ?? '';
            $horarios = [];

            if ($id_medico_logado && !empty($data_especifica)) {
                $sql = "SELECT id_horario_data, hora_inicio, hora_fim, em_almoco, indisponivel_temporariamente, observacao
                        FROM horarios_data_especifica
                        WHERE id_medico = :id_medico AND data_atendimento = :data_atendimento
                        ORDER BY hora_inicio ASC";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':id_medico' => $id_medico_logado,
                    ':data_atendimento' => $data_especifica
                ]);
                $horarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            echo json_encode(['success' => true, 'horarios' => $horarios]);
            exit;
        } elseif ($_GET['action'] === 'add_horario_data_especifica' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $data_atendimento = $data['data_atendimento'] ?? '';
            $hora_inicio = $data['hora_inicio'] ?? '';
            $hora_fim = $data['hora_fim'] ?? '';
            $em_almoco = $data['em_almoco'] ?? 0;
            $indisponivel_temporariamente = $data['indisponivel_temporariamente'] ?? 0;
            $observacao = $data['observacao'] ?? '';

            if ($id_medico_logado && !empty($data_atendimento) && !empty($hora_inicio) && !empty($hora_fim)) {
                $sql = "INSERT INTO horarios_data_especifica (id_medico, data_atendimento, hora_inicio, hora_fim, em_almoco, indisponivel_temporariamente, observacao)
                        VALUES (:id_medico, :data_atendimento, :hora_inicio, :hora_fim, :em_almoco, :indisponivel_temporariamente, :observacao)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':id_medico' => $id_medico_logado,
                    ':data_atendimento' => $data_atendimento,
                    ':hora_inicio' => $hora_inicio,
                    ':hora_fim' => $hora_fim,
                    ':em_almoco' => $em_almoco,
                    ':indisponivel_temporariamente' => $indisponivel_temporariamente,
                    ':observacao' => $observacao
                ]);
                echo json_encode(['success' => true, 'id_horario_data' => $pdo->lastInsertId()]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Dados incompletos para adicionar horário por data.']);
            }
            exit;
        } elseif ($_GET['action'] === 'remove_horario_data_especifica' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $id_horario_data = $data['id_horario_data'] ?? null;

            if ($id_horario_data && $id_medico_logado) {
                $sql = "DELETE FROM horarios_data_especifica WHERE id_horario_data = :id_horario_data AND id_medico = :id_medico";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':id_horario_data' => $id_horario_data,
                    ':id_medico' => $id_medico_logado
                ]);
                if ($stmt->rowCount() > 0) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Horário não encontrado ou não pertence a este médico.']);
                }
            } else {
                echo json_encode(['success' => false, 'error' => 'ID do horário ausente.']);
            }
            exit;
        }

    } catch (PDOException $e) {
        error_log("Erro de PDO em acessmedicdata.php (AJAX): " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Erro de banco de dados: ' . $e->getMessage()]);
        exit;
    } catch (Exception $e) {
        error_log("Erro geral em acessmedicdata.php (AJAX): " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// --- Lógica do chat (mantida como estava) ---
$id_paciente_selecionado = $_GET['id_paciente'] ?? null;
$nome_paciente_selecionado = '';
$mensagens = [];
$pacientes_disponiveis = []; // Para a lista de pacientes na caixa de entrada e no modal
$unread_counts_by_patient = []; // Inicializa o array para contagens de mensagens não lidas

// Processar o envio de mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $id_remetente = $id_medico_logado;
    $id_destinatario = $_POST['id_paciente'];
    $mensagem = $_POST['mensagem'];
    $tipo_remetente = 'medico';
    $tipo_destinatario = 'paciente';

    if (!empty($mensagem) && $id_remetente && $id_destinatario) {
        sendChatMessage($pdo, $id_remetente, $tipo_remetente, $id_destinatario, $tipo_destinatario, $mensagem);
        header("Location: acessmedicdata.php?section=chat-comunicacao&id_paciente=" . $id_destinatario);
        exit();
    }
}

// Obter a lista de todos os pacientes para o médico selecionar
try {
    $sql = "SELECT p.id_paciente, p.nome, p.cpf
            FROM pacientes p
            ORDER BY p.nome ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $pacientes_disponiveis = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obter contagens de mensagens não lidas para o médico logado
    $unread_result = getUnreadMessageCounts($pdo, $id_medico_logado, 'medico');
    if ($unread_result['success']) {
        foreach ($unread_result['unread_counts'] as $count_data) {
            // Verifica se o remetente é um paciente antes de adicionar à contagem
            if ($count_data['tipo_remetente'] === 'paciente') {
                $unread_counts_by_patient[$count_data['id_remetente']] = $count_data['count'];
            }
        }
    } else {
        error_log("Erro ao carregar contagens de mensagens não lidas: " . ($unread_result['error'] ?? 'Erro desconhecido'));
    }

} catch (PDOException $e) {
    error_log("Erro ao buscar pacientes ou contagens de mensagens: " . $e->getMessage());
}

// Se um paciente foi selecionado, obter o nome e o histórico da conversa
if ($id_paciente_selecionado && $id_medico_logado) {
    $sql_paciente_nome = "SELECT nome FROM pacientes WHERE id_paciente = ?";
    $stmt_paciente_nome = $pdo->prepare($sql_paciente_nome);
    $stmt_paciente_nome->execute([$id_paciente_selecionado]);
    $paciente = $stmt_paciente_nome->fetch(PDO::FETCH_ASSOC);
    $nome_paciente_selecionado = htmlspecialchars($paciente['nome'] ?? 'Paciente');

    $chat_result = getChatHistory($pdo, $id_medico_logado, 'medico', $id_paciente_selecionado, 'paciente');
    if ($chat_result['success']) {
        $mensagens = $chat_result['history'];
    } else {
        error_log("Erro ao carregar histórico do chat: " . ($chat_result['error'] ?? 'Erro desconhecido'));
    }
}
// --- Fim da lógica do chat ---

// Determina a seção ativa para o carregamento inicial da página
$activeSection = $_GET['section'] ?? 'chat-comunicacao'; // Define o chat como seção inicial
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Médico - Aglix MedTech</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- FullCalendar CSS -->
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/main.min.css' rel='stylesheet' />
    <style>
        /* Estilos personalizados para elementos Bootstrap não cobertos pelo Tailwind */
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: var(--bs-light-bg-subtle); /* Fundo Bootstrap 5.3 */
            color: var(--bs-body-color);
        }

        /* Modo escuro para elementos Bootstrap */
        .dark-mode {
            background-color: #1a202c; /* Fundo escuro para o modo dark */
            color: #e2e8f0; /* Texto no modo dark */
        }
        .dark-mode .card, .dark-mode .bg-light {
            background-color: #2d3748 !important; /* Cor de card no modo dark */
            color: #e2e8f0;
        }
        .dark-mode .form-control, .dark-mode .form-select {
            background-color: #2d3748;
            color: #e2e8f0;
            border-color: #4a5568;
        }
        .dark-mode .form-control:focus, .dark-mode .form-select:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
        }
        .dark-mode .text-muted {
            color: #a0aec0 !important;
        }
        .dark-mode .border-secondary {
            border-color: #4a5568 !important;
        }
        .dark-mode .list-group-item {
            background-color: #2d3748;
            color: #e2e8f0;
        }
        .dark-mode .list-group-item:hover {
            background-color: #4a5568 !important;
        }
        /* Cores de botões/texto Bootstrap no modo escuro */
        .dark-mode .btn-primary {
            background-color: #3b82f6;
            border-color: #3b82f6;
        }
        .dark-mode .btn-primary:hover {
            background-color: #2563eb;
            border-color: #2563eb;
        }
        .dark-mode .btn-outline-primary {
            color: #3b82f6;
            border-color: #3b82f6;
        }
        .dark-mode .btn-outline-primary:hover {
            background-color: #3b82f6;
            color: white;
        }
        .dark-mode .text-primary {
            color: #3b82f6 !important;
        }
        .dark-mode .text-secondary-bootstrap { /* Classe personalizada para cor secundária no modo escuro */
            color: #8b5cf6 !important;
        }
        .dark-mode .text-danger {
            color: #ef4444 !important;
        }
        .dark-mode .text-success {
            color: #22c55e !important;
        }
        .dark-mode .text-warning {
            color: #f59e0b !important;
        }
        /* Cores de fundo Bootstrap-like para cartões específicos */
        .dark-mode .bg-info-subtle {
            background-color: rgba(59, 130, 246, 0.2) !important;
            border-color: rgba(59, 130, 246, 0.4) !important;
        }
        .dark-mode .bg-success-subtle {
            background-color: rgba(34, 197, 94, 0.2) !important;
            border-color: rgba(34, 197, 94, 0.4) !important;
        }
        .dark-mode .bg-danger-subtle {
            background-color: rgba(239, 68, 68, 0.2) !important;
            border-color: rgba(239, 68, 68, 0.4) !important;
        }
        .dark-mode .bg-purple-subtle {
            background-color: rgba(139, 92, 246, 0.2) !important;
            border-color: rgba(139, 92, 246, 0.4) !important;
        }
        .dark-mode .bg-warning-subtle {
            background-color: rgba(249, 115, 22, 0.2) !important;
            border-color: rgba(249, 115, 22, 0.4) !important;
        }
        .dark-mode .bg-pink-subtle {
            background-color: rgba(236, 72, 153, 0.2) !important;
            border-color: rgba(236, 72, 153, 0.4) !important;
        }
        .dark-mode .bg-teal-subtle {
            background-color: rgba(20, 184, 166, 0.2) !important;
            border-color: rgba(20, 184, 166, 0.4) !important;
        }
        .dark-mode .bg-yellow-subtle {
            background-color: rgba(234, 179, 8, 0.2) !important;
            border-color: rgba(234, 179, 8, 0.4) !important;
        }


        /* Ajustes para o formulário de agendamento de consulta */
        #agendar-consulta .row > div {
            margin-bottom: 1rem;
        }
        #agendar-consulta .row > div:last-child {
            margin-bottom: 0;
        }

        /* Largura personalizada da barra lateral (ainda necessária para largura em pixels específica) */
        .sidebar-custom-width {
            width: 100%; /* Padrão para telas pequenas */
        }
        @media (min-width: 768px) { /* breakpoint md */
            .sidebar-custom-width {
                width: 200px; /* Largura fixa ligeiramente maior para desktop */
            }
        }

        /* Estado ativo Tailwind-like para itens da barra lateral */
        .sidebar-item.sidebar-active {
            background-color: #3b82f6; /* Tailwind blue-500 */
            color: white !important;
            font-weight: 600; /* font-semibold */
        }
        .dark-mode .sidebar-item.sidebar-active {
            background-color: #2563eb; /* Tailwind blue-700 */
        }

        /* Estilos do Chat */
        .chat-container {
            display: flex;
            flex-direction: column;
            height: 70vh; /* Ajuste conforme necessário */
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            overflow: hidden;
        }

        .chat-messages {
            flex-grow: 1;
            overflow-y: auto;
            padding: 1rem;
            background-color: #f8fafc; /* Tailwind gray-50 */
        }

        .chat-message-bubble {
            max-width: 80%;
            padding: 0.75rem 1rem;
            border-radius: 1.25rem;
            margin-bottom: 0.5rem;
            word-wrap: break-word;
        }

        .chat-message-user { /* Para mensagens enviadas pelo usuário (médico neste contexto) */
            background-color: #3b82f6; /* Tailwind blue-500 */
            color: white;
            align-self: flex-end;
            margin-left: auto;
        }

        .chat-message-other { /* Para mensagens recebidas (do paciente neste contexto) */
            background-color: #e2e8f0; /* Tailwind gray-200 */
            color: #1a202c; /* Tailwind gray-900 */
            align-self: flex-start;
            margin-right: auto;
        }

        .dark-mode .chat-messages {
            background-color: #2d3748; /* Tailwind gray-800 */
        }

        .dark-mode .chat-message-other {
            background-color: #4a5568; /* Tailwind gray-600 */
            color: #e2e8f0; /* Tailwind gray-200 */
        }

        .chat-input-area {
            display: flex;
            padding: 1rem;
            border-top: 1px solid #e2e8f0;
            background-color: #fff;
            /* Adicionado para centralizar e alinhar o input e o botão */
            justify-content: center; /* Centraliza horizontalmente */
            align-items: center; /* Alinha verticalmente */
            gap: 0.5rem; /* Espaçamento entre o input e o botão */
        }

        .dark-mode .chat-input-area {
            background-color: #2d3748;
            border-top-color: #4a5568;
        }

        .chat-input-area input {
            flex-grow: 1;
            border: 1px solid #cbd5e0; /* Tailwind gray-300 */
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            outline: none;
            /* Ajuste para largura máxima e para não quebrar o layout */
            max-width: calc(100% - 70px); /* Largura do input menos a largura aproximada do botão + gap */
        }

        .dark-mode .chat-input-area input {
            background-color: #4a5568;
            border-color: #64748b; /* Tailwind gray-500 */
            color: #e2e8f0;
        }

        .chat-input-area button {
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            /* margin-left: 0.5rem; Removido, usando gap no flexbox */
            cursor: pointer;
            transition: background-color 0.2s;
            /* Ajustes para o botão */
            flex-shrink: 0; /* Impede que o botão encolha */
            min-width: 60px; /* Largura mínima para o botão */
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
        }

        .chat-input-area button:hover {
            background-color: #2563eb;
        }

        /* FullCalendar adjustments */
        .fc .fc-button-primary {
            background-color: #3b82f6;
            border-color: #3b82f6;
        }
        .fc .fc-button-primary:hover {
            background-color: #2563eb;
            border-color: #2563eb;
        }
        .fc .fc-button-primary:focus {
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
        }
        .dark-mode .fc-theme-standard .fc-scrollgrid,
        .dark-mode .fc-theme-standard td,
        .dark-mode .fc-theme-standard th {
            border-color: #4a5568;
        }
        .dark-mode .fc-daygrid-day-number {
            color: #e2e8f0;
        }
        .dark-mode .fc-col-header-cell-cushion {
            color: #e2e8f0;
        }
        .dark-mode .fc-toolbar-title {
            color: #e2e8f0;
        }
        .dark-mode .fc-button {
            background-color: #4a5568;
            border-color: #4a5568;
            color: #e2e8f0;
        }
        .dark-mode .fc-button:hover {
            background-color: #64748b;
            border-color: #64748b;
        }
        .dark-mode .fc-day-today {
            background-color: #3b82f620 !important; /* Light blue background for today */
        }
        .dark-mode .fc-daygrid-day-frame {
            background-color: #2d3748;
        }

        /* Styles for selected date in calendar */
        .fc-daygrid-day.fc-day-selected {
            background-color: #bfdbfe; /* Tailwind blue-200 */
            border: 2px solid #3b82f6; /* Tailwind blue-500 */
        }
        .dark-mode .fc-daygrid-day.fc-day-selected {
            background-color: #1e3a8a; /* Darker blue for dark mode */
            border: 2px solid #3b82f6;
        }
    </style>
</head>

<body class="bg-light">

    <div class="d-flex flex-column flex-md-row min-vh-100">

        <aside class="sidebar-custom-width bg-white shadow-lg flex flex-col p-4 md:p-4 sticky top-0 h-screen z-50 transition-all duration-300 dark:bg-gray-800">
            <div class="flex flex-col items-center border-b border-gray-300 pb-4 mb-4 flex-shrink-0 dark:border-gray-700">
              
                <h2 class="text-xl font-bold mt-3 text-gray-800 dark:text-gray-200"><?php echo $nome_medico; ?></h2>
                <p class="text-sm text-gray-500 mt-2 dark:text-gray-400">
                    <i class="fas fa-user-md mr-1"></i> <?php echo $especialidade_medico; ?>
                </p>
                <p class="text-sm text-gray-500 mt-1 dark:text-gray-400">
                    <i class="fas fa-id-badge mr-1"></i> CRM: <?php echo $crm_medico; ?>
                </p>
            </div>
            <nav class="flex flex-col flex-grow overflow-y-auto">
                <a href="?section=chat-comunicacao" id="nav-chat-comunicacao" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700 mb-2 <?php echo ($activeSection == 'chat-comunicacao') ? 'sidebar-active' : ''; ?>">
                    <i class="fas fa-comments text-xl"></i> <span class="text-base">Chat com Pacientes</span>
                </a>
                <a href="?section=horarios-atendimento" id="nav-horarios-atendimento" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700 mb-2 <?php echo ($activeSection == 'horarios-atendimento') ? 'sidebar-active' : ''; ?>">
                    <i class="fas fa-clock text-xl"></i> <span class="text-base">Horários de Atendimento</span>
                </a>
                <a href="?section=configuracoes" id="nav-configuracoes" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700 mb-2 <?php echo ($activeSection == 'configuracoes') ? 'sidebar-active' : ''; ?>">
                    <i class="fas fa-cogs text-xl"></i> <span class="text-base">Configurações</span>
                </a>
            </nav>

            <div class="mt-auto pt-4 border-t border-gray-300 flex-shrink-0 dark:border-gray-700">
                <button onclick="toggleDarkMode()" class="flex items-center space-x-3 p-3 rounded-lg text-gray-700 no-underline w-full text-left text-sm font-medium hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
                    <i class="fas fa-adjust text-xl"></i> <span class="text-base">Modo Claro/Escuro</span>
                </button>
                <a href="login.php" class="flex items-center space-x-3 p-3 rounded-lg text-red-500 no-underline w-full text-left text-sm font-medium hover:bg-red-100 dark:text-red-400 dark:hover:bg-red-900 mt-2">
                    <i class="fas fa-sign-out-alt text-xl"></i> <span class="text-base">Sair</span>
                </a>
            </div>
        </aside>

        <main class="flex-grow-1 p-4 p-md-5 overflow-y-auto">
            <section id="chat-comunicacao" class="content-section card p-4 shadow-sm mb-4 <?php echo ($activeSection == 'chat-comunicacao') ? '' : 'd-none'; ?>">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-comments me-3 text-primary"></i> Chat com Pacientes
                </h2>

                <div id="patient-list-view" class="mb-4" style="<?php echo ($id_paciente_selecionado) ? 'display: none;' : 'display: block;'; ?>">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h3 class="fs-5 fw-bold mb-0">Caixa de Entrada</h3>
                        <div>
                            <button onclick="location.reload()" class="btn btn-success btn-sm mb-2 w-100">
                                <i class="fas fa-sync-alt me-1"></i> Atualizar Mensagens
                            </button>
                            <button
                                class="btn btn-primary btn-sm w-100"
                                data-bs-toggle="modal"
                                data-bs-target="#newChatModal"
                            >
                                <i class="fa fa-plus-circle me-1"></i>
                                Novo Chat
                            </button>
                        </div>
                    </div>
                    <p class="text-muted small mb-3">Chats de novos pacientes aparecerão aqui.</p>
                    <ul id="patient-list" class="list-group list-group-flush">
                        <?php if (!empty($pacientes_disponiveis)) { ?>
                            <?php foreach ($pacientes_disponiveis as $paciente) { ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center list-group-item-action">
                                    <span><?php echo htmlspecialchars($paciente['nome']); ?> (<?php echo htmlspecialchars($paciente['cpf']); ?>)</span>
                                    <?php 
                                    $unread_count = $unread_counts_by_patient[$paciente['id_paciente']] ?? 0;
                                    if ($unread_count > 0) { 
                                        echo '<span class="badge bg-danger rounded-pill ms-auto me-2">' . $unread_count . ' Novo Chat</span>';
                                    } 
                                    ?>
                                    <a href="?section=chat-comunicacao&id_paciente=<?php echo $paciente['id_paciente']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-comment-dots me-1"></i> Chat
                                    </a>
                                </li>
                            <?php } ?>
                        <?php } else { ?>
                            <li class="list-group-item text-muted text-center">Nenhum paciente encontrado.</li>
                        <?php } ?>
                    </ul>
                </div>

                <div id="chat-view" class="chat-container <?php echo ($id_paciente_selecionado) ? 'd-flex' : 'd-none'; ?> flex-column">
                    <div class="chat-header p-3 bg-light border-bottom d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Chat com <span id="chat-paciente-nome"><?php echo $nome_paciente_selecionado; ?></span></h4>
                        <div>
                            <a href="?section=chat-comunicacao&id_paciente=<?php echo $id_paciente_selecionado; ?>" class="btn btn-sm btn-success me-2">
                                <i class="fas fa-sync-alt me-1"></i> Atualizar Conversa
                            </a>
                            <a href="?section=chat-comunicacao" class="btn btn-sm btn-secondary"><i class="fas fa-arrow-left me-1"></i> Voltar</a>
                        </div>
                    </div>

                    <div id="chat-messages" class="chat-messages">
                        <?php if (!empty($mensagens)) { ?>
                            <?php foreach ($mensagens as $mensagem) { ?>
                                <?php 
                                $is_sent_by_medico = ($mensagem['tipo_remetente'] == 'medico');
                                $align_class = $is_sent_by_medico ? 'justify-content-end' : 'justify-content-start';
                                $bg_color_class = $is_sent_by_medico ? 'bg-primary text-white' : 'bg-light';
                                $text_color_class = $is_sent_by_medico ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.5)';
                                $remetente_display = $is_sent_by_medico ? 'Você' : htmlspecialchars($mensagem['nome_remetente']);
                                ?>
                                <div class="d-flex <?php echo $align_class; ?> mb-2">
                                    <div class="p-2 rounded <?php echo $bg_color_class; ?>" style="max-width: 60%;">
                                        <div class="fw-bold small mb-1">
                                            <?php echo $remetente_display; ?>
                                        </div>
                                        <?php echo htmlspecialchars($mensagem['mensagem']); ?>
                                        <div class="text-end" style="font-size: 0.75rem; color: <?php echo $text_color_class; ?>;">
                                            <?php echo (new DateTime($mensagem['data_envio']))->format('H:i'); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="text-muted text-center">Nenhuma mensagem nesta conversa.</div>
                        <?php } ?>
                    </div>

                    <form action="acessmedicdata.php?section=chat-comunicacao&id_paciente=<?php echo $id_paciente_selecionado; ?>" method="POST" class="chat-input-area">
                        <input type="text" name="mensagem" class="form-control" placeholder="Digite sua mensagem..." aria-label="Digite sua mensagem" required>
                        <input type="hidden" name="id_paciente" value="<?php echo $id_paciente_selecionado; ?>">
                        <button class="btn btn-primary" type="submit" name="send_message">
                            <i class="fas fa-paper-plane me-1"></i> Enviar
                        </button>
                    </form>
                </div>
            </section>

            <section id="horarios-atendimento" class="content-section card p-4 shadow-sm mb-4 <?php echo ($activeSection == 'horarios-atendimento') ? '' : 'd-none'; ?>">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-clock me-3 text-primary"></i> Horários de Atendimento
                </h2>
                <p class="text-muted mb-4">Gerencie seus horários disponíveis para consultas.</p>

                <ul class="nav nav-tabs mb-4" id="horariosTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="tab-horarios-fixos" data-bs-toggle="tab" data-bs-target="#content-horarios-fixos" type="button" role="tab" aria-controls="content-horarios-fixos" aria-selected="true">Horários Fixos (Semanal)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tab-horarios-data" data-bs-toggle="tab" data-bs-target="#content-horarios-data" type="button" role="tab" aria-controls="content-horarios-data" aria-selected="false">Horários por Data Específica</button>
                    </li>
                </ul>

                <div class="tab-content" id="horariosTabContent">
                    <!-- Tab Horários Fixos (Semanal) -->
                    <div class="tab-pane fade show active" id="content-horarios-fixos" role="tabpanel" aria-labelledby="tab-horarios-fixos">
                        <form id="horariosForm" class="mb-4" onsubmit="event.preventDefault(); addHorario();">
                            <h3 class="fs-5 fw-semibold mb-3">Adicionar Novo Horário Fixo</h3>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="diaSemana" class="form-label small fw-medium text-muted">Dia da Semana</label>
                                    <select id="diaSemana" class="form-select" required>
                                        <option value="">Selecione...</option>
                                        <option value="Segunda-feira">Segunda-feira</option>
                                        <option value="Terça-feira">Terça-feira</option>
                                        <option value="Quarta-feira">Quarta-feira</option>
                                        <option value="Quinta-feira">Quinta-feira</option>
                                        <option value="Sexta-feira">Sexta-feira</option>
                                        <option value="Sábado">Sábado</option>
                                        <option value="Domingo">Domingo</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="horaInicio" class="form-label small fw-medium text-muted">Hora Início</label>
                                    <input type="time" id="horaInicio" class="form-control" value="09:00" required>
                                </div>
                                <div class="col-md-3">
                                    <label for="horaFim" class="form-label small fw-medium text-muted">Hora Fim</label>
                                    <input type="time" id="horaFim" class="form-control" value="17:00" required>
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-plus me-2"></i> Adicionar</button>
                                </div>
                            </div>
                            <div class="row g-3 mt-2">
                                <div class="col-md-4">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" role="switch" id="emAlmoco">
                                        <label class="form-check-label" for="emAlmoco">Período de Almoço</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" role="switch" id="indisponivelTemporariamente">
                                        <label class="form-check-label" for="indisponivelTemporariamente">Indisponível Temporariamente</label>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <h3 class="fs-5 fw-semibold mb-3">Seus Horários Fixos Cadastrados</h3>
                        <div id="listaHorarios" class="list-group">
                            <div class="list-group-item text-muted text-center">Carregando horários...</div>
                        </div>
                    </div>

                    <!-- Tab Horários por Data Específica -->
                    <div class="tab-pane fade" id="content-horarios-data" role="tabpanel" aria-labelledby="tab-horarios-data">
                        <h3 class="fs-5 fw-semibold mb-3">Gerenciar Horários por Data</h3>
                        <div class="row mb-4">
                            <div class="col-md-8">
                                <div id="calendar"></div>
                            </div>
                            <div class="col-md-4">
                                <div class="card p-3 shadow-sm">
                                    <h4 class="fs-6 fw-bold mb-3">Horários para <span id="selectedDateDisplay">Selecione uma data</span></h4>
                                    <form id="horariosDataForm" onsubmit="event.preventDefault(); addHorarioDataEspecifica();">
                                        <input type="hidden" id="selectedDateInput" name="data_atendimento">
                                        <div class="mb-3">
                                            <label for="horaInicioData" class="form-label small fw-medium text-muted">Hora Início</label>
                                            <input type="time" id="horaInicioData" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="horaFimData" class="form-label small fw-medium text-muted">Hora Fim</label>
                                            <input type="time" id="horaFimData" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" role="switch" id="emAlmocoData">
                                                <label class="form-check-label" for="emAlmocoData">Período de Almoço</label>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" role="switch" id="indisponivelTemporariamenteData">
                                                <label class="form-check-label" for="indisponivelTemporariamenteData">Indisponível o dia todo</label>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="observacaoData" class="form-label small fw-medium text-muted">Observação (opcional)</label>
                                            <textarea id="observacaoData" class="form-control" rows="2"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-plus me-2"></i> Adicionar Horário</button>
                                    </form>

                                    <h5 class="fs-6 fw-bold mt-4 mb-2">Horários Cadastrados para o Dia:</h5>
                                    <div id="listaHorariosDataEspecifica" class="list-group">
                                        <div class="list-group-item text-muted text-center">Nenhum horário selecionado.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="configuracoes" class="content-section card p-4 shadow-sm mb-4 <?php echo ($activeSection == 'configuracoes') ? '' : 'd-none'; ?>">
                <h2 class="fs-3 fw-bold mb-4 d-flex align-items-center text-dark">
                    <i class="fas fa-cogs me-3 text-primary"></i> Configurações da Conta
                </h2>
                <div class="space-y-4">
                    <div>
                        <h3 class="fs-5 fw-semibold mb-3">Informações Pessoais</h3>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="nomeCompleto" class="form-label small fw-medium text-muted">Nome Completo</label>
                                <input type="text" id="nomeCompleto" class="form-control bg-light" value="<?php echo $nome_medico; ?>" disabled>
                            </div>
                            <div class="col-md-6">
                                <label for="crmMedico" class="form-label small fw-medium text-muted">CRM</label>
                                <input type="text" id="crmMedico" class="form-control bg-light" value="<?php echo $crm_medico; ?>" disabled>
                            </div>
                          
                        </div>
                        <button class="btn btn-primary mt-4"><i class="fas fa-save me-2"></i> Salvar Alterações</button>
                    </div>

                    <div class="border-top border-secondary pt-4 mt-4">
                        <h3 class="fs-5 fw-semibold mb-3">Preferências</h3>
                        <div class="d-flex align-items-center justify-content-between">
                            <span class="text-muted">Receber notificações por e-mail</span>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="emailNotificationsSwitch" checked>
                                <label class="form-check-label" for="emailNotificationsSwitch"></label>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detailsModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <h3 id="modalTitle" class="fs-4 fw-bold mb-3 text-dark"></h3>
                    <p class="text-muted mb-2">
                        <span class="fw-semibold">Data:</span> <span id="modalDate"></span>
                    </p>
                    <div class="mb-3">
                        <p id="modalDescription" class="text-muted whitespace-pre-wrap"></p>
                    </div>
                    <a id="modalDownloadLink" href="#" target="_blank" class="btn btn-primary mt-3 d-none"><i class="fas fa-download me-2"></i> Baixar PDF Completo</a>
                    <p id="modalNoPdfMessage" class="small text-muted mt-2 d-none"><i class="fas fa-info-circle me-1"></i> Não há um PDF disponível para este item.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <h3 id="messageModalTitle" class="fs-4 fw-bold mb-3 text-dark"></h3>
                    <p id="messageModalContent" class="text-muted mb-4"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="newChatModal" tabindex="-1" aria-labelledby="newChatModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newChatModalLabel">Iniciar Novo Chat com Paciente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <form id="newChatForm" action="acessmedicdata.php" method="GET">
                        <input type="hidden" name="section" value="chat-comunicacao">
                        <div class="mb-3">
                            <label for="selectPatient" class="form-label">Selecione um Paciente:</label>
                            <select class="form-select" id="selectPatient" name="id_paciente" required>
                                <option value="">Selecione...</option>
                                <?php if (!empty($pacientes_disponiveis)) { ?>
                                    <?php foreach ($pacientes_disponiveis as $paciente) { ?>
                                        <option value="<?php echo $paciente['id_paciente']; ?>">
                                            <?php echo htmlspecialchars($paciente['nome']); ?> (<?php echo htmlspecialchars($paciente['cpf']); ?>)
                                        </option>
                                    <?php } ?>
                                <?php } else { ?>
                                    <option value="" disabled>Nenhum paciente disponível</option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-comment-dots me-1"></i> Iniciar Chat
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FullCalendar JS -->
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/locales/pt-br.global.min.js'></script>
    <script>
        // Funções JavaScript básicas para evitar ReferenceError
        function showSection(sectionId, element) {
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.add('d-none');
                section.classList.remove('d-block');
            });

            const activeSection = document.getElementById(sectionId);
            if (activeSection) {
                activeSection.classList.remove('d-none');
                activeSection.classList.add('d-block');

                // Se a seção de horários de atendimento for ativada, carrega os horários
                if (sectionId === 'horarios-atendimento') {
                    // Ativa a primeira aba (Horários Fixos) por padrão
                    const firstTabButton = document.getElementById('tab-horarios-fixos');
                    const firstTabContent = document.getElementById('content-horarios-fixos');
                    
                    if (firstTabButton && firstTabContent) {
                        new bootstrap.Tab(firstTabButton).show();
                    }
                    loadHorarios(); // Carrega os horários fixos
                    // O calendário será inicializado quando a aba de horários por data for clicada
                }
            }

            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('sidebar-active');
            });

            if (element) {
                element.classList.add('sidebar-active');
            }
        }

        function changeProfilePic() {
            const profilePicInput = document.getElementById('profilePicInput');
            const profilePic = document.getElementById('profilePic');
            if (profilePicInput.files && profilePicInput.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    profilePic.src = e.target.result;
                };
                reader.readAsDataURL(profilePicInput.files[0]);
            }
        }

        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
        }

        function openDetailsModal(type, title, date, description, downloadLink) {
            const modalElement = new bootstrap.Modal(document.getElementById('detailsModal'));
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalDate').textContent = date;
            document.getElementById('modalDescription').textContent = description;
            document.getElementById('detailsModalLabel').textContent = title;

            const downloadLinkElement = document.getElementById('modalDownloadLink');
            const noPdfMessageElement = document.getElementById('modalNoPdfMessage');

            if (downloadLink && downloadLink !== 'N/A') {
                downloadLinkElement.href = downloadLink;
                downloadLinkElement.classList.remove('d-none');
                noPdfMessageElement.classList.add('d-none');
            } else {
                downloadLinkElement.classList.add('d-none');
                noPdfMessageElement.classList.remove('d-none');
            }

            modalElement.show();
        }

        function showMessageModal(title, message) {
            const modalElement = new bootstrap.Modal(document.getElementById('messageModal'));
            document.getElementById('messageModalTitle').innerHTML = title;
            document.getElementById('messageModalContent').innerHTML = message;
            document.getElementById('messageModalLabel').textContent = title;
            modalElement.show();
        }

        // Funções para Horários de Atendimento Fixos (Semanal)
        async function loadHorarios() {
            const lista = document.getElementById('listaHorarios');
            lista.innerHTML = '<div class="list-group-item text-muted text-center">Carregando horários...</div>';

            try {
                const response = await fetch('acessmedicdata.php?action=get_horarios_atendimento');
                const result = await response.json();

                if (result.success) {
                    lista.innerHTML = ''; // Limpa a lista antes de adicionar os novos itens
                    if (result.horarios.length > 0) {
                        result.horarios.forEach(horario => {
                            const newItem = document.createElement('div');
                            newItem.classList.add('list-group-item', 'd-flex', 'justify-content-between', 'align-items-center', 'flex-wrap', 'horario-item');
                            newItem.dataset.idHorario = horario.id_horario; // Armazena o ID para remoção

                            let statusText = '';
                            if (horario.em_almoco == 1) {
                                statusText += '<span class="badge bg-warning text-dark me-2">Almoço</span>';
                            }
                            if (horario.indisponivel_temporariamente == 1) {
                                statusText += '<span class="badge bg-danger me-2">Indisponível</span>';
                            }

                            newItem.innerHTML = `
                                <span>${horario.dia_semana}: ${horario.hora_inicio.substring(0, 5)} - ${horario.hora_fim.substring(0, 5)} ${statusText}</span>
                                <button type="button" class="btn btn-sm btn-outline-danger mt-2 mt-sm-0" onclick="removeHorario(this, ${horario.id_horario})"><i class="fas fa-trash-alt"></i> Remover</button>
                            `;
                            lista.appendChild(newItem);
                        });
                    } else {
                        lista.innerHTML = '<div class="list-group-item text-muted text-center">Nenhum horário cadastrado.</div>';
                    }
                } else {
                    showMessageModal('Erro', `Erro ao carregar horários: ${result.error}`);
                    lista.innerHTML = '<div class="list-group-item text-danger text-center">Erro ao carregar horários.</div>';
                }
            } catch (error) {
                console.error('Erro ao buscar horários:', error);
                showMessageModal('Erro de Conexão', 'Não foi possível carregar os horários. Verifique sua conexão.');
                lista.innerHTML = '<div class="list-group-item text-danger text-center">Erro de conexão.</div>';
            }
        }

        async function addHorario() {
            const dia = document.getElementById('diaSemana').value;
            const inicio = document.getElementById('horaInicio').value;
            const fim = document.getElementById('horaFim').value;
            const emAlmoco = document.getElementById('emAlmoco').checked ? 1 : 0;
            const indisponivelTemporariamente = document.getElementById('indisponivelTemporariamente').checked ? 1 : 0;

            if (!dia || !inicio || !fim) {
                showMessageModal('Erro', 'Por favor, preencha todos os campos obrigatórios para adicionar um horário.');
                return;
            }

            const data = {
                dia_semana: dia,
                hora_inicio: inicio,
                hora_fim: fim,
                em_almoco: emAlmoco,
                indisponivel_temporariamente: indisponivelTemporariamente
            };

            try {
                const response = await fetch('acessmedicdata.php?action=add_horario_atendimento', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    showMessageModal('Sucesso', 'Horário adicionado com sucesso!');
                    document.getElementById('horariosForm').reset(); // Limpa o formulário
                    loadHorarios(); // Recarrega a lista de horários
                } else {
                    showMessageModal('Erro', `Erro ao adicionar horário: ${result.error}`);
                }
            } catch (error) {
                console.error('Erro ao adicionar horário:', error);
                showMessageModal('Erro de Conexão', 'Ocorreu um erro ao tentar adicionar o horário. Verifique sua conexão.');
            }
        }

        async function removeHorario(button, idHorario) {
            if (!confirm('Tem certeza que deseja remover este horário?')) {
                return;
            }

            try {
                const response = await fetch('acessmedicdata.php?action=remove_horario_atendimento', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id_horario: idHorario })
                });
                const result = await response.json();

                if (result.success) {
                    showMessageModal('Sucesso', 'Horário removido com sucesso!');
                    loadHorarios(); // Recarrega a lista de horários
                } else {
                    showMessageModal('Erro', `Erro ao remover horário: ${result.error}`);
                }
            } catch (error) {
                console.error('Erro ao remover horário:', error);
                showMessageModal('Erro de Conexão', 'Ocorreu um erro ao tentar remover o horário. Verifique sua conexão.');
            }
        }

        // Funções para Horários por Data Específica
        let calendar;
        let selectedDate = null;

        async function loadHorariosDataEspecifica(date) {
            const lista = document.getElementById('listaHorariosDataEspecifica');
            lista.innerHTML = '<div class="list-group-item text-muted text-center">Carregando horários...</div>';
            document.getElementById('selectedDateDisplay').textContent = new Date(date + 'T00:00:00').toLocaleDateString('pt-BR');
            document.getElementById('selectedDateInput').value = date;

            try {
                const response = await fetch(`acessmedicdata.php?action=get_horarios_data_especifica&data=${date}`);
                const result = await response.json();

                if (result.success) {
                    lista.innerHTML = '';
                    if (result.horarios.length > 0) {
                        result.horarios.forEach(horario => {
                            const newItem = document.createElement('div');
                            newItem.classList.add('list-group-item', 'd-flex', 'justify-content-between', 'align-items-center', 'flex-wrap', 'horario-item');
                            newItem.dataset.idHorarioData = horario.id_horario_data;

                            let statusText = '';
                            if (horario.em_almoco == 1) {
                                statusText += '<span class="badge bg-warning text-dark me-2">Almoço</span>';
                            }
                            if (horario.indisponivel_temporariamente == 1) {
                                statusText += '<span class="badge bg-danger me-2">Indisponível o dia todo</span>';
                            } else if (horario.observacao) {
                                statusText += `<span class="badge bg-info text-dark me-2">Obs: ${horario.observacao}</span>`;
                            }

                            newItem.innerHTML = `
                                <span>${horario.hora_inicio.substring(0, 5)} - ${horario.hora_fim.substring(0, 5)} ${statusText}</span>
                                <button type="button" class="btn btn-sm btn-outline-danger mt-2 mt-sm-0" onclick="removeHorarioDataEspecifica(this, ${horario.id_horario_data})"><i class="fas fa-trash-alt"></i> Remover</button>
                            `;
                            lista.appendChild(newItem);
                        });
                    } else {
                        lista.innerHTML = '<div class="list-group-item text-muted text-center">Nenhum horário cadastrado para esta data.</div>';
                    }
                } else {
                    showMessageModal('Erro', `Erro ao carregar horários por data: ${result.error}`);
                    lista.innerHTML = '<div class="list-group-item text-danger text-center">Erro ao carregar horários.</div>';
                }
            } catch (error) {
                console.error('Erro ao buscar horários por data:', error);
                showMessageModal('Erro de Conexão', 'Não foi possível carregar os horários para esta data. Verifique sua conexão.');
                lista.innerHTML = '<div class="list-group-item text-danger text-center">Erro de conexão.</div>';
            }
        }

        async function addHorarioDataEspecifica() {
            const dataAtendimento = document.getElementById('selectedDateInput').value;
            const inicio = document.getElementById('horaInicioData').value;
            const fim = document.getElementById('horaFimData').value;
            const emAlmoco = document.getElementById('emAlmocoData').checked ? 1 : 0;
            const indisponivelTemporariamente = document.getElementById('indisponivelTemporariamenteData').checked ? 1 : 0;
            const observacao = document.getElementById('observacaoData').value.trim();

            if (!dataAtendimento || !inicio || !fim) {
                showMessageModal('Erro', 'Por favor, selecione uma data e preencha os horários.');
                return;
            }

            const data = {
                data_atendimento: dataAtendimento,
                hora_inicio: inicio,
                hora_fim: fim,
                em_almoco: emAlmoco,
                indisponivel_temporariamente: indisponivelTemporariamente,
                observacao: observacao
            };

            try {
                const response = await fetch('acessmedicdata.php?action=add_horario_data_especifica', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    showMessageModal('Sucesso', 'Horário adicionado para a data com sucesso!');
                    document.getElementById('horariosDataForm').reset();
                    loadHorariosDataEspecifica(dataAtendimento); // Recarrega a lista para a data selecionada
                    calendar.refetchEvents(); // Atualiza os eventos no calendário
                } else {
                    showMessageModal('Erro', `Erro ao adicionar horário: ${result.error}`);
                }
            } catch (error) {
                console.error('Erro ao adicionar horário por data:', error);
                showMessageModal('Erro de Conexão', 'Ocorreu um erro ao tentar adicionar o horário. Verifique sua conexão.');
            }
        }

        async function removeHorarioDataEspecifica(button, idHorarioData) {
            if (!confirm('Tem certeza que deseja remover este horário para esta data?')) {
                return;
            }

            try {
                const response = await fetch('acessmedicdata.php?action=remove_horario_data_especifica', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id_horario_data: idHorarioData })
                });
                const result = await response.json();

                if (result.success) {
                    showMessageModal('Sucesso', 'Horário removido para a data com sucesso!');
                    loadHorariosDataEspecifica(selectedDate); // Recarrega a lista
                    calendar.refetchEvents(); // Atualiza os eventos no calendário
                } else {
                    showMessageModal('Erro', `Erro ao remover horário: ${result.error}`);
                }
            } catch (error) {
                console.error('Erro ao remover horário por data:', error);
                showMessageModal('Erro de Conexão', 'Ocorreu um erro ao tentar remover o horário. Verifique sua conexão.');
            }
        }

        // Inicialização do FullCalendar
        function initializeCalendar() {
            const calendarEl = document.getElementById('calendar');
            if (calendarEl && !calendar) { // Garante que o calendário não seja inicializado múltiplas vezes
                calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    locale: 'pt-br',
                    selectable: true,
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    },
                    events: async function(fetchInfo, successCallback, failureCallback) {
                        try {
                            // FullCalendar envia startStr e endStr no formato ISO 8601
                            // Usamos apenas a data para buscar horários específicos
                            const response = await fetch(`acessmedicdata.php?action=get_horarios_data_especifica&start=${fetchInfo.startStr.split('T')[0]}&end=${fetchInfo.endStr.split('T')[0]}`);
                            const result = await response.json();
                            if (result.success) {
                                const events = result.horarios.map(horario => {
                                    let title = `${horario.hora_inicio.substring(0,5)} - ${horario.hora_fim.substring(0,5)}`;
                                    let color = '#3b82f6'; // Default blue
                                    if (horario.em_almoco == 1) {
                                        title += ' (Almoço)';
                                        color = '#f59e0b'; // Orange
                                    }
                                    // Se indisponível o dia todo, o evento deve cobrir o dia inteiro e ter título "Indisponível"
                                    if (horario.indisponivel_temporariamente == 1) {
                                        title = 'Indisponível';
                                        color = '#ef4444'; // Red
                                    }
                                    if (horario.observacao && horario.indisponivel_temporariamente == 0) {
                                        title += ` (${horario.observacao})`;
                                    }
                                    return {
                                        id: horario.id_horario_data,
                                        title: title,
                                        // Para eventos de dia inteiro, FullCalendar espera apenas a data
                                        start: horario.indisponivel_temporariamente == 1 ? horario.data_atendimento : `${horario.data_atendimento}T${horario.hora_inicio}`,
                                        end: horario.indisponivel_temporariamente == 1 ? horario.data_atendimento : `${horario.data_atendimento}T${horario.hora_fim}`,
                                        allDay: horario.indisponivel_temporariamente == 1, // Se indisponível, mostra como evento de dia inteiro
                                        color: color
                                    };
                                });
                                successCallback(events);
                            } else {
                                failureCallback(result.error);
                            }
                        } catch (error) {
                            console.error('Erro ao buscar eventos do calendário:', error);
                            failureCallback(error);
                        }
                    },
                    dateClick: function(info) {
                        // Remove a classe 'fc-day-selected' de todos os dias
                        document.querySelectorAll('.fc-daygrid-day').forEach(dayEl => {
                            dayEl.classList.remove('fc-day-selected');
                        });

                        // Adiciona a classe 'fc-day-selected' ao dia clicado
                        info.dayEl.classList.add('fc-day-selected');

                        selectedDate = info.dateStr; // Armazena a data selecionada no formato YYYY-MM-DD
                        loadHorariosDataEspecifica(selectedDate);
                    },
                    eventClick: function(info) {
                        // Opcional: exibir detalhes do evento clicado
                        showMessageModal('Detalhes do Horário', `
                            <strong>${info.event.title}</strong><br>
                            Data: ${info.event.start.toLocaleDateString('pt-BR')}<br>
                            Início: ${info.event.start.toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}<br>
                            Fim: ${info.event.end ? info.event.end.toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'}) : 'N/A'}
                        `);
                    }
                });
                calendar.render();
            }
        }


        // Inicialização
        document.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const initialSection = urlParams.get('section') || 'chat-comunicacao';
            const initialNavLink = document.getElementById(`nav-${initialSection}`);
            if (initialNavLink) {
                showSection(initialSection, initialNavLink);
            } else {
                showSection('chat-comunicacao', document.getElementById('nav-chat-comunicacao'));
            }

            // Adiciona listeners para os links da sidebar para alternar seções
            document.querySelectorAll('aside nav a').forEach(item => { // Seletor ajustado para os links dentro da nav da aside
                item.addEventListener('click', function(e) {
                    // Previne o comportamento padrão apenas se não for um modal ou link de saída
                    if (!this.dataset.bsToggle && this.getAttribute('href') !== 'login.php') {
                        e.preventDefault();
                        const href = this.getAttribute('href');
                        const sectionId = href.split('section=')[1];
                        if (sectionId) {
                            showSection(sectionId, this);
                            // Atualiza a URL sem recarregar a página para manter o estado
                            history.pushState(null, '', href);

                            // Se a seção de chat for selecionada e um paciente estiver ativo, rola para o final
                            if (sectionId === 'chat-comunicacao' && urlParams.get('id_paciente')) {
                                setTimeout(() => {
                                    const chatMessagesDiv = document.getElementById('chat-messages');
                                    if (chatMessagesDiv) {
                                        chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;
                                    }
                                }, 100); // Pequeno atraso para garantir que o DOM esteja renderizado
                            }
                        }
                    }
                });
            });

            // Rola para o final do chat se um paciente já estiver selecionado na carga inicial
            if (urlParams.get('section') === 'chat-comunicacao' && urlParams.get('id_paciente')) {
                setTimeout(() => {
                    const chatMessagesDiv = document.getElementById('chat-messages');
                    if (chatMessagesDiv) {
                        chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;
                    }
                }, 100);
            }

            // Carrega os horários se a seção de horários for a inicial
            if (initialSection === 'horarios-atendimento') {
                // A função loadHorarios() já é chamada dentro de showSection para 'horarios-atendimento'
                // quando a aba 'Horários Fixos' é ativada.
                // O calendário é inicializado quando a aba 'Horários por Data Específica' é clicada.
            }

            // Inicializa o calendário quando a aba de horários por data for mostrada
            const horariosDataTab = document.getElementById('tab-horarios-data');
            if (horariosDataTab) {
                horariosDataTab.addEventListener('shown.bs.tab', function (event) {
                    initializeCalendar();
                    // Seleciona o dia atual por padrão ao abrir a aba do calendário
                    const today = new Date();
                    const todayStr = today.toISOString().split('T')[0];
                    selectedDate = todayStr;
                    loadHorariosDataEspecifica(selectedDate);

                    // Adiciona a classe 'fc-day-selected' ao dia atual no calendário
                    const todayCell = document.querySelector(`.fc-day[data-date="${todayStr}"]`);
                    if (todayCell) {
                        todayCell.classList.add('fc-day-selected');
                    }
                });
            }
        });
    </script>
</body>
</html>