<?php
require('fpdf/fpdf.php'); // Certifique-se de que o caminho para a biblioteca FPDF está correto
include_once 'conexao.php'; // Inclui o arquivo de conexão

class PDF extends FPDF
{
    // Cabeçalho
    function Header()
    {
        // Logo
        // $this->Image('logo.png',10,8,33); // Descomente e ajuste se tiver um logo
        // Fonte do cabeçalho
        $this->SetFont('Arial','B',15);
        // Move para a direita
        $this->Cell(80);
        // Título
        $this->Cell(30,10,'Relatório de Agendamentos',0,0,'C');
        // Quebra de linha
        $this->Ln(20);
    }

    // Rodapé
    function Footer()
    {
        // Posição a 1.5 cm do fim
        $this->SetY(-15);
        // Fonte do rodapé
        $this->SetFont('Arial','I',8);
        // Número da página
        $this->Cell(0,10,'Página '.$this->PageNo().'/{nb}',0,0,'C');
    }

    // Tabela colorida
    function FancyTable($header, $data)
    {
        // Cores, largura de linha e fonte em negrito
        $this->SetFillColor(28, 110, 190); // Azul escuro
        $this->SetTextColor(255);
        $this->SetDrawColor(128,0,0);
        $this->SetLineWidth(.3);
        $this->SetFont('','B');

        // Cabeçalhos
        $w = array(40, 30, 20, 25, 45, 30); // Larguras das colunas
        for($i=0;$i<count($header);$i++)
            $this->Cell($w[$i],7,$header[$i],1,0,'C',true);
        $this->Ln();

        // Restauração de cores e fonte
        $this->SetFillColor(224,235,255); // Azul claro
        $this->SetTextColor(0);
        $this->SetFont('');

        // Dados
        $fill = false;
        foreach($data as $row)
        {
            $this->Cell($w[0],6,iconv('UTF-8', 'windows-1252', $row['nome_paciente']),'LR',0,'L',$fill);
            $this->Cell($w[1],6,iconv('UTF-8', 'windows-1252', $row['cpf_paciente']),'LR',0,'C',$fill);
            $this->Cell($w[2],6,iconv('UTF-8', 'windows-1252', $row['idade_paciente']),'LR',0,'C',$fill);
            $this->Cell($w[3],6,iconv('UTF-8', 'windows-1252', $row['genero_paciente']),'LR',0,'C',$fill);
            $this->Cell($w[4],6,iconv('UTF-8', 'windows-1252', $row['data_agendamento']),'LR',0,'C',$fill);
            $this->Cell($w[5],6,iconv('UTF-8', 'windows-1252', $row['nivel_urgencia']),'LR',0,'C',$fill);
            $this->Ln();
            $fill = !$fill;
        }
        // Linha de fechamento
        $this->Cell(array_sum($w),0,'','T');
    }
}

// Criação do objeto PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

try {
    $pdo = getPdoConnection(); // Obtém a conexão PDO.

    // Consulta para buscar os agendamentos
    $sql = "SELECT nome_paciente, cpf_paciente, idade_paciente, genero_paciente,
                   data_agendamento, nivel_urgencia
            FROM agendamentos
            ORDER BY data_agendamento DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Cabeçalhos da tabela
    $header = array('Paciente', 'CPF', 'Idade', 'Gênero', 'Data/Hora', 'Urgência');

    // Adiciona a tabela ao PDF
    $pdf->FancyTable($header, $agendamentos);

    $pdf->Output('I', 'relatorio_agendamentos.pdf'); // 'I' para exibir no navegador, 'D' para download
} catch (PDOException $e) {
    error_log("Erro ao gerar relatório de agendamentos: " . $e->getMessage());
    echo "Erro ao gerar relatório: " . $e->getMessage();
} catch (Exception $e) {
    error_log("Erro geral ao gerar relatório: " . $e->getMessage());
    echo "Erro inesperado ao gerar relatório: " . $e->getMessage();
}
?>
