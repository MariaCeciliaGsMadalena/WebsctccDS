<?php
require('fpdf.php');

class ReceitaMedicaPDF extends FPDF
{
    private $logoPath = 'logo_clinica.png';
    
    function Header()
    {
        if(file_exists($this->logoPath)) {
            $this->Image($this->logoPath, 10, 8, 30);
        }
        
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(31, 73, 125);
        $this->Cell(0, 15, 'RECEITA MÉDICA', 0, 1, 'C');
        $this->SetDrawColor(31, 73, 125);
        $this->SetLineWidth(0.5);
        $this->Line(10, 30, 200, 30);
        $this->Ln(15);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Página ' . $this->PageNo() . ' | Emitido em: ' . date('d/m/Y H:i'), 0, 0, 'C');
    }

    function DadosMedico($nome, $crm, $especialidade = '')
    {
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(31, 73, 125);
        $this->Cell(40, 10, 'MÉDICO:', 0, 0);
        $this->SetFont('', '');
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 10, $nome, 0, 1);
        
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(31, 73, 125);
        $this->Cell(40, 10, 'CRM:', 0, 0);
        $this->SetFont('', '');
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 10, $crm, 0, 1);
        
        if(!empty($especialidade)) {
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(31, 73, 125);
            $this->Cell(40, 10, 'ESPECIALIDADE:', 0, 0);
            $this->SetFont('', '');
            $this->SetTextColor(0, 0, 0);
            $this->Cell(0, 10, $especialidade, 0, 1);
        }
        
        $this->Ln(8);
    }

    function DadosPaciente($nome, $idade, $sexo = '')
    {
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(31, 73, 125);
        $this->Cell(40, 10, 'PACIENTE:', 0, 0);
        $this->SetFont('', '');
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 10, $nome, 0, 1);
        
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(31, 73, 125);
        $this->Cell(40, 10, 'IDADE:', 0, 0);
        $this->SetFont('', '');
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 10, $idade . ' anos', 0, 1);
        
        if(!empty($sexo)) {
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(31, 73, 125);
            $this->Cell(40, 10, 'SEXO:', 0, 0);
            $this->SetFont('', '');
            $this->SetTextColor(0, 0, 0);
            $this->Cell(0, 10, $sexo, 0, 1);
        }
        
        $this->Ln(8);
    }

    function Medicamentos($nomes, $dosagens, $posologias)
    {
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(31, 73, 125);
        $this->Cell(0, 10, 'MEDICAMENTOS PRESCRITOS:', 0, 1);
        
        $this->SetFont('', '', 12);
        $this->SetTextColor(0, 0, 0);
        
        for($i = 0; $i < count($nomes); $i++) {
            $medicamento = trim($nomes[$i]);
            $dosagem = trim($dosagens[$i]);
            $posologia = trim($posologias[$i]);
            
            if(!empty($medicamento)) {
                $this->MultiCell(0, 8, "• " . $medicamento . " - " . $dosagem . " (" . $posologia . ")", 0, 1);
                $this->Ln(2);
            }
        }
        
        $this->Ln(5);
    }

    function Observacoes($texto)
    {
        if(!empty(trim($texto))) {
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(31, 73, 125);
            $this->Cell(0, 10, 'OBSERVAÇÕES:', 0, 1);
            
            $this->SetFont('', '', 12);
            $this->SetTextColor(0, 0, 0);
            $this->MultiCell(0, 8, trim($texto), 0, 1);
            $this->Ln(5);
        }
    }

    function Assinatura($medico_nome, $medico_crm)
    {
        $this->Ln(20);
        $this->SetFont('', '', 12);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 10, '_________________________', 0, 1, 'R');
        $this->Cell(0, 5, $medico_nome, 0, 1, 'R');
        $this->Cell(0, 5, 'CRM: ' . $medico_crm, 0, 1, 'R');
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Dados do médico
    $medico_nome = htmlspecialchars($_POST['medico_nome'] ?? '');
    $medico_crm = htmlspecialchars($_POST['medico_crm'] ?? '');
    
    // Dados do paciente
    $paciente_nome = htmlspecialchars($_POST['paciente_nome'] ?? '');
    $paciente_idade = htmlspecialchars($_POST['paciente_idade'] ?? '');
    $paciente_sexo = htmlspecialchars($_POST['paciente_sexo'] ?? '');
    
    // Medicamentos
    $medicamentos_nomes = $_POST['medicamento_nome'] ?? [];
    $medicamentos_dosagens = $_POST['medicamento_dosagem'] ?? [];
    $medicamentos_posologias = $_POST['medicamento_posologia'] ?? [];
    
    // Observações
    $observacoes = htmlspecialchars($_POST['observacoes'] ?? '');

    // Criar PDF
    $pdf = new ReceitaMedicaPDF();
    $pdf->AddPage();
    $pdf->DadosMedico($medico_nome, $medico_crm);
    $pdf->DadosPaciente($paciente_nome, $paciente_idade, $paciente_sexo);
    $pdf->Medicamentos($medicamentos_nomes, $medicamentos_dosagens, $medicamentos_posologias);
    $pdf->Observacoes($observacoes);
    $pdf->Assinatura($medico_nome, $medico_crm);

    // Saída do PDF
    $pdf->Output("I", "Receita_Medica_" . date('Ymd_His') . ".pdf");
} else {
    header('HTTP/1.1 403 Forbidden');
    echo "<h1>Acesso não autorizado</h1>";
    echo "<p>Este formulário deve ser submetido via POST.</p>";
}
?>