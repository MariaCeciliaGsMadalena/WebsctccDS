<?php
// Habilita a exibição de todos os erros PHP para depuração.
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
// Inclui o arquivo de conexão com o banco de dados.
// Certifique-se de que 'conexao.php' está configurado corretamente para sua base de dados.
include_once 'conexao.php';
// Inclui o controlador de chat, que contém funções para enviar e buscar mensagens.
include_once 'chat_controller.php';

// Verifica se o usuário está logado e se o tipo de usuário é 'medico'.
// Se não estiver logado ou o tipo de usuário for incorreto, redireciona para a página de login.
if (!isset($_SESSION['usuario']) || (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] !== 'medico')) {
    header('Location: login.php'); // Redireciona para a página de login ou de acesso não autorizado.
    exit; // Termina a execução do script para evitar processamento adicional.
}

// Obtém os dados do médico logado a partir da sessão.
// Usa o operador de coalescência nula (?? '') para evitar avisos se as chaves não existirem.
$nome_medico = 'Dr(a). ' . htmlspecialchars($_SESSION['usuario']['nome'] ?? '');
$especialidade_medico = htmlspecialchars($_SESSION['usuario']['especialidade'] ?? '');
$crm_medico = htmlspecialchars($_SESSION['usuario']['crm'] ?? '');
$id_medico_logado = $_SESSION['usuario']['id_medico'] ?? null;

// Inicializa a conexão PDO usando a função do chat_controller.php.
try {
    $pdo = getPdoConnection();
} catch (Exception $e) {
    // Em caso de erro de conexão com o banco de dados, exibe uma mensagem amigável e encerra o script.
    error_log("Erro ao conectar ao banco de dados em acessmedicdata.php: " . $e->getMessage());
    echo "<h1>Erro de Conexão com o Banco de Dados</h1>";
    echo "<p>Não foi possível conectar ao banco de dados. Por favor, verifique as configurações de conexão e tente novamente. Detalhes: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}


// --- Lógica para buscar todos os estabelecimentos de exame para o dropdown de chat ---
$allEstabelecimentos = []; // Array para armazenar os estabelecimentos.
try {
    // Prepara e executa a consulta SQL para obter todos os estabelecimentos.
    $sqlAllEstabelecimentos = "SELECT id_estabelecimento, nome_estabelecimento, email FROM estabelecimentos_exame ORDER BY nome_estabelecimento ASC";
    $stmtAllEstabelecimentos = $pdo->prepare($sqlAllEstabelecimentos);
    $stmtAllEstabelecimentos->execute();
    // Busca todos os resultados como um array associativo.
    $allEstabelecimentos = $stmtAllEstabelecimentos->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Em caso de erro no banco de dados, registra o erro.
    error_log("Erro ao buscar todos os estabelecimentos: " . $e->getMessage());
    // Em um ambiente de produção, você pode exibir uma mensagem amigável ao usuário.
}

// --- Tratamento do ID do Estabelecimento Selecionado via GET (para o chat) ---
$id_estabelecimento_selecionado = $_GET['id_estabelecimento'] ?? null;
$nome_estabelecimento_selecionado = 'Nenhum Estabelecimento Selecionado';

// Se um ID de estabelecimento foi selecionado, busca o nome correspondente.
if ($id_estabelecimento_selecionado) {
    $sql = "SELECT nome_estabelecimento FROM estabelecimentos_exame WHERE id_estabelecimento = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id_estabelecimento_selecionado, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result) {
        $nome_estabelecimento_selecionado = htmlspecialchars($result['nome_estabelecimento']);
    }
}

// --- Lógica para processar envio de mensagens (Sem AJAX) ---
// Verifica se a requisição é POST e se o botão de envio de chat foi clicado.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_chat_message'])) {
    $id_destinatario = $_POST['id_estabelecimento'] ?? null; // ID do estabelecimento destinatário.
    $mensagem = $_POST['mensagem'] ?? null; // Conteúdo da mensagem.

    // Valida os dados antes de enviar a mensagem.
    if ($id_medico_logado && $id_destinatario && !empty(trim($mensagem))) {
        try {
            // Chama a função 'sendChatMessage' do 'chat_controller.php' para inserir a mensagem no banco.
            sendChatMessage($pdo, $id_medico_logado, 'medico', $id_destinatario, 'estabelecimento_exame', $mensagem);
            // Armazena uma mensagem de sucesso na sessão.
            $_SESSION['chat_success'] = 'Mensagem enviada com sucesso!';
            // Redireciona para a mesma página, recarregando-a com o chat atualizado.
            header("Location: acessmedicdata.php?section=chat-comunicacao&id_estabelecimento=" . $id_destinatario);
            exit; // Termina o script após o redirecionamento.
        } catch (Exception $e) {
            // Em caso de erro, registra e armazena uma mensagem de erro na sessão.
            error_log("Erro ao enviar mensagem no acessmedicdata.php: " . $e->getMessage());
            $_SESSION['chat_error'] = 'Erro interno ao enviar mensagem: ' . $e->getMessage();
        }
    } else {
        // Se os dados forem inválidos, armazena uma mensagem de erro.
        $_SESSION['chat_error'] = "Por favor, selecione um estabelecimento e digite uma mensagem.";
    }
}

// --- Lógica para carregar mensagens do chat (Sem AJAX) ---
$chat_mensagens = []; // Array para armazenar as mensagens do chat.
// Carrega as mensagens apenas se um médico e um estabelecimento estiverem selecionados.
if ($id_medico_logado && $id_estabelecimento_selecionado) {
    try {
        // Chama a função 'getChatHistory' do 'chat_controller.php' para obter o histórico.
        $chat_result = getChatHistory($pdo, $id_medico_logado, 'medico', $id_estabelecimento_selecionado, 'estabelecimento_exame');
        if ($chat_result['success']) {
            $chat_mensagens = $chat_result['history']; // Armazena o histórico de mensagens.
        } else {
            error_log("Erro ao carregar histórico do chat: " . ($chat_result['error'] ?? 'Erro desconhecido'));
        }
    } catch (Exception $e) {
        error_log("Exceção ao carregar chat: " . $e->getMessage());
    }
}

// Lógica para exibir mensagens de sucesso ou erro do chat após o redirecionamento.
$chatNotification = '';
if (isset($_SESSION['chat_success'])) {
    $chatNotification = '<div class="alert alert-success">' . $_SESSION['chat_success'] . '</div>';
    unset($_SESSION['chat_success']); // Limpa a mensagem após exibição.
} elseif (isset($_SESSION['chat_error'])) {
    $chatNotification = '<div class="alert alert-danger">' . $_SESSION['chat_error'] . '</div>';
    unset($_SESSION['chat_error']); // Limpa a mensagem após exibição.
}

// Determina a seção ativa para o carregamento inicial da página com base no parâmetro 'section' na URL.
$activeSection = $_GET['section'] ?? 'dashboard';

// --- Lógica para requisições AJAX (mantidas apenas para funcionalidades que não são o chat principal) ---
// Este bloco processa requisições AJAX para busca de pacientes, histórico de exames e contagem de mensagens não lidas.
// O chat principal (envio/recebimento de mensagens) não usa este bloco.
if (isset($_GET['action'])) {
    header('Content-Type: application/json'); // Define o cabeçalho para indicar que a resposta é JSON.

    try {
        // Ação para buscar exames de um paciente.
        if ($_GET['action'] === 'get_patient_exams') {
            $id_paciente = $_GET['id_paciente'] ?? null;
            $exams = [];

            if ($id_paciente) {
                $sql = "SELECT id_exame, tipo_exame, data_solicitacao, data_realizacao, data_resultado,
                               status_exame, caminho_arquivo_resultado, resultado, observacoes
                        FROM exames
                        WHERE id_paciente = :id_paciente
                        ORDER BY data_solicitacao DESC";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
                $stmt->execute();
                $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            echo json_encode($exams);
            exit;

        // Ação para buscar médicos (para sugestões, se aplicável).
        } elseif ($_GET['action'] === 'search_medicos') {
            $query = $_GET['query'] ?? '';
            $medicos = [];

            if (!empty($query)) {
                $sql = "SELECT id_medico, nome, crm, especialidade FROM medicos
                        WHERE nome LIKE :query OR crm LIKE :query
                        LIMIT 10";
                $stmt = $pdo->prepare($sql);
                $searchTerm = '%' . $query . '%';
                $stmt->bindParam(':query', $searchTerm);
                $stmt->execute();
                $medicos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }

            echo json_encode($medicos);
            exit;

        // Ação para obter a contagem de mensagens não lidas (para o badge de notificação).
        } elseif ($_GET['action'] === 'get_unread_count') {
            // Chama a função 'getUnreadMessageCount' do 'chat_controller.php'.
            $response = getUnreadMessageCount(
                $pdo,
                $id_medico_logado,
                'medico'
            );
            echo json_encode($response);
            exit;
        }

    } catch (PDOException $e) {
        // Em caso de erro de PDO, registra e retorna um JSON de erro.
        error_log("Erro de PDO em acessmedicdata.php (AJAX): " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Erro de banco de dados: ' . $e->getMessage()]);
        exit;
    } catch (Exception $e) {
        // Em caso de erro geral, registra e retorna um JSON de erro.
        error_log("Erro geral em acessmedicdata.php (AJAX): " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso Médico</title>
    <!-- Bootstrap CSS para estilização responsiva -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Seu arquivo CSS personalizado para o menu lateral (se houver) -->
    <link rel="stylesheet" href="stylemenu.css">
    <!-- Chart.js para gráficos (seção de painel) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Estilos gerais do corpo e layout */
        body {
            font-family: "Inter", "Noto Sans", sans-serif;
            background-color: #f8f9fa;
        }
        #wrapper {
            display: flex; /* Garante que os elementos internos se alinhem lado a lado */
        }
        /* Estilos da barra lateral (sidebar) */
        #sidebar-wrapper {
            min-height: 100vh;
            margin-left: 0; /* Define a margem esquerda para 0 para que a sidebar seja sempre visível */
            background-color: #343a40; /* Fundo escuro para a sidebar */
            color: #fff;
            width: 15rem; /* Largura fixa da sidebar */
        }
        #sidebar-wrapper .sidebar-heading {
            padding: 1.5rem 1.25rem;
            font-size: 1.2rem;
            color: #fff;
            border-bottom: 1px solid rgba(255,255,255,.1);
        }
        #sidebar-wrapper .list-group {
            width: 15rem;
        }
        #sidebar-wrapper .list-group-item {
            color: #adb5bd;
            background-color: #343a40;
            border: none;
            padding: 0.75rem 1.25rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #sidebar-wrapper .list-group-item:hover {
            background-color: #495057;
            color: #fff;
        }
        #sidebar-wrapper .list-group-item.active {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
        }
        /* Estilos do conteúdo principal da página */
        #page-content-wrapper {
            flex-grow: 1; /* Permite que o conteúdo principal ocupe o espaço restante */
        }
        .content-section {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,.075);
            margin-bottom: 20px;
        }
        .dashboard-cards .card {
            border-radius: 8px;
            border: none;
        }
        .form-section {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            border: 1px solid #e9ecef;
        }
        /* Estilos do timer (seção de nova consulta) */
        .timer-display {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .btn-group-timer button {
            margin: 5px;
        }
        /* Estilos da caixa de chat */
        .chat-box {
            height: 300px;
            overflow-y: auto;
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 15px;
            background-color: #e9ecef;
            display: flex; /* Adicionado para layout de chat */
            flex-direction: column; /* Adicionado para layout de chat */
        }
        .chat-message {
            background-color: #d1e7dd; /* Verde claro para mensagens recebidas */
            padding: 8px 12px;
            border-radius: 15px;
            margin-bottom: 10px;
            max-width: 80%;
            word-wrap: break-word;
            align-self: flex-start; /* Mensagens recebidas à esquerda */
        }
        .chat-message.system {
            background-color: #cce5ff; /* Azul claro para mensagens do sistema */
            align-self: flex-start; /* Mensagens do sistema à esquerda */
        }
        .chat-message.sent {
            background-color: #007bff; /* Azul para mensagens enviadas */
            color: white;
            align-self: flex-end; /* Mensagens enviadas à direita */
        }
        .chat-message small {
            display: block;
            font-size: 0.75em;
            color: #6c757d;
            margin-top: 5px;
        }
        .chat-message.sent small {
            color: rgba(255, 255, 255, 0.7);
        }
        .chat-message .file-download { /* Estilo para o link de download (escondido) */
            display: none;
        }
        .chat-message.sent .file-download { /* Estilo para o link de download em mensagens enviadas (escondido) */
            display: none;
        }
        /* Estilos para spinners de carregamento */
        .loading-spinner {
            display: none; /* Escondido por padrão */
            margin-left: 10px;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, .3);
            border-radius: 50%;
            border-top-color: #007bff;
            animation: spin 1s ease-in-out infinite;
            -webkit-animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { -webkit-transform: rotate(360deg); }
        }
        @-webkit-keyframes spin {
            to { -webkit-transform: rotate(360deg); }
        }

        /* Estilos para o modal do gráfico */
        .chart-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1050; /* Acima de outros modais se houver */
        }

        .chart-modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 600px; /* Tamanho menor para o modal do gráfico */
            position: relative;
        }

        .chart-modal-content .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 1.5rem;
            cursor: pointer;
            border: none;
            background: none;
        }
        /* Estilos para o Custom Modal (alertas personalizados) */
        .modal-custom {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1060; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            justify-content: center; /* Center content horizontally */
            align-items: center; /* Center content vertically */
        }

        .modal-content-custom {
            background-color: #fefefe;
            margin: auto; /* Centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more specific, like max-width */
            max-width: 500px; /* Max width for better appearance */
            border-radius: 8px;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
            text-align: center;
            position: relative; /* Needed for close button positioning */
        }

        .close-button-custom {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 15px;
            cursor: pointer;
        }

        .close-button-custom:hover,
        .close-button-custom:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <div id="wrapper">
        <!-- Barra Lateral de Navegação -->
        <div id="sidebar-wrapper">
            <div class="sidebar-heading">
                <i class="fas fa-user-md"></i> Médico <br>
                <small class="d-block mt-1"><?php echo $nome_medico; ?></small>
                <small class="d-block"><?php echo $especialidade_medico; ?></small>
                <small class="d-block">CRM: <?php echo $crm_medico; ?></small>
            </div>
            <div class="list-group list-group-flush">
                <!-- Links de navegação. O parâmetro 'section' na URL controla a seção ativa. -->
                <a href="?section=dashboard" class="list-group-item list-group-item-action <?php echo (!isset($_GET['section']) || $_GET['section'] == 'dashboard') ? 'active' : ''; ?>" id="menu-dashboard"><i class="fas fa-chart-line"></i> Painel</a>
                <a href="?section=new-consultation" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'new-consultation') ? 'active' : ''; ?>" id="menu-new-consultation"><i class="fas fa-stethoscope"></i> Nova Consulta</a>
                <a href="?section=patient-history" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'patient-history') ? 'active' : ''; ?>" id="menu-patient-history"><i class="fas fa-notes-medical"></i> Prontuários</a>
                <a href="?section=appointments" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'appointments') ? 'active' : ''; ?>" id="menu-appointments"><i class="fas fa-calendar-alt"></i> Agendamentos</a>
                <a href="?section=medical-certificates" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'medical-certificates') ? 'active' : ''; ?>" id="menu-medical-certificates"><i class="fas fa-file-medical"></i> Atestados</a>
                <a href="?section=exams" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'exams') ? 'active' : ''; ?>" id="menu-exams"><i class="fas fa-x-ray"></i> Exames</a>
                <a href="?section=chat-comunicacao" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'chat-comunicacao') ? 'active' : ''; ?>" id="menu-chat-comunicacao"><i class="fas fa-comments"></i> Chat de Comunicação</a>
                <a href="?section=reports" class="list-group-item list-group-item-action <?php echo (isset($_GET['section']) && $_GET['section'] == 'reports') ? 'active' : ''; ?>" id="menu-reports"><i class="fas fa-chart-pie"></i> Relatórios</a>
                <a href="login.php" class="list-group-item list-group-item-action text-danger"><i class="fas fa-sign-out-alt"></i> Sair</a>
            </div>
        </div>
        <!-- Conteúdo Principal da Página -->
        <div id="page-content-wrapper">
            <div class="container-fluid">

                <!-- Seção: Painel (Dashboard) -->
                <div id="dashboard" class="content-section" style="<?php echo (!isset($_GET['section']) || $_GET['section'] == 'dashboard') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-chart-line"></i> Visão Geral do Dia</h2>
                    <div class="row dashboard-cards">
                        <div class="col-md-4">
                            <div class="card text-white bg-primary mb-3">
                                <div class="card-header">Consultas de Hoje</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="consultasHoje">5</h5> <!-- Exemplo de dado -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-white bg-success mb-3">
                                <div class="card-header">Tempo Médio das Últimas 10 Consultas</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="tempoMedio">18 min</h5> <!-- Exemplo de dado -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-dark bg-warning mb-3">
                                <div class="card-header">Próximo Paciente</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="proximoPacienteNome">João Silva</h5>
                                    <p id="proximoPacienteHorario">Horário: 10:00</p>
                                    <p id="proximoPacienteMotivo">Motivo: Retorno de Exames</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-4">
                        <div class="card-header"><i class="fas fa-history"></i> Últimas Consultas (Recentes)</div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush" id="recent-consultations-list">
                                <!-- Conteúdo preenchido dinamicamente via JS/AJAX (exemplo estático aqui) -->
                                <li class="list-group-item">
                                    <strong>Maria Souza</strong> (45 anos) - Motivo: Dor de cabeça - <small>10/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>Carlos Alberto</strong> (28 anos) - Motivo: Resfriado - <small>09/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>Ana Paula</strong> (60 anos) - Motivo: Checape Anual - <small>08/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                            </ul>
                            <button class="btn btn-sm btn-outline-primary mt-3">Ver Todas as Consultas</button>
                        </div>
                    </div>

                    <!-- Botão para abrir o modal do gráfico -->
                    <div class="text-center mt-4">
                        <button class="btn btn-info" id="openChartModalBtn"><i class="fas fa-chart-bar"></i> Ver Gráfico de Atendimentos por Mês</button>
                    </div>
                </div>

                <!-- Seção: Nova Consulta -->
                <div id="new-consultation" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'new-consultation') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-stethoscope"></i> Iniciar Nova Consulta</h2>
                    <div class="form-section">
                        <h4 class="mb-3">Começar consulta</h4>
                        <div class="timer-display" id="timer">00:00:00</div>
                        <div class="mb-3 btn-group-timer">
                            <button class="btn btn-success" id="startBtn"><i class="fas fa-play"></i> Iniciar</button>
                            <button class="btn btn-warning" id="pauseBtn"><i class="fas fa-pause"></i> Pausar</button>
                            <button class="btn btn-danger" id="resetBtn"><i class="fas fa-redo"></i> Resetar</button>
                        </div>
                        <p><strong>Status:</strong> <span id="consultationStatus">Primeira consulta</span></p>
                        <p><strong>CPF do paciente:</strong> <span id="patientCpf">CPF não informado</span></p>
                    </div>

                    <div class="form-section">
                        <h4 class="mb-3">Dados do Paciente</h4>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="patientName" class="form-label">Nome do Paciente</label>
                                <input type="text" class="form-control" id="patientName" placeholder="Nome Completo do Paciente" oninput="searchPatients(this.value, 'new-consultation')">
                                <div id="patient-name-suggestions-new-consultation" class="list-group position-absolute w-50 z-1000" style="display: none;"></div>
                            </div>
                            <div class="col-md-3">
                                <label for="patientAge" class="form-label">Idade</label>
                                <input type="number" class="form-control" id="patientAge" min="0" readonly>
                            </div>
                            <div class="col-md-3">
                                <label for="patientGender" class="form-label">Sexo</label>
                                <select class="form-select" id="patientGender" disabled>
                                    <option selected>Selecione</option>
                                    <option value="Masculino">Masculino</option>
                                    <option value="Feminino">Feminino</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="patientCpfInput" class="form-label">CPF do Paciente</label>
                            <input type="text" class="form-control" id="patientCpfInput" placeholder="000.000.000-00" readonly>
                            <input type="hidden" id="patientIdNewConsultation">
                        </div>
                        <div class="mb-3">
                            <label for="patientReason" class="form-label">Motivo da Consulta</label>
                            <textarea class="form-control" id="patientReason" rows="3" placeholder="Sintomas, queixas, etc."></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="patientDiagnosis" class="form-label">Diagnóstico (CID-10)</label>
                            <textarea class="form-control" id="patientDiagnosis" rows="2" placeholder="Ex: R51 - Cefaleia"></textarea>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="mb-3">Receita Médica</h4>
                        <div class="mb-3">
                            <label for="prescribedMedications" class="form-label">Medicamentos Prescritos</label>
                            <textarea class="form-control" id="prescribedMedications" rows="5" placeholder="Ex: Paracetamol 500mg, 2x ao dia por 5 dias"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="observations" class="form-label">Observações</label>
                            <textarea class="form-control" id="observations" rows="3" placeholder="Instruções adicionais, repouso, etc."></textarea>
                        </div>
                        <button class="btn btn-primary" id="generatePdfBtn"><i class="fas fa-file-pdf"></i> Gerar Receita em PDF</button>
                    </div>

                    <div class="form-section mt-3">
                        <h4>Solicitar Novo Exame</h4>
                        <div class="mb-3">
                            <label for="examPatientName" class="form-label">Nome do Paciente</label>
                            <input type="text" class="form-control" id="examPatientName" placeholder="Nome Completo do Paciente">
                        </div>
                        <div class="mb-3">
                            <label for="examType" class="form-label">Tipo de Exame</label>
                            <input type="text" class="form-control" id="examType" placeholder="Ex: Hemograma Completo, Raio-X de Tórax">
                        </div>
                        <div class="mb-3">
                            <label for="examObservations" class="form-label">Observações para o Exame</label>
                            <textarea class="form-control" id="examObservations" rows="3" placeholder="Informações adicionais para o laboratório/técnico."></textarea>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-file-alt"></i> Gerar Pedido de Exame</button>
                    </div>

                    <div class="form-section text-center">
                        <button class="btn btn-success btn-lg"><i class="fas fa-save"></i> Finalizar e Salvar Consulta</button>
                    </div>
                </div>

                <!-- Seção: Prontuários (Histórico do Paciente) -->
                <div id="patient-history" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'patient-history') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-notes-medical"></i> Histórico do Paciente</h2>
                    <div class="form-section">
                        <div class="mb-3">
                            <label for="searchPatientInput" class="form-label">Buscar Paciente por Nome ou CPF</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="searchPatientInput" placeholder="Digite o nome ou CPF do paciente" oninput="searchPatients(this.value, 'patient-history')">
                                <button class="btn btn-outline-primary" type="button" id="searchPatientBtn"><i class="fas fa-search"></i> Buscar</button>
                            </div>
                            <div id="patient-name-suggestions-patient-history" class="list-group position-absolute w-50 z-1000" style="display: none;"></div>
                        </div>
                        <div id="patient-details" style="display: none;">
                            <h4>Detalhes do Paciente: <span id="displayPatientName"></span> (<span id="displayPatientCpf"></span>)</h4>
                            <p><strong>Idade:</strong> <span id="displayPatientAge"></span></p>
                            <p><strong>Sexo:</strong> <span id="displayPatientGender"></span></p>
                            <p><strong>Data de Nascimento:</strong> <span id="displayPatientBirthDate"></span></p>
                            <p><strong>Observações do Cadastro:</strong> <span id="displayPatientObservations"></span></p>
                            <h5>Histórico de Consultas e Registros</h5>
                            <ul class="list-group" id="consultation-history-list">
                                <!-- Conteúdo preenchido dinamicamente via JS/AJAX -->
                            </ul>
                        </div>
                        <div id="no-patient-found" class="alert alert-warning mt-3" style="display: none;">
                            Nenhum paciente encontrado com o nome ou CPF informado.
                        </div>
                    </div>
                </div>

                <!-- Seção: Agendamentos -->
                <div id="appointments" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'appointments') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-calendar-alt"></i> Agendamentos</h2>
                    <div class="form-section">
                        <h4>Agendamentos do Dia</h4>
                        <ul class="list-group mb-3">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>09:00</strong> - Ana Pereira (40 anos) - Consulta de Rotina
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success me-2"><i class="fas fa-check"></i> Atender</button>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i> Cancelar</button>
                                </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>10:30</strong> - Roberto Costa (55 anos) - Retorno de Exames
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success me-2"><i class="fas fa-check"></i> Atender</button>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i> Cancelar</button>
                                </div>
                            </li>
                        </ul>
                        <button class="btn btn-primary"><i class="fas fa-plus"></i> Novo Agendamento</button>
                    </div>
                    <div class="form-section mt-3">
                        <h4>Calendário de Agendamentos</h4>
                        <div class="alert alert-info">
                            Funcionalidade de calendário seria implementada aqui (requer biblioteca JS).
                        </div>
                    </div>
                </div>

                <!-- Seção: Atestados Médicos -->
                <div id="medical-certificates" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'medical-certificates') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-file-medical"></i> Gerar Atestado Médico</h2>
                    <div class="form-section">
                        <form id="attestForm">
                            <div class="mb-3">
                                <label for="attestPatientName" class="form-label">Nome do Paciente</label>
                                <input type="text" class="form-control" id="attestPatientName" name="attestPatientName" placeholder="Nome Completo do Paciente" required>
                            </div>
                            <div class="mb-3">
                                <label for="attestCpf" class="form-label">CPF do Paciente</label>
                                <input type="text" class="form-control" id="attestCpf" name="attestCpf" placeholder="000.000.000-00" required>
                            </div>
                            <div class="mb-3">
                                <label for="attestDate" class="form-label">Data do Atendimento</label>
                                <input type="date" class="form-control" id="attestDate" name="attestDate" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="attestDays" class="form-label">Número de Dias de Afastamento</label>
                                <input type="number" class="form-control" id="attestDays" name="attestDays" min="1" value="1" required>
                            </div>
                            <div class="mb-3">
                                <label for="symptomsInput" class="form-label">Sintomas/Condição para Sugestão de Motivo</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="symptomsInput" placeholder="Ex: Febre, tosse, dor de garganta">
                                    <button class="btn btn-outline-primary" type="button" id="suggestReasonBtn">Sugestão de Motivo ✨</button>
                                    <div class="spinner-border text-primary loading-spinner" role="status" id="attestLoadingSpinner">
                                        <span class="visually-hidden">Carregando...</span>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="attestReason" class="form-label">Motivo do Afastamento (Diagnóstico/CID)</label>
                                <textarea class="form-control" id="attestReason" name="attestReason" rows="3" placeholder="Ex: Repouso devido a gripe (CID J11.1)." required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="attestRelevantInfo" class="form-label">Informações Relevantes (Opcional)</label>
                                <textarea class="form-control" id="attestRelevantInfo" name="attestRelevantInfo" rows="3" placeholder="Qualquer informação adicional para o atestado."></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="attestLocal" class="form-label">Local de Emissão</label>
                                <input type="text" class="form-control" id="attestLocal" name="attestLocal" value="Franca-SP" placeholder="Cidade-UF">
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-file-pdf"></i> Gerar Atestado</button>
                        </form>
                        <div id="atestadoGerado" class="card p-4 mt-4 d-none">
                            <h5>Pré-visualização do Atestado:</h5>
                            <pre id="atestadoContent" class="bg-light p-3 rounded"></pre>
                            <button class="btn btn-secondary mt-3" onclick="printAttest()">Imprimir Atestado</button>
                        </div>
                    </div>
                </div>

                <!-- Seção: Exames -->
                <div id="exams" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'exams') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-x-ray"></i> Gerenciamento de Exames</h2>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-section">
                                <h4><i class="fas fa-inbox"></i> Arquivos de Exames Recebidos</h4>
                                <ul class="list-group" id="received-exams-list">
                                    <!-- Exemplo de arquivos de exames recebidos (conteúdo estático) -->
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>Resultado Hemograma - Ana Silva</strong> <small>(15/07/2025)</small><br>
                                            <small>Tipo: Exame Laboratorial</small>
                                        </div>
                                        <div>
                                            <button class="btn btn-sm btn-outline-primary me-2"><i class="fas fa-eye"></i> Ver</button>
                                            <button class="btn btn-sm btn-outline-success"><i class="fas fa-download"></i> Baixar</button>
                                        </div>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>Laudo Raio-X Tórax - João Costa</strong> <small>(14/07/2025)</small><br>
                                            <small>Tipo: Imagem Diagnóstica</small>
                                        </div>
                                        <div>
                                            <button class="btn btn-sm btn-outline-primary me-2"><i class="fas fa-eye"></i> Ver</button>
                                            <button class="btn btn-sm btn-outline-success"><i class="fas fa-download"></i> Baixar</button>
                                        </div>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>Relatório Cardiológico - Maria Oliveira</strong> <small>(13/07/2025)</small><br>
                                            <small>Tipo: Relatório Médico</small>
                                        </div>
                                        <div>
                                            <button class="btn btn-sm btn-outline-primary me-2"><i class="fas fa-eye"></i> Ver</button>
                                            <button class="btn btn-sm btn-outline-success"><i class="fas fa-download"></i> Baixar</button>
                                        </div>
                                    </li>
                                </ul>
                                <div class="mt-3 text-center">
                                    <button class="btn btn-info"><i class="fas fa-sync-alt"></i> Atualizar Caixa de Entrada</button>
                                </div>
                            </div>
                             <div class="form-section mt-4">
                                <h4>Exames Pendentes/Realizados</h4>
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>João Silva</strong> - Hemograma Completo (<small>Pedido em: 05/06/2025</small>)
                                        </div>
                                        <div>
                                            <span class="badge bg-warning text-dark me-2">Pendente</span>
                                            <button class="btn btn-sm btn-outline-info">Ver Pedido</button>
                                        </div>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>Fernanda Lima</strong> - Raio-X de Tórax (<small>Realizado em: 01/06/2025</small>)
                                        </div>
                                        <div>
                                            <span class="badge bg-success">Concluído</span>
                                            <button class="btn btn-sm btn-outline-primary"><i class="fas fa-file-medical-alt"></i> Ver Resultado</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Seção: Chat de Comunicação (SEM AJAX para envio/recebimento de mensagens de chat) -->
                <div id="chat-comunicacao" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'chat-comunicacao') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-comments"></i> Chat de Comunicação</h2>

                    <?php if (isset($_SESSION['chat_error'])): // Exibe mensagens de erro do chat ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['chat_error']; unset($_SESSION['chat_error']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['chat_success'])): // Exibe mensagens de sucesso do chat ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $_SESSION['chat_success']; unset($_SESSION['chat_success']); ?>
                        </div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="estabelecimentoSelect" class="form-label">Conversar com Estabelecimento de Exame:</label>
                        <select class="form-select" id="estabelecimentoSelect" onchange="window.location.href='acessmedicdata.php?section=chat-comunicacao&id_estabelecimento=' + this.value;">
                            <option value="">Selecione um Estabelecimento</option>
                            <?php foreach ($allEstabelecimentos as $estabelecimento_item): ?>
                                <option value="<?php echo htmlspecialchars($estabelecimento_item['id_estabelecimento']); ?>"
                                    <?php echo ($id_estabelecimento_selecionado == $estabelecimento_item['id_estabelecimento']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($estabelecimento_item['nome_estabelecimento']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <?php if ($id_estabelecimento_selecionado): // Exibe o chat se um estabelecimento estiver selecionado ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                Chat com: <strong><?php echo $nome_estabelecimento_selecionado; ?></strong>
                            </div>
                            <div class="card-body">
                                <div class="chat-box" id="chatBox">
                                    <?php if (empty($chat_mensagens)): // Mensagem se não houver histórico ?>
                                        <p class="text-muted text-center">Nenhuma mensagem nesta conversa.</p>
                                    <?php else: // Exibe as mensagens do histórico ?>
                                        <?php foreach ($chat_mensagens as $msg): ?>
                                            <?php
                                                // Determina se a mensagem foi enviada pelo médico logado.
                                                $is_sent_by_me = ($msg['id_remetente'] == $id_medico_logado && $msg['tipo_remetente'] == 'medico');
                                                // Adiciona a classe 'sent' se a mensagem foi enviada pelo médico logado.
                                                $message_class = $is_sent_by_me ? 'sent' : '';
                                                // Define o nome do remetente a ser exibido.
                                                $sender_name = $is_sent_by_me ? 'Você' : htmlspecialchars($msg['nome_remetente']);
                                            ?>
                                            <div class="chat-message <?php echo $message_class; ?>">
                                                <strong><?php echo $sender_name; ?>:</strong> <?php echo htmlspecialchars($msg['mensagem']); ?>
                                                <small><?php echo date('d/m/Y H:i', strtotime($msg['data_envio'])); ?></small>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>

                                <!-- Formulário de envio de mensagem (via POST, sem AJAX) -->
                                <form id="chatForm" method="POST" action="acessmedicdata.php?section=chat-comunicacao&id_estabelecimento=<?php echo htmlspecialchars($id_estabelecimento_selecionado); ?>" class="mt-3">
                                    <div class="input-group">
                                        <!-- Campo oculto para passar o ID do estabelecimento -->
                                        <input type="hidden" name="id_estabelecimento" value="<?php echo htmlspecialchars($id_estabelecimento_selecionado); ?>">
                                        <input type="text" class="form-control" name="mensagem" id="chatMessageInput" placeholder="Digite sua mensagem..." required>
                                        <!-- Botão de envio, com 'name="send_chat_message"' para identificação no PHP -->
                                        <button class="btn btn-primary" type="submit" name="send_chat_message"><i class="fas fa-paper-plane"></i> Enviar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php else: // Mensagem para selecionar um estabelecimento se nenhum estiver selecionado ?>
                        <div class="alert alert-info mt-3" role="alert">
                            Por favor, selecione um estabelecimento para iniciar uma conversa.
                        </div>
                    <?php endif; ?>
                </div>
                <!-- Fim da Seção de Chat -->

                <!-- Seção: Relatórios -->
                <div id="reports" class="content-section" style="<?php echo (isset($_GET['section']) && $_GET['section'] == 'reports') ? 'display: block;' : 'display: none;'; ?>">
                    <h2><i class="fas fa-chart-pie"></i> Relatórios</h2>
                    <p>Conteúdo da seção de Relatórios.</p>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal para o gráfico de atendimentos (ainda usa JavaScript/Chart.js) -->
    <div class="modal-custom" id="chartModal">
        <div class="modal-content-custom">
            <span class="close-button-custom" id="closeChartModalBtn">&times;</span>
            <h4>Atendimentos por Mês</h4>
            <canvas id="consultationsChart"></canvas>
        </div>
    </div>

    <!-- Bootstrap JS Bundle (inclui Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Seu arquivo JS personalizado (se houver, para outras funcionalidades) -->
    <script src="funpainelmed.js"></script>
    <script>
        // Funções de modal personalizadas (podem ser usadas por outras partes do site)
        function showModal(message) {
            document.getElementById('customAlertMessage').textContent = message;
            document.getElementById('customAlertModal').style.display = 'flex'; // Usa flex para centralizar
        }

        function closeModal() {
            document.getElementById('customAlertModal').style.display = 'none';
        }

        // Função para alternar a visibilidade das seções da página.
        // Esta função é chamada ao clicar nos links da barra lateral.
        function showSection(sectionId) {
            // Esconde todas as seções de conteúdo.
            document.querySelectorAll('.content-section').forEach(section => {
                section.style.display = 'none';
            });
            // Exibe a seção desejada.
            const activeSection = document.getElementById(sectionId);
            if (activeSection) {
                activeSection.style.display = 'block';
                // Se for a seção de chat, rola para o final do chatbox.
                if (sectionId === 'chat-comunicacao') {
                    const chatBox = document.getElementById('chatBox');
                    if (chatBox) {
                        chatBox.scrollTop = chatBox.scrollHeight;
                    }
                }
            }
        }

        // Função para verificar mensagens não lidas (ainda usa AJAX para notificação)
        function checkUnreadMessages() {
            // Obtém o ID do médico logado (passado do PHP para o JavaScript).
            const medicoId = <?php echo json_encode($id_medico_logado); ?>;
            const medicoType = 'medico';

            // Faz uma requisição AJAX para obter a contagem de mensagens não lidas.
            fetch(`acessmedicdata.php?action=get_unread_count&user_id=${medicoId}&user_type=${medicoType}`)
                .then(response => response.json()) // Converte a resposta para JSON.
                .then(unreadData => {
                    const badge = document.getElementById('unread-count-badge'); // O elemento do badge de notificação.
                    // Calcula o total de mensagens não lidas.
                    const totalUnread = unreadData.reduce((sum, item) => sum + parseInt(item.count), 0);

                    // Atualiza o badge com a contagem ou o esconde se não houver mensagens não lidas.
                    if (totalUnread > 0) {
                        badge.textContent = totalUnread;
                        badge.classList.remove('d-none');
                    } else {
                        badge.classList.add('d-none');
                    }
                })
                .catch(error => {
                    console.error('Erro ao verificar mensagens não lidas:', error);
                });
        }

        // Evento que dispara quando o DOM (Document Object Model) estiver completamente carregado.
        document.addEventListener('DOMContentLoaded', function() {
            // Obtém os parâmetros da URL para determinar a seção inicial.
            const urlParams = new URLSearchParams(window.location.search);
            const initialSection = urlParams.get('section') || 'dashboard'; // Padrão é 'dashboard'.
            showSection(initialSection); // Exibe a seção inicial.

            // Atualiza a classe 'active' nos links da barra lateral.
            document.querySelectorAll('.list-group-item').forEach(link => {
                link.classList.remove('active');
            });
            const navLink = document.getElementById(`menu-${initialSection}`);
            if (navLink) {
                navLink.classList.add('active');
            }

            // Rola para o final do chat box se a seção de chat estiver ativa.
            if (initialSection === 'chat-comunicacao') {
                const chatBox = document.getElementById('chatBox');
                if (chatBox) {
                    chatBox.scrollTop = chatBox.scrollHeight;
                }
                checkUnreadMessages(); // Verifica mensagens não lidas ao entrar na seção de chat.
            }

            // Adiciona listeners para os links do menu lateral.
            // Ao clicar, a página é recarregada com o parâmetro 'section' atualizado.
            document.getElementById('menu-dashboard').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=dashboard';
            });
            document.getElementById('menu-new-consultation').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=new-consultation';
            });
            document.getElementById('menu-patient-history').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=patient-history';
            });
            document.getElementById('menu-appointments').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=appointments';
            });
            document.getElementById('menu-medical-certificates').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=medical-certificates';
            });
            document.getElementById('menu-exams').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=exams';
            });
            document.getElementById('menu-chat-comunicacao').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=chat-comunicacao';
            });
            document.getElementById('menu-reports').addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = '?section=reports';
            });
            // O link de sair já tem href="login.php", então não precisa de listener extra.

            // Verifica mensagens não lidas periodicamente (ainda via AJAX).
            setInterval(checkUnreadMessages, 60000); // A cada 1 minuto.
            checkUnreadMessages(); // Verifica imediatamente ao carregar.
        });

        // Lógica para a busca de pacientes (ainda usa AJAX para sugestões)
        let currentPatientSearchTimeout = null;
        let currentPatientSearchController = null;

        function searchPatients(query, type) {
            const suggestionsBox = document.getElementById(`patient-name-suggestions-${type}`);
            // Limpa sugestões e esconde a caixa se a query for muito curta.
            if (query.length < 3) {
                suggestionsBox.innerHTML = '';
                suggestionsBox.style.display = 'none';
                return;
            }

            // Limpa timeouts e aborta requisições anteriores para otimização.
            if (currentPatientSearchTimeout) {
                clearTimeout(currentPatientSearchTimeout);
            }
            if (currentPatientSearchController) {
                currentPatientSearchController.abort();
            }

            // Define um timeout para atrasar a busca e evitar muitas requisições.
            currentPatientSearchTimeout = setTimeout(async () => {
                currentPatientSearchController = new AbortController();
                const signal = currentPatientSearchController.signal;

                try {
                    // Faz a requisição AJAX para buscar pacientes.
                    const response = await fetch(`acessmedicdata.php?action=search_patient&query=${encodeURIComponent(query)}`, { signal });
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const patients = await response.json();

                    suggestionsBox.innerHTML = ''; // Limpa sugestões anteriores.
                    if (patients.length > 0) {
                        // Adiciona cada paciente como uma sugestão clicável.
                        patients.forEach(patient => {
                            const item = document.createElement('a');
                            item.href = '#';
                            item.classList.add('list-group-item', 'list-group-item-action');
                            item.textContent = `${patient.nome} (CPF: ${patient.cpf}) - ${patient.idade} anos`;
                            item.onclick = (event) => {
                                event.preventDefault();
                                selectPatient(patient, type); // Preenche os campos com o paciente selecionado.
                                suggestionsBox.style.display = 'none'; // Esconde as sugestões.
                            };
                            suggestionsBox.appendChild(item);
                        });
                        suggestionsBox.style.display = 'block'; // Exibe a caixa de sugestões.
                    } else {
                        suggestionsBox.style.display = 'none'; // Esconde se não houver resultados.
                    }
                } catch (error) {
                    if (error.name === 'AbortError') {
                        console.log('Fetch de sugestões abortado');
                    } else {
                        console.error('Erro ao buscar pacientes para sugestões:', error);
                        suggestionsBox.style.display = 'none';
                    }
                } finally {
                    currentPatientSearchController = null;
                }
            }, 300); // Atraso de 300ms.
        }
        // Exporta a função para o escopo global para ser acessível via oninput no HTML.
        window.searchPatients = searchPatients;

        // Função para preencher os campos do paciente com os dados selecionados da sugestão.
        function selectPatient(patient, type) {
            if (type === 'new-consultation') {
                document.getElementById('patientName').value = patient.nome;
                document.getElementById('patientAge').value = patient.idade;
                document.getElementById('patientGender').value = patient.genero;
                document.getElementById('patientCpfInput').value = patient.cpf;
                document.getElementById('patientIdNewConsultation').value = patient.id_paciente;
                document.getElementById('patientCpf').textContent = patient.cpf; // Atualiza o CPF no timer
            } else if (type === 'patient-history') {
                document.getElementById('searchPatientInput').value = patient.nome;
                document.getElementById('displayPatientName').textContent = patient.nome;
                document.getElementById('displayPatientCpf').textContent = patient.cpf;
                document.getElementById('displayPatientAge').textContent = patient.idade;
                document.getElementById('displayPatientGender').textContent = patient.genero;
                document.getElementById('displayPatientBirthDate').textContent = patient.data_nascimento;
                document.getElementById('displayPatientObservations').textContent = patient.observacoes;
                document.getElementById('patient-details').style.display = 'block';
                document.getElementById('no-patient-found').style.display = 'none';
                loadPatientHistory(patient.id_paciente); // Carrega o histórico do paciente selecionado.
            }
        }
        window.selectPatient = selectPatient; // Exporta para o escopo global.

        // Função para carregar o histórico de consultas, atestados e exames de um paciente.
        async function loadPatientHistory(patientId) {
            try {
                const response = await fetch(`acessmedicdata.php?action=get_patient_history&id_paciente=${patientId}`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const history = await response.json();
                const consultationHistoryList = document.getElementById('consultation-history-list');
                consultationHistoryList.innerHTML = ''; // Limpa o histórico anterior.

                if (history.length > 0) {
                    // Adiciona cada registro do histórico à lista.
                    history.forEach(record => {
                        const li = document.createElement('li');
                        li.classList.add('list-group-item');
                        let detailsHtml = '';
                        // Itera sobre os detalhes do registro para formatá-los.
                        for (const key in record.details) {
                            detailsHtml += `<strong>${key}:</strong> ${record.details[key]}<br>`;
                        }
                        li.innerHTML = `
                            <div>
                                <strong>${record.type}</strong> - <small>${record.date}</small><br>
                                <button class="btn btn-sm btn-outline-info ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${record.type}${record.date.replace(/[^a-zA-Z0-9]/g, '')}" aria-expanded="false">
                                    Ver Detalhes
                                </button>
                                <div class="collapse mt-2" id="collapse${record.type}${record.date.replace(/[^a-zA-Z0-9]/g, '')}">
                                    <div class="card card-body">
                                        ${detailsHtml}
                                    </div>
                                </div>
                            </div>
                        `;
                        consultationHistoryList.appendChild(li);
                    });
                } else {
                    consultationHistoryList.innerHTML = '<li class="list-group-item">Nenhum histórico encontrado para este paciente.</li>';
                }
            } catch (error) {
                console.error('Erro ao carregar histórico do paciente:', error);
                showModal('Erro ao carregar histórico do paciente.');
            }
        }

        // Event listener para o botão de busca na seção "Histórico do Paciente".
        document.getElementById('searchPatientBtn').addEventListener('click', function() {
            const query = document.getElementById('searchPatientInput').value;
            searchPatients(query, 'patient-history');
        });

        // Lógica do Timer para a seção de Nova Consulta
        let timerInterval;
        let running = false;
        let startTime;
        let elapsedTime = 0;

        const timerDisplay = document.getElementById('timer');
        const startBtn = document.getElementById('startBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const resetBtn = document.getElementById('resetBtn');
        const consultationStatus = document.getElementById('consultationStatus');
        const patientCpfDisplay = document.getElementById('patientCpf');

        // Formata o tempo para exibição (HH:MM:SS).
        function formatTime(ms) {
            const hours = Math.floor(ms / 3600000);
            const minutes = Math.floor((ms % 3600000) / 60000);
            const seconds = Math.floor((ms % 60000) / 1000);

            return [hours, minutes, seconds]
                .map(unit => String(unit).padStart(2, '0'))
                .join(':');
        }

        // Atualiza o display do timer.
        function updateTimer() {
            const currentTime = Date.now();
            elapsedTime = currentTime - startTime;
            timerDisplay.textContent = formatTime(elapsedTime);
        }

        // Event listener para o botão "Iniciar" do timer.
        startBtn.addEventListener('click', () => {
            if (!running) {
                const patientCpfValue = document.getElementById('patientCpfInput').value;
                if (!patientCpfValue) {
                    showModal('Por favor, selecione um paciente antes de iniciar a consulta.');
                    return;
                }

                startTime = Date.now() - elapsedTime;
                timerInterval = setInterval(updateTimer, 1000); // Atualiza a cada segundo.
                running = true;
                consultationStatus.textContent = 'Em andamento';
                patientCpfDisplay.textContent = patientCpfValue;
            }
        });

        // Event listener para o botão "Pausar" do timer.
        pauseBtn.addEventListener('click', () => {
            if (running) {
                clearInterval(timerInterval); // Para o timer.
                running = false;
                consultationStatus.textContent = 'Pausada';
            }
        });

        // Event listener para o botão "Resetar" do timer.
        resetBtn.addEventListener('click', () => {
            clearInterval(timerInterval); // Para o timer.
            running = false;
            elapsedTime = 0;
            timerDisplay.textContent = formatTime(elapsedTime);
            consultationStatus.textContent = 'Primeira consulta';
            patientCpfDisplay.textContent = 'CPF não informado';
        });

        // Lógica para o atestado médico (utiliza API Gemini para sugestão, mas não AJAX para o fluxo principal)
        document.getElementById('attestForm').addEventListener('submit', async function(event) {
            event.preventDefault(); // Impede o envio padrão do formulário.

            const symptoms = document.getElementById('symptomsInput').value;
            const attestReason = document.getElementById('attestReason');
            const loadingSpinner = document.getElementById('attestLoadingSpinner');

            // Se houver sintomas e o campo de motivo estiver vazio, sugere um motivo via API.
            if (symptoms && !attestReason.value) {
                loadingSpinner.style.display = 'inline-block'; // Exibe o spinner.
                try {
                    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            contents: [{
                                role: "user",
                                parts: [{
                                    text: `Sugira um motivo de afastamento médico e um CID-10 para os seguintes sintomas: ${symptoms}. Formate como "Motivo: [motivo]. CID: [CID-10]."`
                                }]
                            }]
                        })
                    });
                    const result = await response.json();
                    // Preenche o campo de motivo com a sugestão da API.
                    if (result.candidates && result.candidates.length > 0 && result.candidates[0].content && result.candidates[0].content.parts && result.candidates[0].content.parts.length > 0) {
                        const suggestedReason = result.candidates[0].content.parts[0].text;
                        attestReason.value = suggestedReason;
                    } else {
                        showModal('Não foi possível gerar uma sugestão. Tente novamente.');
                    }
                } catch (error) {
                    console.error('Erro ao chamar a API Gemini para sugestão:', error);
                    showModal('Erro ao gerar sugestão de motivo. Verifique sua conexão ou tente novamente.');
                } finally {
                    loadingSpinner.style.display = 'none'; // Esconde o spinner.
                }
            }

            // Gerar o conteúdo do atestado para pré-visualização.
            const patientName = document.getElementById('attestPatientName').value;
            const attestDate = document.getElementById('attestDate').value;
            const attestDays = document.getElementById('attestDays').value;
            const attestReasonValue = attestReason.value;
            const attestRelevantInfo = document.getElementById('attestRelevantInfo').value;
            const attestLocal = document.getElementById('attestLocal').value;
            // Puxa os dados do médico do PHP (já disponíveis na página).
            const crmMedico = "<?php echo $crm_medico; ?>";
            const nomeMedico = "<?php echo $nome_medico; ?>";
            const especialidadeMedico = "<?php echo $especialidade_medico; ?>";

            // Monta o conteúdo do atestado.
            const attestContent = `
ATESTADO MÉDICO

Atesto para os devidos fins que o(a) paciente ${patientName},
necessita de afastamento de suas atividades por ${attestDays} dia(s),
a partir de ${new Date(attestDate).toLocaleDateString('pt-BR')}.

Motivo: ${attestReasonValue}

${attestRelevantInfo ? 'Informações Relevantes: ' + attestRelevantInfo : ''}

${attestLocal}, ${new Date().toLocaleDateString('pt-BR')}.

________________________________________
${nomeMedico}
${especialidadeMedico}
CRM: ${crmMedico}
            `;

            document.getElementById('atestadoContent').textContent = attestContent; // Exibe o conteúdo.
            document.getElementById('atestadoGerado').classList.remove('d-none'); // Torna a seção visível.
        });

        // Event listener para o botão "Sugestão de Motivo".
        document.getElementById('suggestReasonBtn').addEventListener('click', function() {
            // Dispara o evento de submit do formulário para acionar a lógica de sugestão.
            document.getElementById('attestForm').dispatchEvent(new Event('submit'));
        });

        // Função para imprimir o atestado.
        function printAttest() {
            const content = document.getElementById('atestadoContent').textContent;
            const printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>Atestado Médico</title>');
            printWindow.document.write('</head><body style="font-family: sans-serif; padding: 20px;">');
            printWindow.document.write('<pre>' + content + '</pre>');
            printWindow.document.close();
            printWindow.print(); // Abre a caixa de diálogo de impressão.
        }

        // Lógica do Modal do Gráfico (ainda usa Chart.js)
        const chartModal = document.getElementById('chartModal');
        const openChartModalBtn = document.getElementById('openChartModalBtn');
        const closeChartModalBtn = document.getElementById('closeChartModalBtn');
        let consultationsChart; // Para armazenar a instância do Chart.js.

        // Abre o modal do gráfico.
        openChartModalBtn.addEventListener('click', function() {
            chartModal.style.display = 'flex'; // Torna visível (usa flex para centralizar).
            renderChart(); // Renderiza o gráfico quando o modal abre.
        });

        // Fecha o modal do gráfico.
        closeChartModalBtn.addEventListener('click', function() {
            chartModal.style.display = 'none'; // Esconde o modal.
        });

        // Fecha o modal se clicar fora dele.
        window.addEventListener('click', function(event) {
            if (event.target == chartModal) {
                chartModal.style.display = 'none';
            }
        });

        // Renderiza o gráfico de atendimentos.
        function renderChart() {
            const ctx = document.getElementById('consultationsChart').getContext('2d');

            // Dados de exemplo (você substituiria isso por dados reais do banco de dados).
            const data = {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
                datasets: [{
                    label: 'Número de Atendimentos',
                    data: [15, 20, 18, 25, 22, 30, 28, 35, 32, 40, 38, 45], // Exemplo
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            };

            const options = {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            };

            // Destrói o gráfico existente se houver um para evitar sobreposição.
            if (consultationsChart) {
                consultationsChart.destroy();
            }

            consultationsChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: options
            });
        }
    </script>
</body>
</html>