// Função para alternar a exibição das seções de conteúdo
// Adiciona suporte para acessar dados do paciente (acesspacdata)
function showSection(sectionId, clickedElement) {
    // Se a seção for 'acesspacdata', busca e exibe os dados do paciente
    if (sectionId === 'acesspacdata') {
        loadPacienteData();
    }

    // Remove 'active' de todas as seções e esconde-as
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });
    // Remove 'active' de todos os itens da sidebar
    document.querySelectorAll('.sidebar-item').forEach(item => {
        item.classList.remove('active');
    });

    // Adiciona 'active' à seção clicada e a mostra
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        targetSection.style.display = 'block';
    }
    // Adiciona 'active' ao item da sidebar clicado
    if (clickedElement) {
        clickedElement.classList.add('active');
    }

    // Atualiza a contagem de notificações se a seção de notificações for ativada
    if (sectionId === 'notificacoes') {
        updateNotificationCount();
    }
}

// Função para carregar dados do paciente (exemplo)
function loadPacienteData() {
    const pacDataDiv = document.getElementById('acesspacdata-content');
    if (!pacDataDiv) return;
    // Simulação de dados do paciente
    const paciente = {
        nome: 'João da Silva',
        idade: 42,
        cpf: '123.456.789-00',
        email: 'joao@email.com',
        telefone: '(11) 99999-8888',
        endereco: 'Rua Exemplo, 123, São Paulo - SP'
    };
    pacDataDiv.innerHTML = `
        <h3 class="font-bold text-lg mb-2">Dados do Paciente</h3>
        <ul class="list-disc pl-5">
            <li><strong>Nome:</strong> ${paciente.nome}</li>
            <li><strong>Idade:</strong> ${paciente.idade}</li>
            <li><strong>CPF:</strong> ${paciente.cpf}</li>
            <li><strong>Email:</strong> ${paciente.email}</li>
            <li><strong>Telefone:</strong> ${paciente.telefone}</li>
            <li><strong>Endereço:</strong> ${paciente.endereco}</li>
        </ul>
    `;
}
function showSection(sectionId, clickedElement) {
    // Remove 'active' de todas as seções e esconde-as
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none'; // Esconde a seção
    });
    // Remove 'active' de todos os itens da sidebar
    document.querySelectorAll('.sidebar-item').forEach(item => {
        item.classList.remove('active');
    });

    // Adiciona 'active' à seção clicada e a mostra
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        targetSection.style.display = 'block'; // Mostra a seção
    }
    // Adiciona 'active' ao item da sidebar clicado
    if (clickedElement) {
        clickedElement.classList.add('active');
    }

    // Atualiza a contagem de notificações se a seção de notificações for ativada
    if (sectionId === 'notificacoes') {
        updateNotificationCount();
    }
}

// Troca de imagem de perfil
function changeProfilePic() {
    const input = document.getElementById('profilePicInput');
    const img = document.getElementById('profilePic');
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = e => img.src = e.target.result;
        reader.readAsDataURL(file);
    }
}

// Toggle modo claro/escuro
function toggleDarkMode() {
    document.documentElement.classList.toggle('dark');
}

// Gerar nova receita (apenas adiciona um item simulado à lista)
function gerarNovaReceita() {
    const lista = document.getElementById('listaReceitas');
    const newRow = document.createElement('tr');
    const today = new Date();
    const formattedDate = today.toLocaleDateString('pt-BR'); // Ex: 14/06/2025

    newRow.classList.add('border-b', 'border-gray-200', 'dark:border-gray-600', 'last:border-b-0');
    newRow.innerHTML = `
        <td class="py-3 px-4">Medicamento Genérico (X mg)</td>
        <td class="py-3 px-4">${formattedDate}</td>
        <td class="py-3 px-4"><span class="bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Ativa</span></td>
        <td class="py-3 px-4">
            <button class="text-secondary hover:underline text-sm" onclick="openDetailsModal('recipe', 'Medicamento Genérico (X mg)', '${formattedDate}', 'Esta é uma nova receita genérica para demonstração. Posologia: 1 comprimido ao dia. Uso por 30 dias.', 'N/A')"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
            <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Medicamento Genérico (X mg)', '${formattedDate}', 'Esta é uma nova receita genérica para demonstração. Posologia: 1 comprimido ao dia. Uso por 30 dias.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
        </td>
    `;
    lista.prepend(newRow); // Adiciona no início da lista
    alert('Sua solicitação de nova receita foi enviada e está aguardando análise médica. Você receberá uma notificação quando ela for aprovada.');
}

// Função para submeter feedback
function submitFeedback(event) {
    event.preventDefault(); // Evita o recarregamento da página
    const subject = document.getElementById('feedbackSubject').value;
    const message = document.getElementById('feedbackMessage').value;

    if (subject.trim() === '' || message.trim() === '') {
        alert('Por favor, preencha o assunto e a mensagem do seu feedback.');
        return;
    }

    // Simulação de envio
    console.log('Feedback enviado:', { subject, message });
    alert('Obrigado pelo seu feedback! Recebemos sua mensagem e entraremos em contato se necessário.');

    // Limpa o formulário
    document.getElementById('feedbackSubject').value = '';
    document.getElementById('feedbackMessage').value = '';
}

// Funções para Notificações
function updateNotificationCount() {
    const notificationItems = document.querySelectorAll('#notifications-list > div');
    let unreadCount = 0;
    notificationItems.forEach(item => {
        // Only count notifications that are not marked as read (i.e., don't have bg-gray-100)
        if (!item.classList.contains('bg-gray-100') && !item.classList.contains('dark:bg-gray-700')) {
            unreadCount++;
        }
    });
    const notificationBadge = document.getElementById('notification-count');
    if (unreadCount > 0) {
        notificationBadge.textContent = unreadCount;
        notificationBadge.classList.remove('hidden');
    } else {
        notificationBadge.classList.add('hidden');
    }
}

function markNotificationAsRead(element) {
    // Change background and text color to indicate it's read
    element.classList.remove('bg-blue-50', 'bg-green-50', 'bg-orange-50', 'dark:bg-blue-800/20', 'dark:bg-green-800/20', 'dark:bg-orange-800/20');
    element.classList.add('bg-gray-100', 'dark:bg-gray-700'); // Use dark:bg-gray-700 for dark mode
    
    // Change icon color to gray
    const icon = element.querySelector('i');
    if (icon) {
        icon.classList.remove('text-blue-600', 'text-green-600', 'text-orange-600', 'dark:text-blue-400', 'dark:text-green-400', 'dark:text-orange-400');
        icon.classList.add('text-gray-500', 'dark:text-gray-400');
    }

    // Remove the "Mark as read" button
    const readButton = element.querySelector('button');
    if (readButton) {
        readButton.remove();
    }
    
    // Update the notification count after marking as read
    updateNotificationCount();
}


function clearAllNotifications() {
    const notificationsList = document.getElementById('notifications-list');
    notificationsList.innerHTML = '<p class="text-center text-gray-500 dark:text-gray-400">Nenhuma notificação.</p>';
    updateNotificationCount(); // Update the count after clearing
    alert('Todas as notificações foram limpas.');
}

// Funções do Modal de Detalhes
function openDetailsModal(type, title, date, description, downloadLink) {
    const modal = document.getElementById('detailsModal');
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalDate').textContent = date;
    // Replace '\n' with <br> for proper line breaks in HTML
    document.getElementById('modalDescription').innerHTML = description.replace(/\\n/g, '<br>');

    const downloadBtn = document.getElementById('modalDownloadLink');
    const noPdfMsg = document.getElementById('modalNoPdfMessage');

    if (downloadLink && downloadLink !== 'N/A') {
        downloadBtn.href = downloadLink;
        downloadBtn.classList.remove('hidden');
        noPdfMsg.classList.add('hidden');
    } else {
        downloadBtn.classList.add('hidden');
        noPdfMsg.classList.remove('hidden');
    }

    // Use 'active' class for visibility controlled by CSS
    modal.classList.add('active');
}

function closeDetailsModal() {
    // Use 'active' class for visibility controlled by CSS
    document.getElementById('detailsModal').classList.remove('active');
}

// Fechar modal ao clicar fora ou pressionar ESC
document.getElementById('detailsModal').addEventListener('click', function(event) {
    // Check if the click was on the overlay itself, not the modal content
    if (event.target === this) {
        closeDetailsModal();
    }
});
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && document.getElementById('detailsModal').classList.contains('active')) {
        closeDetailsModal();
    }
});

// Function to toggle description for specialties
function toggleDesc(id) {
    const desc = document.getElementById(id);
    const icon = document.getElementById(id.replace('Desc', 'Icon'));
    if (desc.classList.contains('hidden')) {
        desc.classList.remove('hidden');
        icon.classList.remove('bi-plus-lg');
        icon.classList.add('bi-dash-lg');
    } else {
        desc.classList.add('hidden');
        icon.classList.remove('bi-dash-lg');
        icon.classList.add('bi-plus-lg');
    }
}

// --- Gemini AI Assistant Logic ---
const chatMessagesDiv = document.getElementById('chat-messages');
const chatInput = document.getElementById('ai-chat-input');
const sendButton = document.getElementById('ai-chat-send-button');
const loadingSpinner = document.getElementById('ai-loading-spinner');

sendButton.addEventListener('click', sendMessage);
chatInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

async function sendMessage() {
    const userMessage = chatInput.value.trim();
    if (userMessage === '') return;

    // Add user message to chat
    appendMessage(userMessage, 'user');
    chatInput.value = '';
    loadingSpinner.classList.remove('hidden'); // Show spinner

    try {
        // Call Gemini API - IMPORTANT: Replace with your actual secure API key and backend handling
        // Directly exposing API_KEY in client-side code is NOT recommended for production.
        // Use a backend proxy to handle API calls securely.
        let chatHistory = [];
        chatHistory.push({ role: "user", parts: [{ text: userMessage }] });

        const payload = { contents: chatHistory };
        // This API Key is exposed for demonstration purposes as per the user's provided code.
        // For production, this should be handled server-side to prevent exposure.
        const apiKey = "AIzaSyCrcQKq0_MYs4OhIqNRt2kItaSi3PWfYWE"; 
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await response.json();
        if (result.candidates && result.candidates.length > 0 &&
            result.candidates[0].content && result.candidates[0].content.parts &&
            result.candidates[0].content.parts.length > 0) {
            const aiResponse = result.candidates[0].content.parts[0].text;
            appendMessage(aiResponse, 'ai');
        } else {
            appendMessage('Desculpe, não consegui gerar uma resposta. Por favor, tente novamente.', 'ai');
            console.error("Unexpected API response structure:", result);
        }
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        appendMessage('Ocorreu um erro ao conectar com o assistente. Por favor, tente novamente mais tarde.', 'ai');
    } finally {
        loadingSpinner.classList.add('hidden'); // Hide spinner
        chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight; // Scroll to bottom
    }
}

function appendMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message-bubble', 'p-2', 'rounded-lg', 'max-w-[80%]'); // Added common styles here

    if (sender === 'user') {
        messageDiv.classList.add('message-user', 'self-end', 'bg-purple-500', 'text-white');
    } else {
        messageDiv.classList.add('message-ai', 'self-start', 'bg-blue-500', 'text-white');
    }
    messageDiv.textContent = text;
    chatMessagesDiv.appendChild(messageDiv);
    chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight; // Scroll to bottom
}

// Inicializa a exibição do dashboard e a contagem de notificações ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
    showSection('dashboard', document.getElementById('nav-dashboard'));
    updateNotificationCount(); // Chamar ao carregar para exibir o número inicial
});