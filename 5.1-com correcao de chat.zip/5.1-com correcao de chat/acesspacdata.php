<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Paciente - Aglix MedTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="stylemenupac.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3b82f6', // Azul principal para botões, links, etc.
                        secondary: '#8b5cf6', // Roxo secundário para detalhes, renovar
                        darkBg: '#1a202c', // Fundo escuro para o modo dark
                        darkCard: '#2d3748', // Cor de card no modo dark
                        darkText: '#e2e8f0', // Texto no modo dark
                        lightBg: '#f8f9fa', // Fundo claro
                        lightCard: '#ffffff', // Cor de card no modo claro
                        lightText: '#2d3748' // Texto no modo claro
                    },
                    fontFamily: {
                        sans: ['Arial', 'Helvetica', 'sans-serif'], // Fontes mais profissionais
                    },
                },
            },
            darkMode: 'class', // Habilita o modo escuro com a classe 'dark' no html
        };
    </script>
    <script src="https://kit.fontawesome.com/a2d9d5eada.js" crossorigin="anonymous"></script>
    <style>
        /* Custom styles for modals and potential adjustments for form height */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            visibility: hidden;
            opacity: 0;
            transition: visibility 0s, opacity 0.3s;
        }
        .modal-overlay.active {
            visibility: visible;
            opacity: 1;
        }
        .modal-content {
            background-color: var(--lightCard); /* Use CSS variable for consistency */
            color: var(--lightText);
            padding: 2rem;
            border-radius: 0.75rem;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
            position: relative;
            max-width: 500px;
            width: 90%;
            transform: translateY(-20px);
            transition: transform 0.3s;
        }
        .dark .modal-content {
            background-color: var(--darkCard);
            color: var(--darkText);
        }
        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }
        .modal-close-button {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--lightText);
        }
        .dark .modal-close-button {
            color: var(--darkText);
        }
        /* Adjustments for agendar-consulta form height */
        #agendar-consulta .grid-cols-2 > div {
            margin-bottom: 1rem; /* Add some space between form fields */
        }
        #agendar-consulta .space-y-4 > div:last-child {
            margin-bottom: 0; /* Remove extra margin for the last element before button */
        }
        .chat-messages {
            max-height: 300px; /* Limit chat messages height */
            overflow-y: auto;
            border: 1px solid var(--gray-300);
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
            background-color: var(--lightBg);
        }
        .dark .chat-messages {
            background-color: var(--darkBg);
        }
        .message-bubble {
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
            max-width: 80%;
        }
        .message-ai {
            background-color: var(--primary);
            color: white;
            align-self: flex-start;
            margin-right: auto;
        }
        .message-user {
            background-color: var(--secondary);
            color: white;
            align-self: flex-end;
            margin-left: auto;
        }
        .chat-input-area {
            display: flex;
            align-items: center;
        }
        .chat-input {
            flex-grow: 1;
            padding: 0.75rem;
            border: 1px solid var(--gray-300);
            border-radius: 0.5rem;
            margin-right: 0.5rem;
            background-color: var(--lightCard);
            color: var(--lightText);
        }
        .dark .chat-input {
            background-color: var(--darkCard);
            color: var(--darkText);
            border-color: var(--gray-600);
        }
        .chat-send-button {
            background-color: var(--primary);
            color: white;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .chat-send-button:hover {
            background-color: var(--blue-700);
        }
        .loading-spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
            margin-left: 0.5rem;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>

<body class="bg-lightBg dark:bg-darkBg text-lightText dark:text-darkText font-sans">

    <div class="flex flex-col md:flex-row min-h-screen">

        <aside class="w-full md:w-64 bg-lightCard dark:bg-darkCard shadow-lg flex flex-col p-4 md:p-6 sticky top-0 h-auto md:h-screen z-10">
            <div class="flex flex-col items-center border-b border-gray-200 dark:border-gray-700 pb-4 mb-4">
                <input type="file" id="profilePicInput" class="hidden" accept="image/*" onchange="changeProfilePic()">
                <img id="profilePic" src="https://placehold.co/100x100/3b82f6/ffffff?text=FP" alt="Foto de Perfil" class="w-24 h-24 rounded-full object-cover border-2 border-primary shadow-md">
                <button onclick="document.getElementById('profilePicInput').click()" class="mt-2 text-sm text-primary hover:underline font-medium">
                    <i class="fas fa-camera mr-1"></i> Alterar Foto
                </button>
                <h2 class="text-xl font-bold mt-3">Teste Pessoa</h2>
                <p class="text-xs text-gray-500 dark:text-gray-500 mt-2">
                    <i class="fas fa-id-card mr-1"></i> CPF: 123.456.789-00
                </p>
            </div>

            <nav class="flex flex-col flex-grow space-y-2">
                <a href="#" id="nav-dashboard" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 active" onclick="showSection('dashboard', this)">
                    <i class="fas fa-chart-line text-lg"></i>Visão Geral
                </a>
                <a href="#" id="nav-agendar-consulta" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('agendar-consulta', this)">
                    <i class="fas fa-calendar-plus text-lg"></i> Agendar Consulta
                </a>
                <a href="#" id="nav-meus-exames" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('meus-exames', this)">
                    <i class="fas fa-flask-vial text-lg"></i> Meus Exames
                </a>
                <a href="#" id="nav-minhas-receitas" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('minhas-receitas', this)">
                    <i class="fas fa-notes-medical text-lg"></i> Minhas Receitas
                </a>
                <a href="#" id="nav-medicamentos-uso" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('medicamentos-uso', this)">
                    <i class="fas fa-pills text-lg"></i> Medicamentos em Uso
                </a>
                <a href="#" id="nav-consultas-anteriores" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('consultas-anteriores', this)">
                    <i class="fas fa-history text-lg"></i> Consultas Anteriores
                </a>
                <a href="#" id="nav-notificacoes" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('notificacoes', this)">
                    <i class="fas fa-bell text-lg"></i> Notificações <span class="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full" id="notification-count">3</span>
                </a>
                <a href="#" id="nav-feedback" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('feedback', this)">
                    <i class="fas fa-comment-dots text-lg"></i> Enviar Feedback
                </a>
                <a href="#" id="nav-ai-assistant" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('ai-assistant', this)">
                    <i class="fas fa-robot text-lg"></i> Assistente de Saúde (IA)
                </a>
                <a href="#" id="nav-configuracoes" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('configuracoes', this)">
                    <i class="fas fa-cogs text-lg"></i> Configurações
                </a>
            </nav>

            <div class="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
                <button onclick="toggleDarkMode()" class="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 w-full text-left text-sm font-medium">
                    <i class="fas fa-adjust text-lg"></i> Modo Claro/Escuro
                </button>
                <a href="#" class="flex items-center gap-3 p-3 rounded-lg hover:bg-red-100 dark:hover:bg-red-800/50 text-red-600 dark:text-red-400 w-full text-left text-sm font-medium mt-2">
                    <i class="fas fa-sign-out-alt text-lg"></i> Sair
                </a>
            </div>
        </aside>

        <main class="flex-1 p-6 md:p-8 overflow-y-auto">
            <header class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
                <h1 class="text-3xl font-extrabold text-gray-800 dark:text-darkText">
                    Bem-vindo(a), <span class="text-primary">Teste Pessoa!</span>
                </h1>
                <div class="mt-4 sm:mt-0 flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <i class="fas fa-calendar-day mr-2"></i> Hoje: Sexta-feira, 14 de junho de 2025
                </div>
            </header>

            <section id="dashboard" class="content-section active bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-tachometer-alt mr-3 text-primary"></i> Visão Geral
                </h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="bg-primary/10 border-l-4 border-primary p-4 rounded-lg shadow-sm">
                        <h3 class="text-lg font-semibold text-primary mb-2 flex items-center"><i class="fas fa-calendar-check mr-2"></i> Próxima Consulta</h3>
                        <p class="text-gray-700 dark:text-gray-300">
                            <span class="font-medium">26 de julho de 2025 às 10:30</span><br>
                            Com <span class="font-medium">Dra. Roberta Silva</span> (Clínica Geral)
                        </p>
                        <a href="agendamento.html" class="mt-3 inline-block text-primary hover:underline text-sm font-semibold">
                            <i class="fas fa-external-link-alt mr-1"></i> Ver detalhes
                        </a>
                    </div>
                    <div class="bg-green-100 dark:bg-green-800/30 border-l-4 border-green-500 p-4 rounded-lg shadow-sm">
                        <h3 class="text-lg font-semibold text-green-700 dark:text-green-400 mb-2 flex items-center"><i class="fas fa-flask-vial mr-2"></i> Último Exame</h3>
                        <p class="text-gray-700 dark:text-gray-300">
                            <span class="font-medium">Hemograma Completo</span><br>
                            Realizado em: <span class="font-medium">20 de maio de 2025</span>
                        </p>
                        <button class="mt-3 inline-block text-green-700 dark:text-green-400 hover:underline text-sm font-semibold" onclick="openDetailsModal('exam', 'Hemograma Completo', '20 de maio de 2025', 'Normal. Sem alterações significativas. Valores dentro da faixa de referência.', 'Link para PDF do Hemograma')">
                            <i class="fas fa-file-alt mr-1"></i> Ver Detalhes
                        </button>
                    </div>
                    <div class="bg-purple-100 dark:bg-purple-800/30 border-l-4 border-purple-500 p-4 rounded-lg shadow-sm">
                        <h3 class="text-lg font-semibold text-purple-700 dark:text-purple-400 mb-2 flex items-center"><i class="fas fa-notes-medical mr-2"></i> Última Receita</h3>
                        <p class="text-gray-700 dark:text-gray-300">
                            <span class="font-medium">Paracetamol 500mg</span><br>
                            Prescrita em: <span class="font-medium">05 de junho de 2025</span>
                        </p>
                        <button class="mt-3 inline-block text-purple-700 dark:text-purple-400 hover:underline text-sm font-semibold" onclick="openDetailsModal('recipe', 'Paracetamol 500mg', '05 de junho de 2025', 'Tomar 1 comprimido a cada 6 horas, conforme a dor. Não exceder 4 comprimidos por dia. Usar por 5 dias.', 'Link para PDF do Paracetamol')">
                            <i class="fas fa-file-alt mr-1"></i> Ver Detalhes
                        </button>
                    </div>
                </div>
            </section>
            <section id="agendar-consulta" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-calendar-plus mr-3 text-primary"></i> Agendamento Médico
                </h2>
                <form action="gerar_comprovante.php" method="POST" class="bg-white dark:bg-darkCard p-6 rounded-lg shadow-lg space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="nome">Nome</label>
                            <input name="nome" id="nome" placeholder="Nome" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="sobrenome">Sobrenome</label>
                            <input name="sobrenome" id="sobrenome" placeholder="Sobrenome" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="idade">Idade</label>
                            <input name="idade" id="idade" type="number" placeholder="Idade" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="cpf">CPF</label>
                            <input name="cpf" id="cpf" placeholder="CPF" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="dataNascimento">Data de Nascimento</label>
                            <input name="data_nascimento" id="dataNascimento" type="date" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="motivo">Motivo da Consulta</label>
                            <input name="motivo" id="motivo" placeholder="Motivo da Consulta" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="urgencia">Nível de Urgência</label>
                            <select name="urgencia" id="urgencia" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" required>
                                <option value="">Selecione</option>
                                <option value="Baixa">Baixa</option>
                                <option value="Média">Média</option>
                                <option value="Alta">Alta</option>
                                <option value="Emergência">Emergência</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <p class="mb-2 font-medium text-gray-700 dark:text-gray-400">Especialidades:</p>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                            <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-100 dark:border-blue-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('cardioDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-heart-pulse text-blue-600 dark:text-blue-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Cardiologia" class="mr-2 align-middle"> Cardiologia
                                        </label>
                                    </div>
                                    <i id="cardioIcon" class="bi bi-plus-lg text-blue-600 dark:text-blue-400 text-xl"></i>
                                </div>
                                <p id="cardioDesc" class="mt-2 text-blue-700 dark:text-blue-300 text-sm hidden">
                                    Cardiologia é a especialidade médica que cuida do diagnóstico e tratamento das doenças do coração e do sistema circulatório.
                                </p>
                            </div>

                            <div class="bg-green-50 dark:bg-green-800/20 p-4 rounded-lg border border-green-100 dark:border-green-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('uroDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-gender-male text-green-600 dark:text-green-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Urologia" class="mr-2 align-middle"> Urologia
                                        </label>
                                    </div>
                                    <i id="uroIcon" class="bi bi-plus-lg text-green-600 dark:text-green-400 text-xl"></i>
                                </div>
                                <p id="uroDesc" class="mt-2 text-green-700 dark:text-green-300 text-sm hidden">
                                    Urologia é a especialidade médica que trata do sistema urinário e do sistema reprodutor masculino.
                                </p>
                            </div>

                            <div class="bg-red-50 dark:bg-red-800/20 p-4 rounded-lg border border-red-100 dark:border-red-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('dermaDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-patch-check text-red-600 dark:text-red-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Dermatologia" class="mr-2 align-middle"> Dermatologia
                                        </label>
                                    </div>
                                    <i id="dermaIcon" class="bi bi-plus-lg text-red-600 dark:text-red-400 text-xl"></i>
                                </div>
                                <p id="dermaDesc" class="mt-2 text-red-700 dark:text-red-300 text-sm hidden">
                                    Dermatologia é o ramo da medicina que estuda, diagnostica e trata doenças da pele, cabelo e unhas.
                                </p>
                            </div>

                            <div class="bg-purple-50 dark:bg-purple-800/20 p-4 rounded-lg border border-purple-100 dark:border-purple-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('oftalmoDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-eye text-purple-600 dark:text-purple-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Oftalmologia" class="mr-2 align-middle"> Oftalmologia
                                        </label>
                                    </div>
                                    <i id="oftalmoIcon" class="bi bi-plus-lg text-purple-600 dark:text-purple-400 text-xl"></i>
                                </div>
                                <p id="oftalmoDesc" class="mt-2 text-purple-700 dark:text-purple-300 text-sm hidden">
                                    Oftalmologia trata das doenças e cuidados dos olhos, incluindo exames, cirurgias e correções visuais.
                                </p>
                            </div>

                            <div class="bg-orange-50 dark:bg-orange-800/20 p-4 rounded-lg border border-orange-100 dark:border-orange-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('ortopediaDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-bandaid text-orange-600 dark:text-orange-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Ortopedia" class="mr-2 align-middle"> Ortopedia
                                        </label>
                                    </div>
                                    <i id="ortopediaIcon" class="bi bi-plus-lg text-orange-600 dark:text-orange-400 text-xl"></i>
                                </div>
                                <p id="ortopediaDesc" class="mt-2 text-orange-700 dark:text-orange-300 text-sm hidden">
                                    Ortopedia cuida das doenças e lesões do sistema musculoesquelético, como ossos, articulações e músculos.
                                </p>
                            </div>

                            <div class="bg-pink-50 dark:bg-pink-800/20 p-4 rounded-lg border border-pink-100 dark:border-pink-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('ginecoDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-gender-female text-pink-600 dark:text-pink-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Ginecologia" class="mr-2 align-middle"> Ginecologia
                                        </label>
                                    </div>
                                    <i id="ginecoIcon" class="bi bi-plus-lg text-pink-600 dark:text-pink-400 text-xl"></i>
                                </div>
                                <p id="ginecoDesc" class="mt-2 text-pink-700 dark:text-pink-300 text-sm hidden">
                                    Ginecologia é a especialidade médica que cuida da saúde do sistema reprodutor feminino.
                                </p>
                            </div>

                            <div class="bg-teal-50 dark:bg-teal-800/20 p-4 rounded-lg border border-teal-100 dark:border-teal-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('clinicoDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-file-earmark-medical text-teal-600 dark:text-teal-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Clínico Geral" class="mr-2 align-middle"> Clínico Geral
                                        </label>
                                    </div>
                                    <i id="clinicoIcon" class="bi bi-plus-lg text-teal-600 dark:text-teal-400 text-xl"></i>
                                </div>
                                <p id="clinicoDesc" class="mt-2 text-teal-700 dark:text-teal-300 text-sm hidden">
                                    O clínico geral é o médico que faz o primeiro atendimento e encaminha para especialistas quando necessário.
                                </p>
                            </div>

                            <div class="bg-yellow-50 dark:bg-yellow-800/20 p-4 rounded-lg border border-yellow-100 dark:border-yellow-700">
                                <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('endocrinoDesc')">
                                    <div class="flex items-center">
                                        <i class="bi bi-clipboard-pulse text-yellow-600 dark:text-yellow-400 text-2xl mr-3"></i>
                                        <label class="text-base font-semibold cursor-pointer">
                                            <input type="checkbox" name="especialidades[]" value="Endocrinologia" class="mr-2 align-middle"> Endocrinologia
                                        </label>
                                    </div>
                                    <i id="endocrinoIcon" class="bi bi-plus-lg text-yellow-600 dark:text-yellow-400 text-xl"></i>
                                </div>
                                <p id="endocrinoDesc" class="mt-2 text-yellow-700 dark:text-yellow-300 text-sm hidden">
                                    Endocrinologia trata dos hormônios e glândulas, como diabetes e distúrbios metabólicos.
                                </p>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-blue-600 text-white p-3 rounded-md hover:bg-blue-700 transition-colors duration-300 flex items-center justify-center gap-2">
                        <i class="fas fa-file-pdf"></i> Gerar Comprovante
                    </button>
                </form>
            </section>

            <section id="meus-exames" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-flask-vial mr-3 text-primary"></i> Meus Exames
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Histórico de Exames</h3>
                    <a href="agendamento.html" class="btn-primary-link text-primary hover:underline flex items-center gap-2 font-medium">
                        <i class="fas fa-calendar-plus"></i> Agendar Novo Exame
                    </a>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Tipo de Exame</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Data</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Hemograma Completo</td>
                                <td class="py-3 px-4">25/05/2025</td>
                                <td class="py-3 px-4"><span class="bg-yellow-100 text-yellow-800 dark:bg-yellow-800/30 dark:text-yellow-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Agendado</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-primary hover:underline text-sm" onclick="openDetailsModal('exam', 'Hemograma Completo', '25 de maio de 2025', 'Exame de rotina. Necessário jejum de 8h. Favor comparecer 15 minutos antes.', 'N/A')"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Raio-X de Tórax</td>
                                <td class="py-3 px-4">30/05/2025</td>
                                <td class="py-3 px-4"><span class="bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Concluído</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-green-700 dark:text-green-400 hover:underline text-sm" onclick="openDetailsModal('exam', 'Raio-X de Tórax', '30 de maio de 2025', 'Resultados normais. Pulmões limpos.', 'Link para PDF do Raio-X')"><i class="fas fa-download mr-1"></i> Baixar</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Ultrassonografia Abdominal</td>
                                <td class="py-3 px-4">10/06/2025</td>
                                <td class="py-3 px-4"><span class="bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Concluído</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-green-700 dark:text-green-400 hover:underline text-sm" onclick="openDetailsModal('exam', 'Ultrassonografia Abdominal', '10 de junho de 2025', 'Sem alterações significativas nos órgãos abdominais. Necessário jejum de 6h.', 'Link para PDF da Ultrassonografia')"><i class="fas fa-download mr-1"></i> Baixar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="minhas-receitas" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-notes-medical mr-3 text-primary"></i> Minhas Receitas
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Receitas Ativas</h3>
                    <button onclick="gerarNovaReceita()" class="btn-primary flex items-center gap-2">
                        <i class="fas fa-plus"></i> Solicitar Nova Receita
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Medicamento</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Data da Prescrição</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="listaReceitas">
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Carbonato de Lítio (300mg)</td>
                                <td class="py-3 px-4">10/01/2025</td>
                                <td class="py-3 px-4"><span class="bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Ativa</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Carbonato de Lítio (300mg)', '10 de janeiro de 2025', 'Tomar 1 cápsula via oral, 2 vezes ao dia (a cada 12h), após as refeições. Uso contínuo. Monitorar níveis séricos de lítio.', 'Link para PDF da Receita de Lítio')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Metilfenidato (10mg)</td>
                                <td class="py-3 px-4">20/01/2025</td>
                                <td class="py-3 px-4"><span class="bg-red-100 text-red-800 dark:bg-red-800/30 dark:text-red-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Vencida</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Metilfenidato (10mg)', '20 de janeiro de 2025', 'Tomar 1 comprimido via oral, pela manhã. Não exceder a dose prescrita. Não tomar à noite. Receita controlada.', 'Link para PDF da Receita de Metilfenidato')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="medicamentos-uso" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-pills mr-3 text-primary"></i> Medicamentos em Uso
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-4">Esta seção lista todos os medicamentos que você está tomando atualmente.</p>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                        <h3 class="font-semibold text-lg text-blue-800 dark:text-blue-300">Amlodipino 5mg</h3>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            **Posologia:** 1 comprimido, 1x ao dia (manhã)<br>
                            **Início:** 01/01/2024<br>
                            **Indicação:** Controle de Pressão Arterial
                        </p>
                        <button class="mt-2 text-primary hover:underline text-sm"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                        <h3 class="font-semibold text-lg text-blue-800 dark:text-blue-300">Sinvastatina 20mg</h3>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            **Posologia:** 1 comprimido, 1x ao dia (noite)<br>
                            **Início:** 15/03/2023<br>
                            **Indicação:** Controle de Colesterol
                        </p>
                        <button class="mt-2 text-primary hover:underline text-sm"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                        <h3 class="font-semibold text-lg text-blue-800 dark:text-blue-300">Vitamina D 2000 UI</h3>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            **Posologia:** 1 cápsula, 1x ao dia (manhã)<br>
                            **Início:** 01/06/2025<br>
                            **Indicação:** Suplementação
                        </p>
                        <button class="mt-2 text-primary hover:underline text-sm"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                    </div>
                </div>
            </section>

            <section id="consultas-anteriores" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-history mr-3 text-primary"></i> Consultas Anteriores
                </h2>
                <ul class="divide-y divide-gray-200 dark:divide-gray-700">
                    <li class="py-4 flex items-start">
                        <div class="flex-shrink-0 text-gray-500 dark:text-gray-400 mr-4">
                            <i class="fas fa-calendar-alt text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-lg font-semibold mb-1">18 de agosto de 2024 - Urologista | Dr. Tanaba</p>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">
                                <span class="font-medium">Motivo:</span> Exame de rotina para check-up anual.<br>
                                <span class="font-medium">Diagnóstico:</span> Sem alterações significativas.
                            </p>
                            <button class="mt-2 text-primary hover:underline text-sm" onclick="openDetailsModal('consultation', 'Consulta com Dr. Tanaba (Urologista)', '18 de agosto de 2024', 'Motivo: Exame de rotina para check-up anual.\\nDiagnóstico: Sem alterações significativas.\\nRecomendações: Manter hábitos saudáveis.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Ver Prontuário</button>
                        </div>
                    </li>
                    <li class="py-4 flex items-start">
                        <div class="flex-shrink-0 text-gray-500 dark:text-gray-400 mr-4">
                            <i class="fas fa-calendar-alt text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-lg font-semibold mb-1">30 de janeiro de 2024 - Nefrologista | Dr. Andre</p>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">
                                <span class="font-medium">Motivo:</span> Acompanhamento de quadro de hipertensão.<br>
                                <span class="font-medium">Diagnóstico:</span> Pressão arterial controlada com medicação.
                            </p>
                            <button class="mt-2 text-primary hover:underline text-sm" onclick="openDetailsModal('consultation', 'Consulta com Dr. Andre (Nefrologista)', '30 de janeiro de 2024', 'Motivo: Acompanhamento de quadro de hipertensão.\\nDiagnóstico: Pressão arterial controlada com medicação.\\nRecomendações: Continuar com medicação e controle da dieta.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Ver Prontuário</button>
                        </div>
                    </li>
                    <li class="py-4 flex items-start">
                        <div class="flex-shrink-0 text-gray-500 dark:text-gray-400 mr-4">
                            <i class="fas fa-calendar-alt text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-lg font-semibold mb-1">15 de dezembro de 2023 - Clínico Geral | Dra. Juliana</p>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">
                                <span class="font-medium">Motivo:</span> Sintomas de gripe e tosse persistente.<br>
                                <span class="font-medium">Diagnóstico:</span> Gripe viral. Prescrito repouso e analgésicos.
                            </p>
                            <button class="mt-2 text-primary hover:underline text-sm" onclick="openDetailsModal('consultation', 'Consulta com Dra. Juliana (Clínico Geral)', '15 de dezembro de 2023', 'Motivo: Sintomas de gripe e tosse persistente.\\nDiagnóstico: Gripe viral. Prescrito repouso e analgésicos.\\nRecomendações: Hidratação e acompanhamento dos sintomas.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Ver Prontuário</button>
                        </div>
                    </li>
                </ul>
            </section>

            <section id="notificacoes" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-bell mr-3 text-primary"></i> Minhas Notificações
                </h2>
                <div id="notifications-list" class="space-y-4">
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border-l-4 border-blue-500 flex items-start">
                        <i class="fas fa-info-circle text-blue-600 dark:text-blue-400 mr-3 text-xl mt-1"></i>
                        <div>
                            <h3 class="font-semibold text-lg">Lembrete de Consulta</h3>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">Você tem uma consulta agendada com Dra. Roberta Silva em 26/07/2025 às 10:30.</p>
                            <button class="text-primary hover:underline text-xs mt-1" onclick="markNotificationAsRead(this.closest('.flex'))">Marcar como lida</button>
                        </div>
                    </div>
                    <div class="bg-green-50 dark:bg-green-800/20 p-4 rounded-lg border-l-4 border-green-500 flex items-start">
                        <i class="fas fa-check-circle text-green-600 dark:text-green-400 mr-3 text-xl mt-1"></i>
                        <div>
                            <h3 class="font-semibold text-lg">Resultado de Exame Disponível</h3>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">Seu resultado do Hemograma Completo de 20/05/2025 está disponível para visualização.</p>
                            <button class="text-primary hover:underline text-xs mt-1" onclick="markNotificationAsRead(this.closest('.flex'))">Marcar como lida</button>
                        </div>
                    </div>
                    <div class="bg-orange-50 dark:bg-orange-800/20 p-4 rounded-lg border-l-4 border-orange-500 flex items-start">
                        <i class="fas fa-exclamation-triangle text-orange-600 dark:text-orange-400 mr-3 text-xl mt-1"></i>
                        <div>
                            <h3 class="font-semibold text-lg">Receita Médica Vencida</h3>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">Sua receita de Metilfenidato venceu. Por favor, solicite a renovação.</p>
                            <button class="text-primary hover:underline text-xs mt-1" onclick="markNotificationAsRead(this.closest('.flex'))">Marcar como lida</button>
                        </div>
                    </div>
                </div>
                <button class="btn-primary-outline mt-6" onclick="clearAllNotifications()">Limpar todas as notificações</button>
            </section>

            <section id="feedback" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-comment-dots mr-3 text-primary"></i> Enviar Feedback
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-4">Sua opinião é muito importante para nós! Ajude-nos a melhorar nossos serviços.</p>
                <form onsubmit="submitFeedback(event)">
                    <div class="mb-4">
                        <label for="feedbackSubject" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Assunto</label>
                        <input type="text" id="feedbackSubject" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" placeholder="Ex: Sugestão para agendamento">
                    </div>
                    <div class="mb-4">
                        <label for="feedbackMessage" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Sua Mensagem</label>
                        <textarea id="feedbackMessage" rows="5" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" placeholder="Descreva sua sugestão, elogio ou problema..."></textarea>
                    </div>
                    <button type="submit" class="btn-primary"><i class="fas fa-paper-plane mr-2"></i> Enviar Feedback</button>
                </form>
            </section>

            <section id="ai-assistant" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-robot mr-3 text-primary"></i> Tia do postinho (IA)
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-4">Pergunte à Tia do Postinho sobre exames, medicamentos ou informações gerais de saúde. Lembre-se que esta é uma ferramenta auxiliar e não substitui a consulta médica.</p>

                <div class="chat-container flex flex-col h-[400px]"> <div class="chat-messages flex-1 overflow-y-auto p-3 bg-gray-50 dark:bg-gray-700 rounded-lg mb-4 space-y-2" id="chat-messages">
                        <div class="message-bubble message-ai self-start bg-blue-500 text-white rounded-lg p-2 max-w-[80%]">Olá! Como posso ajudar você hoje com suas dúvidas?</div>
                    </div>
                    <div class="chat-input-area flex items-center">
                        <input type="text" id="ai-chat-input" class="chat-input flex-grow p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-lightCard dark:bg-darkBg text-lightText dark:text-darkText" placeholder="Digite sua pergunta aqui...">
                        <button id="ai-chat-send-button" class="chat-send-button ml-2 bg-primary text-white p-2 rounded-md hover:bg-blue-700 transition-colors duration-300">
                            <i class="fas fa-paper-plane"></i> Enviar
                        </button>
                        <span id="ai-loading-spinner" class="loading-spinner ml-2 hidden"></span>
                    </div>
                </div>
            </section>

            <section id="configuracoes" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-cogs mr-3 text-primary"></i> Configurações da Conta
                </h2>
                <div class="space-y-6">
                    <div>
                        <h3 class="text-xl font-semibold mb-3">Informações Pessoais</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="nomeCompleto" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Nome Completo</label>
                                <input type="text" id="nomeCompleto" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-gray-50 dark:bg-gray-700 text-lightText dark:text-darkText p-2" value="Teste Pessoa" disabled>
                            </div>
                            <div>
                                <label for="cpfPaciente" class="block text-sm font-medium text-gray-700 dark:text-gray-400">CPF</label>
                                <input type="text" id="cpfPaciente" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-gray-50 dark:bg-gray-700 text-lightText dark:text-darkText p-2" value="123.456.789-00" disabled>
                            </div>
                            <div>
                                <label for="emailPaciente" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Email</label>
                                <input type="email" id="emailPaciente" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="teste.pessoa@email.com">
                            </div>
                            <div>
                                <label for="telefonePaciente" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Telefone</label>
                                <input type="text" id="telefonePaciente" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="(11) 98765-4321">
                            </div>
                        </div>
                        <button class="mt-6 btn-primary"><i class="fas fa-save mr-2"></i> Salvar Alterações</button>
                    </div>

                    <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
                        <h3 class="text-xl font-semibold mb-3">Preferências</h3>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-700 dark:text-gray-300">Receber notificações por e-mail</span>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" value="" class="sr-only peer" checked>
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                            </label>
                        </div>
                    </div>
                </div>
            </section>

        </main>
    </div>

    <div id="detailsModal" class="modal-overlay">
        <div class="modal-content">
            <button class="modal-close-button" onclick="closeDetailsModal()">&times;</button>
            <h3 id="modalTitle" class="text-2xl font-bold mb-4 text-gray-800 dark:text-darkText"></h3>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
                <span class="font-semibold">Data:</span> <span id="modalDate"></span>
            </p>
            <div class="mb-4">
                <p class="text-gray-700 dark:text-gray-300 font-semibold mb-1">Informações Detalhadas:</p>
                <p id="modalDescription" class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap"></p>
            </div>
            <a id="modalDownloadLink" href="#" target="_blank" class="btn-primary mt-4 hidden"><i class="fas fa-download mr-2"></i> Baixar PDF Completo</a>
            <p id="modalNoPdfMessage" class="text-sm text-gray-500 mt-2 hidden"><i class="fas fa-info-circle mr-1"></i> Não há um PDF disponível para este item.</p>
        </div>
    </div>

    <script src="funpainelpac.js"></script>      
    </script>
</body>
</html>