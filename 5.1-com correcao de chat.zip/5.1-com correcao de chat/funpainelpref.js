 // Função para alternar a exibição das seções de conteúdo
        function showSection(sectionId, clickedElement) {
            // Remove 'active' de todas as seções e esconde-as
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            // Remove 'active' de todos os itens da sidebar
            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('active');
            });

            // Adiciona 'active' à seção clicada e a mostra
            document.getElementById(sectionId).classList.add('active');
            // Adiciona 'active' ao item da sidebar clicado
            clickedElement.classList.add('active');

            // Recarregar estoque da farmácia ao entrar na seção
            if (sectionId === 'estoque') {
                loadEstoqueFarmacia();
            }
        }

        // Toggle modo claro/escuro
        function toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
        }

        // --- Funções de Gestão de Médicos ---
        let currentMedicoRow = null; // Para saber qual linha editar

        function openMedicoModal(mode, nome = '', especialidade = '', crm = '') {
            const modal = document.getElementById('medicoModal');
            const title = document.getElementById('medicoModalTitle');
            const submitBtn = document.getElementById('medicoFormSubmitBtn');
            const form = document.getElementById('medicoForm');

            document.getElementById('medicoNome').value = nome;
            document.getElementById('medicoEspecialidade').value = especialidade;
            document.getElementById('medicoCRM').value = crm;

            if (mode === 'add') {
                title.textContent = 'Adicionar Novo Médico';
                submitBtn.textContent = 'Adicionar Médico';
                submitBtn.classList.remove('bg-blue-600');
                submitBtn.classList.add('bg-primary');
                currentMedicoRow = null;
            } else if (mode === 'edit') {
                title.textContent = 'Editar Médico';
                submitBtn.textContent = 'Salvar Alterações';
                submitBtn.classList.remove('bg-primary');
                submitBtn.classList.add('bg-blue-600'); // Cor ligeiramente diferente para edição
                // Armazena a linha que está sendo editada
                currentMedicoRow = event.target.closest('tr');
            }
            modal.classList.add('show');
        }

        function closeMedicoModal() {
            document.getElementById('medicoModal').classList.remove('show');
            document.getElementById('medicoForm').reset();
            currentMedicoRow = null;
        }

        function handleMedicoSubmit(event) {
            event.preventDefault();
            const nome = document.getElementById('medicoNome').value.trim();
            const especialidade = document.getElementById('medicoEspecialidade').value.trim();
            const crm = document.getElementById('medicoCRM').value.trim();
            const listaMedicos = document.getElementById('lista-medicos');

            if (!nome || !especialidade || !crm) {
                alert('Por favor, preencha todos os campos do médico.');
                return;
            }

            if (currentMedicoRow) {
                // Modo de Edição
                currentMedicoRow.children[0].textContent = nome;
                currentMedicoRow.children[1].textContent = especialidade;
                currentMedicoRow.children[2].textContent = crm;
                alert(`Médico ${nome} atualizado com sucesso!`);
            } else {
                // Modo de Adição
                const newRow = `
                    <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                        <td class="py-3 px-4">${nome}</td>
                        <td class="py-3 px-4">${especialidade}</td>
                        <td class="py-3 px-4">${crm}</td>
                        <td class="py-3 px-4"><span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Ativo</span></td>
                        <td class="py-3 px-4">
                            <button class="text-blue-600 hover:underline text-sm mr-2" onclick="openMedicoModal('edit', '${nome}', '${especialidade}', '${crm}', this)"><i class="fas fa-edit"></i> Editar</button>
                            <button class="text-red-600 hover:underline text-sm" onclick="removerMedico(this)"><i class="fas fa-trash"></i> Remover</button>
                        </td>
                    </tr>
                `;
                listaMedicos.insertAdjacentHTML('beforeend', newRow);
                alert(`Médico ${nome} adicionado com sucesso!`);
            }
            closeMedicoModal();
        }

        function removerMedico(buttonElement) {
            if (confirm('Tem certeza que deseja remover este médico?')) {
                const row = buttonElement.closest('tr');
                row.remove();
                alert('Médico removido com sucesso!');
            }
        }

        // --- Funções de Controle de Estoque ---
        const estoqueData = {
            central: [
                { nome: 'Paracetamol 500mg', quantidade: 120, status: 'OK' },
                { nome: 'Amoxicilina 500mg', quantidade: 45, status: 'OK' },
                { nome: 'Sufato de Eritropoietina 500mg', quantidade: 20, status: 'Baixo' },
                { nome: 'Dipirona 300mg', quantidade: 10, status: 'Baixo' }
            ],
            bairro1: [
                { nome: 'Paracetamol 500mg', quantidade: 80, status: 'OK' },
                { nome: 'Insulina', quantidade: 5, status: 'Crítico' }
            ],
            bairro2: [
                { nome: 'Anti-histamínico', quantidade: 60, status: 'OK' },
                { nome: 'Vitaminas', quantidade: 90, status: 'OK' }
            ],
            rural: [
                { nome: 'Soro Fisiológico', quantidade: 30, status: 'OK' },
                { nome: 'Máscaras N95', quantidade: 50, status: 'OK' }
            ]
        };

        function loadEstoqueFarmacia() {
            const select = document.getElementById('farmacia-select');
            const selectedFarmacia = select.value;
            const tableBody = document.getElementById('estoque-table-body');
            tableBody.innerHTML = ''; // Limpa a tabela

            const currentEstoque = estoqueData[selectedFarmacia];

            if (currentEstoque) {
                currentEstoque.forEach(item => {
                    const statusClass = item.status === 'OK' ? 'bg-green-100 text-green-800' :
                                       item.status === 'Baixo' ? 'bg-yellow-100 text-yellow-800' :
                                       'bg-red-100 text-red-800';
                    const newRow = `
                        <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                            <td class="py-3 px-4">${item.nome}</td>
                            <td class="py-3 px-4">${item.quantidade}</td>
                            <td class="py-3 px-4"><span class="${statusClass} px-2 py-1 rounded-full text-xs">${item.status}</span></td>
                            <td class="py-3 px-4">
                                <button class="text-danger hover:underline text-sm" onclick="removerMedicamento(this, '${selectedFarmacia}', '${item.nome}')">
                                    <i class="fas fa-trash"></i> Remover
                                </button>
                            </td>
                        </tr>
                    `;
                    tableBody.insertAdjacentHTML('beforeend', newRow);
                });
            }
        }

        function adicionarOuAtualizarMedicamento() {
            const nome = document.getElementById('medicamento-nome').value.trim();
            let quantidade = parseInt(document.getElementById('medicamento-quantidade').value.trim());
            const select = document.getElementById('farmacia-select');
            const selectedFarmacia = select.value;

            if (!nome || isNaN(quantidade) || quantidade < 0) {
                alert('Preencha corretamente o nome e uma quantidade válida (não negativa).');
                return;
            }

            const currentEstoque = estoqueData[selectedFarmacia];
            const existingItemIndex = currentEstoque.findIndex(item => item.nome.toLowerCase() === nome.toLowerCase());

            if (existingItemIndex > -1) {
                // Atualizar
                currentEstoque[existingItemIndex].quantidade = quantidade;
                currentEstoque[existingItemIndex].status = getMedicamentoStatus(quantidade);
                alert(`Quantidade de ${nome} atualizada para ${quantidade} na Farmácia ${selectedFarmacia}.`);
            } else {
                // Adicionar
                const status = getMedicamentoStatus(quantidade);
                currentEstoque.push({ nome, quantidade, status });
                alert(`Medicamento ${nome} adicionado à Farmácia ${selectedFarmacia}.`);
            }

            loadEstoqueFarmacia(); // Recarrega a tabela
            document.getElementById('medicamento-nome').value = '';
            document.getElementById('medicamento-quantidade').value = '';
        }

        function removerMedicamento(buttonElement, farmaciaKey, medicamentoNome) {
            if (confirm(`Deseja realmente remover "${medicamentoNome}" desta farmácia?`)) {
                const currentEstoque = estoqueData[farmaciaKey];
                const itemIndex = currentEstoque.findIndex(item => item.nome === medicamentoNome);
                if (itemIndex > -1) {
                    currentEstoque.splice(itemIndex, 1);
                    alert(`Medicamento "${medicamentoNome}" removido.`);
                    loadEstoqueFarmacia(); // Recarrega a tabela
                }
            }
        }

        function getMedicamentoStatus(quantidade) {
            if (quantidade === 0) return 'Esgotado';
            if (quantidade < 30) return 'Baixo';
            return 'OK';
        }

        // --- Funções de Comunicação ---
        function gerarEmailFuncional() {
            const nome = document.getElementById('nomeParaEmail').value.trim();
            const resultadoEmailDiv = document.getElementById('resultadoEmail');
            const copyButton = document.getElementById('copyEmailBtn');

            if (nome) {
                const email = nome.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, '.') + '@saude.prefeitura.br';
                resultadoEmailDiv.innerText = email;
                copyButton.style.display = 'block';
            } else {
                resultadoEmailDiv.innerText = 'Digite o nome para gerar o email.';
                copyButton.style.display = 'none';
            }
        }

        function copyEmail() {
            const emailText = document.getElementById('resultadoEmail').innerText;
            if (emailText && !emailText.includes('Digite o nome')) {
                navigator.clipboard.writeText(emailText).then(() => {
                    alert('Email copiado para a área de transferência!');
                }).catch(err => {
                    console.error('Erro ao copiar texto: ', err);
                });
            }
        }

        function enviarComunicado() {
            const assunto = document.getElementById('comunicadoAssunto').value.trim();
            const mensagem = document.getElementById('comunicadoMensagem').value.trim();

            if (!assunto || !mensagem) {
                alert('Por favor, preencha o assunto e a mensagem do comunicado.');
                return;
            }

            // Simulação de envio do comunicado
            console.log('Comunicado Enviado:', { assunto, mensagem });
            alert('Comunicado enviado com sucesso para todos os usuários/equipe!');

            // Limpa os campos
            document.getElementById('comunicadoAssunto').value = '';
            document.getElementById('comunicadoMensagem').value = '';
        }

        // Fechar modal ao clicar fora ou pressionar ESC
        document.getElementById('medicoModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeMedicoModal();
            }
        });
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && document.getElementById('medicoModal').classList.contains('show')) {
                closeMedicoModal();
            }
        });


        // Inicializa a exibição do dashboard ao carregar a página
        document.addEventListener('DOMContentLoaded', () => {
            showSection('dashboard', document.getElementById('nav-dashboard'));
        });