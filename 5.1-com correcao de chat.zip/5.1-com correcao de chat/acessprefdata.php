<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel da Prefeitura - Saúde Municipal</title>
    <script src="https://cdn.tailwindcss.com"></script>
     <link rel="stylesheet" href="stylemenupref.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1d4ed8', // Azul forte para ações principais
                        secondary: '#4f46e5', // Roxo escuro para detalhes e fundo da navbar
                        accent: '#22c55e', // Verde para sucesso
                        warning: '#f59e0b', // Laranja para avisos
                        danger: '#ef4444', // Vermelho para perigo
                        darkBg: '#1f2937', // Fundo escuro para o modo dark
                        darkCard: '#374151', // Cor de card no modo dark
                        darkText: '#e5e7eb', // Texto no modo dark
                        lightBg: '#f3f4f6', // Fundo claro
                        lightCard: '#ffffff', // Cor de card no modo claro
                        lightText: '#1f2937' // Texto no modo claro
                    },
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'], // Usar Poppins como principal
                    },
                },
            },
            darkMode: 'class', // Habilita o modo escuro com a classe 'dark' no html
        };
    </script>   
       <script src="https://kit.fontawesome.com/a2d9d5eada.js" crossorigin="anonymous"></script>
</head>

<body class="bg-lightBg dark:bg-darkBg text-lightText dark:text-darkText min-h-screen">

    <div class="flex flex-col md:flex-row min-h-screen">
        <aside class="w-full md:w-64 bg-lightCard dark:bg-darkCard shadow-lg flex flex-col p-4 md:p-6 sticky top-0 h-auto md:h-screen z-10">
            <div class="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
                <i class="fas fa-city text-3xl text-primary"></i>
                <span class="text-xl font-bold text-gray-800 dark:text-darkText">Prefeitura</span>
            </div>

            <nav class="flex flex-col flex-grow space-y-2">
                <a href="#" id="nav-dashboard" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 active" onclick="showSection('dashboard', this)">
                    <i class="fas fa-chart-line text-lg"></i> Dashboard
                </a>
                <a href="#" id="nav-gestao-medicos" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('gestao-medicos', this)">
                    <i class="fas fa-user-md text-lg"></i> Gestão de Médicos
                </a>
                <a href="#" id="nav-gestao-pacientes" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('gestao-pacientes', this)">
                    <i class="fas fa-user text-lg"></i> Gestão de Pacientes
                </a>
                <a href="#" id="nav-relatorios" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('relatorios', this)">
                    <i class="fas fa-chart-pie text-lg"></i> Relatórios
                </a>
                <a href="#" id="nav-estoque" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('estoque', this)">
                    <i class="fas fa-boxes text-lg"></i> Controle de Estoque
                </a>
                <a href="#" id="nav-comunicacao" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('comunicacao', this)">
                    <i class="fas fa-envelope text-lg"></i> Comunicação
                </a>
                <a href="#" id="nav-configuracoes" class="sidebar-item flex items-center gap-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('configuracoes', this)">
                    <i class="fas fa-cogs text-lg"></i> Configurações
                </a>
            </nav>

            <div class="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
                <button onclick="toggleDarkMode()" class="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 w-full text-left text-sm font-medium">
                    <i class="fas fa-adjust text-lg"></i> Modo Claro/Escuro
                </button>
                <a href="#" class="flex items-center gap-3 p-3 rounded-lg hover:bg-red-100 dark:hover:bg-red-800/50 text-danger w-full text-left text-sm font-medium mt-2">
                    <i class="fas fa-sign-out-alt text-lg"></i> Sair
                </a>
            </div>
        </aside>

        <main class="flex-1 p-6 md:p-8 overflow-y-auto">
            <header class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
                <h1 class="text-3xl font-extrabold text-gray-800 dark:text-darkText">
                    Secretaria Municipal de Saúde
                </h1>
                <div class="mt-4 sm:mt-0 flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <i class="fas fa-calendar-day mr-2"></i> Hoje: Sábado, 14 de Junho de 2025
                </div>
            </header>

            <section id="dashboard" class="content-section active bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-chart-line mr-3 text-primary"></i> Visão Geral do Dia
                </h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-5 rounded-lg shadow-sm border-l-4 border-blue-500">
                        <p class="text-sm text-gray-600 dark:text-gray-400">Consultas Agendadas</p>
                        <p class="text-3xl font-bold text-blue-800 dark:text-blue-300 mt-1">150</p>
                    </div>
                    <div class="bg-green-50 dark:bg-green-800/20 p-5 rounded-lg shadow-sm border-l-4 border-green-500">
                        <p class="text-sm text-gray-600 dark:text-gray-400">Pacientes Atendidos</p>
                        <p class="text-3xl font-bold text-green-800 dark:text-green-300 mt-1">95</p>
                    </div>
                    <div class="bg-purple-50 dark:bg-purple-800/20 p-5 rounded-lg shadow-sm border-l-4 border-purple-500">
                        <p class="text-sm text-gray-600 dark:text-gray-400">Receitas Emitidas</p>
                        <p class="text-3xl font-bold text-purple-800 dark:text-purple-300 mt-1">70</p>
                    </div>
                    <div class="bg-yellow-50 dark:bg-yellow-800/20 p-5 rounded-lg shadow-sm border-l-4 border-yellow-500">
                        <p class="text-sm text-gray-600 dark:text-gray-400">Medicamentos em Falta</p>
                        <p class="text-3xl font-bold text-yellow-800 dark:text-yellow-300 mt-1">5</p>
                    </div>
                </div>

                <div class="mt-8">
                    <h3 class="text-xl font-bold mb-3 flex items-center"><i class="fas fa-calendar-alt mr-2 text-primary"></i> Próximos Eventos</h3>
                    <ul class="space-y-3">
                        <li class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-sm flex items-start">
                            <i class="fas fa-info-circle text-blue-500 mr-3 text-lg mt-1"></i>
                            <div>
                                <p class="font-semibold">Reunião Mensal com Chefes de Unidade</p>
                                <p class="text-sm text-gray-700 dark:text-gray-300">20/06/2025 - 09:00h | Sala de Reuniões 1</p>
                            </div>
                        </li>
                        <li class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-sm flex items-start">
                            <i class="fas fa-syringe text-green-500 mr-3 text-lg mt-1"></i>
                            <div>
                                <p class="font-semibold">Campanha de Vacinação Contra Gripe</p>
                                <p class="text-sm text-gray-700 dark:text-gray-300">25/06/2025 - 08:00h às 17:00h | Praça Central</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>

            <section id="gestao-medicos" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-user-md mr-3 text-primary"></i> Gestão de Médicos
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Médicos Cadastrados</h3>
                    <button class="btn-primary" onclick="openMedicoModal('add')">
                        <i class="fas fa-plus"></i> Adicionar Novo Médico
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Nome</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Especialidade</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">CRM</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="lista-medicos">
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Dra. Ana Costa</td>
                                <td class="py-3 px-4">Clínico Geral</td>
                                <td class="py-3 px-4">CRM/SP 123456</td>
                                <td class="py-3 px-4"><span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Ativo</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-blue-600 hover:underline text-sm mr-2" onclick="openMedicoModal('edit', 'Dra. Ana Costa', 'Clínico Geral', 'CRM/SP 123456')"><i class="fas fa-edit"></i> Editar</button>
                                    <button class="text-red-600 hover:underline text-sm" onclick="removerMedico(this)"><i class="fas fa-trash"></i> Remover</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Dr. Bruno Silva</td>
                                <td class="py-3 px-4">Pediatra</td>
                                <td class="py-3 px-4">CRM/SP 789012</td>
                                <td class="py-3 px-4"><span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Ativo</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-blue-600 hover:underline text-sm mr-2" onclick="openMedicoModal('edit', 'Dr. Bruno Silva', 'Pediatra', 'CRM/SP 789012')"><i class="fas fa-edit"></i> Editar</button>
                                    <button class="text-red-600 hover:underline text-sm" onclick="removerMedico(this)"><i class="fas fa-trash"></i> Remover</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Dra. Carla Souza</td>
                                <td class="py-3 px-4">Ginecologista</td>
                                <td class="py-3 px-4">CRM/SP 345678</td>
                                <td class="py-3 px-4"><span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Férias</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-blue-600 hover:underline text-sm mr-2" onclick="openMedicoModal('edit', 'Dra. Carla Souza', 'Ginecologista', 'CRM/SP 345678')"><i class="fas fa-edit"></i> Editar</button>
                                    <button class="text-red-600 hover:underline text-sm" onclick="removerMedico(this)"><i class="fas fa-trash"></i> Remover</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="gestao-pacientes" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-user mr-3 text-primary"></i> Gestão de Pacientes
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Pacientes Cadastrados</h3>
                    <button class="btn-primary" onclick="alert('Funcionalidade de cadastro de paciente será implementada.')">
                        <i class="fas fa-user-plus"></i> Cadastrar Novo Paciente
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Nome</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">CPF</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Última Consulta</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">João Silva</td>
                                <td class="py-3 px-4">111.222.333-44</td>
                                <td class="py-3 px-4">01/05/2025</td>
                                <td class="py-3 px-4">
                                    <button class="text-blue-600 hover:underline text-sm mr-2" onclick="alert('Ver perfil do João Silva')"><i class="fas fa-eye"></i> Perfil</button>
                                    <button class="text-red-600 hover:underline text-sm" onclick="alert('Excluir João Silva')"><i class="fas fa-trash"></i> Excluir</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Maria Oliveira</td>
                                <td class="py-3 px-4">555.666.777-88</td>
                                <td class="py-3 px-4">10/06/2025</td>
                                <td class="py-3 px-4">
                                    <button class="text-blue-600 hover:underline text-sm mr-2" onclick="alert('Ver perfil da Maria Oliveira')"><i class="fas fa-eye"></i> Perfil</button>
                                    <button class="text-red-600 hover:underline text-sm" onclick="alert('Excluir Maria Oliveira')"><i class="fas fa-trash"></i> Excluir</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="relatorios" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-chart-pie mr-3 text-primary"></i> Relatórios e Estatísticas
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-4">Acesse relatórios detalhados sobre o desempenho da saúde municipal.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-primary">
                        <h3 class="text-xl font-semibold mb-3 flex items-center"><i class="fas fa-calendar-check mr-2 text-primary"></i> Agendamentos</h3>
                        <p class="text-gray-700 dark:text-gray-300 mb-3">Total de agendamentos por período, por especialidade e por médico.</p>
                        <a href="#" class="btn-outline" onclick="alert('Gerar relatório de agendamentos')"><i class="fas fa-file-excel"></i> Gerar Relatório</a>
                    </div>
                    <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-accent">
                        <h3 class="text-xl font-semibold mb-3 flex items-center"><i class="fas fa-notes-medical mr-2 text-accent"></i> Receitas Emitidas</h3>
                        <p class="text-gray-700 dark:text-gray-300 mb-3">Volume de receitas emitidas, medicamentos mais prescritos e médicos prescritores.</p>
                        <a href="#" class="btn-outline" onclick="alert('Gerar relatório de receitas')"><i class="fas fa-file-excel"></i> Gerar Relatório</a>
                    </div>
                    <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-secondary">
                        <h3 class="text-xl font-semibold mb-3 flex items-center"><i class="fas fa-stethoscope mr-2 text-secondary"></i> Consultas Realizadas</h3>
                        <p class="text-gray-700 dark:text-gray-300 mb-3">Quantidade de consultas por tipo, por unidade de saúde e por faixa etária.</p>
                        <a href="#" class="btn-outline" onclick="alert('Gerar relatório de consultas')"><i class="fas fa-file-excel"></i> Gerar Relatório</a>
                    </div>
                    <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-warning">
                        <h3 class="text-xl font-semibold mb-3 flex items-center"><i class="fas fa-chart-bar mr-2 text-warning"></i> Visitas Domiciliares</h3>
                        <p class="text-gray-700 dark:text-gray-300 mb-3">Número de visitas realizadas por agentes de saúde e principais ocorrências.</p>
                        <a href="#" class="btn-outline" onclick="alert('Gerar relatório de visitas domiciliares')"><i class="fas fa-file-excel"></i> Gerar Relatório</a>
                    </div>
                </div>

                <h3 class="text-xl font-bold mb-3 mt-8 flex items-center"><i class="fas fa-chart-line mr-2 text-primary"></i> Gráficos (Exemplo)</h3>
                <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-primary">
                    <p class="text-gray-700 dark:text-gray-300">Aqui seriam exibidos gráficos interativos (e.g., com Chart.js ou D3.js) sobre os dados de saúde.</p>
                    <div class="h-48 bg-gray-200 dark:bg-gray-600 rounded-md flex items-center justify-center mt-4 text-gray-500">
                        <p>Gráfico de Exemplo</p>
                    </div>
                </div>
            </section>

            <section id="estoque" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-boxes mr-3 text-primary"></i> Controle de Estoque - Farmácias Municipais
                </h2>

                <div class="mb-4">
                    <label for="farmacia-select" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Selecione a Farmácia:</label>
                    <select id="farmacia-select" class="mt-1 block w-full border border-gray-300 dark:border-gray-600 rounded-md shadow-sm p-2 bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText" onchange="loadEstoqueFarmacia()">
                        <option value="central">Farmácia Central</option>
                        <option value="bairro1">Farmácia Bairro 1</option>
                        <option value="bairro2">Farmácia Bairro 2</option>
                        <option value="rural">Farmácia Rural</option>
                    </select>
                </div>

                <div class="overflow-x-auto mb-6">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold">Medicamento</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold">Quantidade</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="estoque-table-body">
                            </tbody>
                    </table>
                </div>

                <div class="mt-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg shadow-inner">
                    <h3 class="text-lg font-semibold mb-3">Adicionar/Atualizar Medicamento</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input id="medicamento-nome" type="text" placeholder="Nome do Medicamento" class="border p-2 rounded-md w-full bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText border-gray-300 dark:border-gray-600">
                        <input id="medicamento-quantidade" type="number" placeholder="Quantidade" class="border p-2 rounded-md w-full bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText border-gray-300 dark:border-gray-600">
                        <button onclick="adicionarOuAtualizarMedicamento()" class="btn-primary">
                            <i class="fas fa-plus"></i> Adicionar/Atualizar
                        </button>
                    </div>
                </div>
            </section>

            <section id="comunicacao" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-envelope mr-3 text-primary"></i> Ferramentas de Comunicação
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-6">Gerencie a comunicação com a equipe e parceiros.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-purple-500">
                        <h3 class="text-xl font-semibold mb-3 flex items-center"><i class="fas fa-at mr-2 text-purple-500"></i> Gerador de Email Funcional</h3>
                        <div class="mb-4">
                            <label for="nomeParaEmail" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Nome Completo:</label>
                            <input id="nomeParaEmail" type="text" placeholder="Ex: Ana Paula Silva" class="w-full border rounded-md px-3 py-2 mt-1 bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText border-gray-300 dark:border-gray-600">
                        </div>
                        <button onclick="gerarEmailFuncional()" class="btn-primary w-full justify-center">
                            <i class="fas fa-sync-alt"></i> Gerar Email
                        </button>
                        <div id="resultadoEmail" class="mt-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-mono text-sm break-all">
                            </div>
                        <button onclick="copyEmail()" class="btn-secondary w-full justify-center mt-3" id="copyEmailBtn" style="display:none;">
                            <i class="fas fa-copy"></i> Copiar Email
                        </button>
                    </div>

                    <div class="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg shadow-sm border-l-4 border-blue-500">
                        <h3 class="text-xl font-semibold mb-3 flex items-center"><i class="fas fa-bullhorn mr-2 text-blue-500"></i> Enviar Comunicado Geral</h3>
                        <div class="mb-4">
                            <label for="comunicadoAssunto" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Assunto</label>
                            <input type="text" id="comunicadoAssunto" class="w-full border rounded-md px-3 py-2 mt-1 bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText border-gray-300 dark:border-gray-600" placeholder="Ex: Nova diretriz de atendimento">
                        </div>
                        <div class="mb-4">
                            <label for="comunicadoMensagem" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Mensagem</label>
                            <textarea id="comunicadoMensagem" rows="4" class="w-full border rounded-md px-3 py-2 mt-1 bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText border-gray-300 dark:border-gray-600" placeholder="Digite a mensagem do comunicado..."></textarea>
                        </div>
                        <button onclick="enviarComunicado()" class="btn-primary w-full justify-center">
                            <i class="fas fa-paper-plane"></i> Enviar Comunicado
                        </button>
                    </div>
                </div>
            </section>

            <section id="configuracoes" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-cogs mr-3 text-primary"></i> Configurações do Sistema
                </h2>
                <div class="space-y-6">
                    <div>
                        <h3 class="text-xl font-semibold mb-3">Informações da Secretaria</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="nomeSecretaria" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Nome da Secretaria</label>
                                <input type="text" id="nomeSecretaria" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="Secretaria Municipal de Saúde">
                            </div>
                            <div>
                                <label for="enderecoSecretaria" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Endereço</label>
                                <input type="text" id="enderecoSecretaria" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="Rua da Saúde, 123 - Centro">
                            </div>
                            <div>
                                <label for="telefoneSecretaria" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Telefone</label>
                                <input type="text" id="telefoneSecretaria" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="(XX) XXXX-XXXX">
                            </div>
                        </div>
                        <button class="mt-6 btn-primary"><i class="fas fa-save mr-2"></i> Salvar Configurações</button>
                    </div>

                    <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
                        <h3 class="text-xl font-semibold mb-3">Preferências do Sistema</h3>
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-gray-700 dark:text-gray-300">Habilitar Modo de Manutenção</span>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" value="" class="sr-only peer">
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                            </label>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-700 dark:text-gray-300">Tema do Sistema</span>
                            <button onclick="toggleDarkMode()" class="btn-secondary btn-sm">
                                <i class="fas fa-moon"></i> Alternar Tema
                            </button>
                        </div>
                    </div>
                </div>
            </section>

        </main>
    </div>

    <div id="medicoModal" class="modal-overlay">
        <div class="modal-content">
            <button class="modal-close-button" onclick="closeMedicoModal()">&times;</button>
            <h3 id="medicoModalTitle" class="text-2xl font-bold mb-4 text-gray-800 dark:text-darkText"></h3>
            <form id="medicoForm" onsubmit="handleMedicoSubmit(event)">
                <div class="mb-4">
                    <label for="medicoNome" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Nome Completo</label>
                    <input type="text" id="medicoNome" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" required>
                </div>
                <div class="mb-4">
                    <label for="medicoEspecialidade" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Especialidade</label>
                    <input type="text" id="medicoEspecialidade" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" required>
                </div>
                <div class="mb-4">
                    <label for="medicoCRM" class="block text-sm font-medium text-gray-700 dark:text-gray-400">CRM</label>
                    <input type="text" id="medicoCRM" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" required>
                </div>
                <button type="submit" class="btn-primary w-full justify-center" id="medicoFormSubmitBtn"></button>
            </form>
        </div>
    </div>
</body>
</html>