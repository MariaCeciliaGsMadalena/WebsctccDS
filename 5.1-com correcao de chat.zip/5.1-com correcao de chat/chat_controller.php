<?php
// chat_controller.php
// Controlador unificado para envio e recuperação de mensagens entre exame e médico

// Configurações de conexão (ajuste conforme seu ambiente)
define('DB_HOST', 'localhost');
define('DB_NAME', 'agilixmdtechbd');
define('DB_USER', 'root');
define('DB_PASS', 'usbw');

/**
 * Retorna uma nova conexão PDO com o banco de dados.
 * @return PDO A conexão PDO.
 */
function getPdoConnection() {
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $pdo;
    } catch (PDOException $e) {
        error_log('Falha na conexão com o banco: ' . $e->getMessage());
        // Em um ambiente de produção, você pode querer lançar uma exceção ou redirecionar
        throw new Exception('Falha na conexão com o banco de dados.');
    }
}

/**
 * Envia uma mensagem de chat e a armazena no banco de dados.
 * @param PDO $pdo Conexão PDO com o banco de dados.
 * @param int $senderId ID do remetente.
 * @param string $senderType Tipo do remetente ('medico' ou 'estabelecimento_exame').
 * @param int $receiverId ID do destinatário.
 * @param string $receiverType Tipo do destinatário ('medico' ou 'estabelecimento_exame').
 * @param string $messageText O texto da mensagem.
 * @return array Um array associativo com 'success' e 'id_mensagem'.
 */
function sendChatMessage($pdo, $senderId, $senderType, $receiverId, $receiverType, $messageText) {
    $stmt = $pdo->prepare(
        "INSERT INTO chat_mensagens (id_remetente, tipo_remetente, id_destinatario, tipo_destinatario, mensagem, data_envio, lida)
         VALUES (:id_remetente, :tipo_remetente, :id_destinatario, :tipo_destinatario, :mensagem, NOW(), 0)"
    );
    $stmt->execute([
        ':id_remetente'    => $senderId,
        ':tipo_remetente'  => $senderType,
        ':id_destinatario' => $receiverId,
        ':tipo_destinatario' => $receiverType,
        ':mensagem'        => $messageText
    ]);
    return ['success' => true, 'id_mensagem' => $pdo->lastInsertId()];
}

/**
 * Recupera o histórico de mensagens entre dois usuários e marca as mensagens como lidas.
 * @param PDO $pdo Conexão PDO com o banco de dados.
 * @param int $meId ID do usuário logado.
 * @param string $meType Tipo do usuário logado.
 * @param int $themId ID do outro usuário na conversa.
 * @param string $themType Tipo do outro usuário na conversa.
 * @return array Um array associativo com 'success' e 'history' (array de mensagens).
 */
function getChatHistory($pdo, $meId, $meType, $themId, $themType) {
    // Marcar mensagens como lidas (mensagens enviadas pelo "them" para "me")
    $sqlUpdate = "UPDATE chat_mensagens SET lida = 1
                  WHERE id_remetente = :them_id AND tipo_remetente = :them_type
                  AND id_destinatario = :me_id AND tipo_destinatario = :me_type";
    $stmtUpdate = $pdo->prepare($sqlUpdate);
    $stmtUpdate->bindParam(':them_id', $themId);
    $stmtUpdate->bindParam(':them_type', $themType);
    $stmtUpdate->bindParam(':me_id', $meId);
    $stmtUpdate->bindParam(':me_type', $meType);
    $stmtUpdate->execute();

    // Obter mensagens
    $sql = "SELECT cm.id_mensagem, cm.id_remetente, cm.tipo_remetente, cm.mensagem, cm.data_envio, cm.lida,
                    CASE
                        WHEN cm.tipo_remetente = 'estabelecimento_exame' THEN ee.nome_estabelecimento
                        WHEN cm.tipo_remetente = 'medico' THEN m.nome
                    END as nome_remetente
                    FROM chat_mensagens cm
                    LEFT JOIN estabelecimentos_exame ee ON cm.tipo_remetente = 'estabelecimento_exame' AND cm.id_remetente = ee.id_estabelecimento
                    LEFT JOIN medicos m ON cm.tipo_remetente = 'medico' AND cm.id_remetente = m.id_medico
                    WHERE ((cm.id_remetente = :me_id AND cm.tipo_remetente = :me_type AND cm.id_destinatario = :them_id AND cm.tipo_destinatario = :them_type)
                    OR (cm.id_remetente = :them_id AND cm.tipo_remetente = :them_type AND cm.id_destinatario = :me_id AND cm.tipo_destinatario = :me_type))
                    ORDER BY cm.data_envio ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':me_id', $meId);
    $stmt->bindParam(':me_type', $meType);
    $stmt->bindParam(':them_id', $themId);
    $stmt->bindParam(':them_type', $themType);
    $stmt->execute();

    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['success' => true, 'history' => $mensagens];
}

// A função getUnreadMessageCounts (ou get_unread_count) também pode ser mantida aqui,
// mas seu uso no frontend ainda dependeria de AJAX para atualização em tempo real,
// a menos que você queira forçar um refresh total da página para verificar novas mensagens.
// Para este requisito de "sem AJAX", ela não será usada ativamente no frontend.
function getUnreadMessageCounts($pdo, $id_medico) {
    $sql = "SELECT cm.id_remetente, ee.nome_estabelecimento, COUNT(*) as count
            FROM chat_mensagens cm
            JOIN estabelecimentos_exame ee ON cm.id_remetente = ee.id_estabelecimento
            WHERE cm.id_destinatario = :id_medico
            AND cm.tipo_destinatario = 'medico'
            AND cm.tipo_remetente = 'estabelecimento_exame'
            AND cm.lida = 0
            GROUP BY cm.id_remetente";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id_medico', $id_medico);
    $stmt->execute();

    return ['success' => true, 'unread_counts' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

?>