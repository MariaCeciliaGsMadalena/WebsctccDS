<?php
session_start();
include_once 'conexao.php'; // Certifique-se de que conexao.php está configurado corretamente
include_once 'chat_controller.php'; // Inclui o controlador de chat como biblioteca de funções

// Verificar se o usuário está logado como estabelecimento_exame
if (!isset($_SESSION['usuario']) || $_SESSION['tipo_usuario'] !== 'estabelecimento_exame') {
    header('Location: login.php');
    exit;
}

// Dados do estabelecimento logado
$estabelecimento = $_SESSION['usuario'];
$id_estabelecimento_logado = $estabelecimento['id_estabelecimento']; // ID do estabelecimento logado

// Configurações do sistema para upload de arquivos (para o chat)
// Estas configurações são mantidas, mas o upload de arquivos para o chat será ignorado na lógica de envio.
$uploadDir = 'uploads/chat/';
$maxFileSize = 5 * 1024 * 1024; // 5MB
$allowedFileTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

// Criar diretório de uploads se não existir
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true); // Garante permissões de escrita
}

// Lógica para processar o envio de mensagem de chat via POST (SEM AJAX AGORA)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_chat_message_sync') {
    $id_destinatario = $_POST['id_medico'] ?? null;
    $mensagem = $_POST['mensagem'] ?? '';

    if (!$id_destinatario) {
        $_SESSION['chat_error'] = 'ID do médico destinatário não fornecido.';
    } elseif (empty(trim($mensagem))) {
        $_SESSION['chat_error'] = 'É necessário enviar uma mensagem. Anexos são ignorados no momento.';
    } else {
        $response = sendChatMessage(
            $conn,
            $id_estabelecimento_logado,
            'estabelecimento_exame',
            $id_destinatario,
            'medico',
            $mensagem,
            null, // Caminho do arquivo (ignorado)
            null, // Tipo do arquivo (ignorado)
            null  // Nome do arquivo (ignorado)
        );
        if (!$response['success']) {
            $_SESSION['chat_error'] = 'Erro ao enviar mensagem: ' . ($response['error'] ?? 'Erro desconhecido');
        } else {
            $_SESSION['chat_success'] = 'Mensagem enviada com sucesso!';
            // Redireciona para recarregar a página com o médico selecionado
            header('Location: acessexamdata.php?section=chat-medico&selected_medico=' . $id_destinatario);
            exit;
        }
    }
    // Se houve erro e não redirecionou, ainda redireciona para mostrar a mensagem de erro
    header('Location: acessexamdata.php?section=chat-medico&selected_medico=' . ($id_destinatario ?? ''));
    exit;
}

// Lógica para buscar todos os médicos para o dropdown
$allMedicos = [];
try {
    $sqlAllMedicos = "SELECT id_medico, nome, crm, especialidade FROM medicos ORDER BY nome ASC";
    $stmtAllMedicos = $conn->prepare($sqlAllMedicos);
    $stmtAllMedicos->execute();
    $allMedicos = $stmtAllMedicos->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar todos os médicos em acessexamdata.php: " . $e->getMessage());
}

// Lógica para carregar mensagens do chat (SEM AJAX AGORA)
$chatMessagesHtml = '';
$selectedMedicoId = $_GET['selected_medico'] ?? null;
if ($selectedMedicoId) {
    try {
        $messages = getChatHistory(
            $conn,
            $id_estabelecimento_logado,
            'estabelecimento_exame',
            $selectedMedicoId,
            'medico'
        );

        if (empty($messages['history'])) {
            $chatMessagesHtml = '
                <div class="chat-message system">
                    <strong>Sistema:</strong> Nenhuma mensagem ainda. Inicie a conversa!
                    <small>' . date('d/m/Y H:i:s') . '</small>
                </div>
            ';
        } else {
            foreach ($messages['history'] as $msg) {
                $messageClass = ($msg['tipo_remetente'] === 'estabelecimento_exame') ? 'sent' : 'received';
                $senderName = ($msg['tipo_remetente'] === 'estabelecimento_exame') ? 'Você' : htmlspecialchars($msg['nome_remetente']);
                $chatMessagesHtml .= '
                    <div class="chat-message ' . $messageClass . '">
                        <strong>' . $senderName . ':</strong>
                        <p>' . htmlspecialchars($msg['mensagem']) . '</p>
                        <small>' . date('d/m/Y H:i:s', strtotime($msg['data_envio'])) . '</small>
                    </div>
                ';
            }
        }
    } catch (Exception $e) {
        $chatMessagesHtml = '
            <div class="chat-message system">
                <strong>Sistema:</strong> Erro ao carregar mensagens: ' . htmlspecialchars($e->getMessage()) . '
                <small>' . date('d/m/Y H:i:s') . '</small>
            </div>
        ';
        error_log("Erro ao carregar histórico do chat: " . $e->getMessage());
    }
} else {
     $chatMessagesHtml = '
        <div class="chat-message system">
            <strong>Sistema:</strong> Selecione um médico para iniciar a conversa.
            <small>' . date('d/m/Y H:i:s') . '</small>
        </div>
    ';
}

// Lógica para exibir mensagens de sucesso ou erro do chat após o redirecionamento
$chatNotification = '';
if (isset($_SESSION['chat_success'])) {
    $chatNotification = '<div class="alert alert-success">' . $_SESSION['chat_success'] . '</div>';
    unset($_SESSION['chat_success']);
} elseif (isset($_SESSION['chat_error'])) {
    $chatNotification = '<div class="alert alert-danger">' . $_SESSION['chat_error'] . '</div>';
    unset($_SESSION['chat_error']);
}

// Determinar a seção ativa para o carregamento inicial da página
$activeSection = $_GET['section'] ?? 'dados-estabelecimento';

// Add a variable to hold the generated PDF link, if any (from previous request)
$generatedPdfLink = $_GET['pdf_link'] ?? null;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gerenciamento de Exames - Estabelecimento</title>
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='%23007bff' d='M8 0a1.5 1.5 0 0 0-1.5 1.5v.793l-3.354 3.353A.5.5 0 0 0 3 6v1H2.5a.5.5 0 0 0-.5.5v2a.5.5 0 0 0 .5.5H3v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1h1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-2a.5.5 0 0 0-.5-.5H13V6a.5.5 0 0 0-.146-.354L9.5 1.793V1.5A1.5 1.5 0 0 0 8 0ZM7 1.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5V2h-2V1.5ZM4 6h-.5a.5.5 0 0 0-.5.5v2a.5.5 0 0 0 .5.5H4V6Zm.5 4a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1Zm5-4h-.5a.5.5 0 0 0-.5.5v2a.5.5 0 0 0 .5.5H9V6Zm.5 4a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1Zm5-4h-.5a.5.5 0 0 0-.5.5v2a.5.5 0 0 0 .5.5H14V6Z'/%3E%3C/svg%3E">

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter%3Awght%40400%3B500%3B700%3B900&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
      body {
        font-family: "Inter", "Noto Sans", sans-serif;
        background-color: #f8f9fa;
      }
      .sidebar {
        background-color: #343a40;
        min-height: 100vh;
        color: #fff;
      }
      .sidebar .nav-link {
        color: #adb5bd;
        padding: 0.75rem 1rem;
        border-radius: 0.75rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
      }
      .sidebar .nav-link.active {
        background-color: #007bff;
        font-weight: 500;
        color: #fff;
      }
      .sidebar .nav-link:hover {
        background-color: #495057;
        color: #fff;
      }
      .search-input-group .form-control {
        background-color: #eaedf1;
        border: none;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .search-input-group .input-group-text {
        background-color: #eaedf1;
        border: none;
        color: #5c728a;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
      .filter-button {
        background-color: #eaedf1;
        color: #101418;
        border: none;
        border-radius: 0.75rem;
        padding: 0.5rem 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-weight: 500;
      }
      .table-responsive .table {
        border-radius: 0.75rem;
        border: 1px solid #d4dbe2;
        background-color: #f8f9fa;
      }
      .table thead th {
        color: #101418;
        font-weight: 500;
      }
      .table tbody td {
        color: #101418;
        font-weight: 400;
      }
      .table tbody tr:not(:first-child) {
        border-top: 1px solid #d4dbe2;
      }
      .form-control-custom {
        height: 3.5rem;
        padding: 0.9375rem;
        border-radius: 0.75rem;
        border: 1px solid #d4dbe2;
        background-color: #f8f9fa;
        color: #101418;
      }
      .form-control-custom::placeholder {
        color: #5c728a;
      }
      .form-select-custom {
        height: 3.5rem;
        padding: 0.9375rem;
        border-radius: 0.75rem;
        border: 1px solid #d4dbe2;
        background-color: #f8f9fa;
        color: #101418;
        background-image: var(--select-button-svg);
        background-repeat: no-repeat;
        background-position: right 0.75rem center;
        background-size: 16px 12px;
      }
      .send-button {
        background-color: #007bff;
        color: #fff;
        font-weight: bold;
        letter-spacing: 0.015em;
        height: 2.5rem;
        padding: 0 1rem;
        border-radius: 0.75rem;
        border: none;
      }
      /* Estilos para a lista de sugestões */
      /* Removido .patient-suggestions e .medico-suggestions pois a busca por texto foi substituída */
      .exam-input-group .form-control {
        border-top-left-radius: 0.75rem;
        border-bottom-left-radius: 0.75rem;
      }
      .exam-input-group .input-group-text {
        background-color: #e9ecef;
        border: 1px solid #d4dbe2;
        border-left: none;
        border-top-right-radius: 0.75rem;
        border-bottom-right-radius: 0.75rem;
        color: #5c728a;
      }
      .content-section {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,.075);
            margin-bottom: 20px;
        }
        .modal-custom {
            display: none;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content-custom {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
            text-align: center;
        }
        .close-button-custom {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close-button-custom:hover,
        .close-button-custom:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        /* Estilos do chat */
        .chat-box {
            height: 400px;
            overflow-y: auto;
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 15px;
            background-color: #e9ecef;
            display: flex;
            flex-direction: column;
        }
        .chat-message {
            background-color: #d1e7dd;
            padding: 8px 12px;
            border-radius: 15px;
            margin-bottom: 10px;
            max-width: 80%;
            word-wrap: break-word;
            align-self: flex-start;
        }
        .chat-message.system {
            background-color: #cce5ff;
            align-self: flex-start;
        }
        .chat-message.sent {
            background-color: #007bff;
            color: white;
            align-self: flex-end;
        }
        .chat-message small {
            display: block;
            font-size: 0.75em;
            color: #6c757d;
            margin-top: 5px;
        }
        .chat-message.sent small {
            color: rgba(255, 255, 255, 0.7);
        }
        .chat-message .file-download {
            display: none; /* Esconde o link de download para arquivos */
        }
        .chat-message.sent .file-download {
            display: none; /* Esconde o link de download para arquivos */
        }
        .loading-spinner {
            display: none;
            margin-left: 10px;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, .3);
            border-radius: 50%;
            border-top-color: #007bff;
            animation: spin 1s ease-in-out infinite;
            -webkit-animation: spin 1s ease-in-out infinite;
        }
        .badge-notification {
            position: absolute;
            top: -5px;
            right: -5px;
            font-size: 0.7rem;
        }
        @keyframes spin {
            to { -webkit-transform: rotate(360deg); }
        }
        @-webkit-keyframes spin {
            to { -webkit-transform: rotate(360deg); }
        }

        /* Custom styles for smaller sidebar text on medium and large screens for better responsiveness */
        @media (min-width: 768px) {
          .sidebar .sidebar-heading h1 {
            font-size: 1.2rem;
          }
          .sidebar .sidebar-heading p {
            font-size: 0.9rem;
          }
          .sidebar .nav-link p {
            font-size: 0.95rem;
          }
        }

        @media (min-width: 992px) {
          .sidebar .sidebar-heading h1 {
            font-size: 1.1rem;
          }
          .sidebar .sidebar-heading p {
            font-size: 0.8rem;
          }
          .sidebar .nav-link p {
            font-size: 0.85rem;
          }
        }
    </style>
</head>
<body>
    <div
      class="container-fluid d-flex flex-column min-vh-100 p-0"
      style="
        --select-button-svg: url('data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724px%27 height=%2724px%27 fill=%27rgb(92,114,138)%27 viewBox=%270 0 256 256%27%3e%3cpath d=%27M181.66,170.34a8,8,0,0,1,0,11.32l-48,48a8,8,0,0,1-11.32,0l-48-48a8,8,0,0,1,11.32-11.32L128,212.69l42.34-42.35A8,8,0,0,1,181.66,170.34Zm-96-84.68L128,43.31l42.34,42.35a8,8,0,0,0,11.32-11.32l-48-48a8,8,0,0,0-11.32,0l-48,48A8,8,0,0,0,85.66,85.66Z%27%3e%3c/path%3e%3c/svg%3e');
      "
    >
      <div class="row flex-grow-1">
        <div class="col-md-3 col-lg-2 p-4 sidebar">
          <div class="d-flex flex-column gap-4">
            <div class="d-flex flex-column sidebar-heading">
              <h1 class="fs-5 fw-medium text-white"><i class="bi bi-hospital me-2"></i>Gerenciamento de Exames</h1>
              <p class="text-white-50 fs-6">Estabelecimento: <?php echo htmlspecialchars($estabelecimento['nome_estabelecimento']); ?></p>
            </div>
            <div class="d-flex flex-column gap-2">
              <a href="?section=dados-estabelecimento" class="nav-link <?php echo ($activeSection === 'dados-estabelecimento' ? 'active' : ''); ?>" id="nav-dados-estabelecimento">
                <div class="text-white">
                  <i class="fas fa-building"></i>
                </div>
                <p class="mb-0 fs-6">Meus Dados</p>
              </a>
              <a href="?section=lancamento-exames" class="nav-link <?php echo ($activeSection === 'lancamento-exames' ? 'active' : ''); ?>" id="nav-lancamento-exames">
                <div class="text-white">
                  <i class="fas fa-flask"></i>
                </div>
                <p class="mb-0 fs-6">Lançar Resultados</p>
              </a>
              <a href="?section=chat-medico" class="nav-link <?php echo ($activeSection === 'chat-medico' ? 'active' : ''); ?>" id="nav-chat-medico">
                <div class="text-white position-relative">
                  <i class="fas fa-comments"></i>
                  <span id="unread-count-badge" class="badge bg-danger badge-notification d-none">0</span>
                </div>
                <p class="mb-0 fs-6">Chat com Médico</p>
              </a>
              <a href="login.php" class="nav-link text-danger" id="nav-sair">
                <div class="text-danger">
                  <i class="fas fa-sign-out-alt"></i>
                </div>
                <p class="mb-0 fs-6">Sair</p>
              </a>
            </div>
          </div>
        </div>

        <div class="col-md-9 col-lg-10 p-4">
          <div id="dados-estabelecimento" class="content-section" style="display: <?php echo ($activeSection === 'dados-estabelecimento' ? 'block' : 'none'); ?>;">
              <h2 class="fs-4 fw-bold text-dark mb-3">
                  <i class="fas fa-building"></i> Dados do Estabelecimento
              </h2>
              <div class="row">
                  <div class="col-md-6 mb-3">
                      <label class="form-label">Nome do Estabelecimento:</label>
                      <p class="form-control-static"><?php echo htmlspecialchars($estabelecimento['nome_estabelecimento']); ?></p>
                  </div>
                  <div class="col-md-6 mb-3">
                      <label class="form-label">Endereço:</label>
                      <p class="form-control-static"><?php echo htmlspecialchars($estabelecimento['endereco']); ?></p>
                  </div>
                  <div class="col-md-6 mb-3">
                      <label class="form-label">Telefone:</label>
                      <p class="form-control-static"><?php echo htmlspecialchars($estabelecimento['telefone']); ?></p>
                  </div>
                  <div class="col-md-6 mb-3">
                      <label class="form-label">Email:</label>
                      <p class="form-control-static"><?php echo htmlspecialchars($estabelecimento['email']); ?></p>
                  </div>
                  </div>
          </div>

          <div id="lancamento-exames" class="content-section" style="display: <?php echo ($activeSection === 'lancamento-exames' ? 'block' : 'none'); ?>;">
            <h2 class="fs-4 fw-bold text-dark mb-3">
              <i class="fas fa-flask"></i> Lançar Resultados de Exames
            </h2>
            <form action="gerar_resultado_exame_pdf.php" method="POST" target="_blank">
              <div class="mb-3">
                  <label for="patient_nome" class="form-label">Nome do Paciente</label>
                  <input type="text" class="form-control form-control-custom" id="patient_nome" name="patient_nome" placeholder="Nome completo do paciente" required>
              </div>
              <div class="mb-3">
                  <label for="patient_cpf" class="form-label">CPF do Paciente</label>
                  <input type="text" class="form-control form-control-custom" id="patient_cpf" name="patient_cpf" placeholder="000.000.000-00" required>
              </div>
              <div class="mb-3">
                  <label for="patient_data_nascimento" class="form-label">Data de Nascimento</label>
                  <input type="date" class="form-control form-control-custom" id="patient_data_nascimento" name="patient_data_nascimento" required>
              </div>
              <div class="mb-3">
                  <label for="patient_genero" class="form-label">Gênero</label>
                  <select class="form-select form-select-lg" id="patient_genero" name="patient_genero" required>
                      <option value="">Selecione</option>
                      <option value="Masculino">Masculino</option>
                      <option value="Feminino">Feminino</option>
                      <option value="Outro">Outro</option>
                  </select>
              </div>
              <input type="hidden" id="id_paciente_biomedico" name="id_paciente_biomedico" value="0">
              <small class="form-text text-muted" id="selectedBiomedicPatientInfo">Preencha os dados do paciente manualmente.</small>

              <div class="mb-4">
                  <h5 class="mb-3">Resultados do Hemograma Completo</h5>
                  <div class="row g-3">
                      <div class="col-md-4">
                          <label for="hemacias" class="form-label">Hemácias ($10^6/\mu L$)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="hemacias" name="hemacias" placeholder="Ex: 5.70">
                              <span class="input-group-text">Ref: 4.00-6.10</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="hemoglobina" class="form-label">Hemoglobina (g/dL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="hemoglobina" name="hemoglobina" placeholder="Ex: 16.8">
                              <span class="input-group-text">Ref: 13.0-18.0</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="hematocrito" class="form-label">Hematócrito (%)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="hematocrito" name="hematocrito" placeholder="Ex: 49.1">
                              <span class="input-group-text">Ref: 39.0-54.0</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="vcm" class="form-label">VCM (fL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="vcm" name="vcm" placeholder="Ex: 86.1">
                              <span class="input-group-text">Ref: 80.0-98.0</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="hcm" class="form-label">HCM (pg)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="hcm" name="hcm" placeholder="Ex: 29.2">
                              <span class="input-group-text">Ref: 27.0-32.0</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="chcm" class="form-label">CHCM (g/dL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="chcm" name="chcm" placeholder="Ex: 34.2">
                              <span class="input-group-text">Ref: 30.0-36.0</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="rdw" class="form-label">RDW (%)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="rdw" name="rdw" placeholder="Ex: 13.6">
                              <span class="input-group-text">Ref: 11.0-16.0</span>
                          </div>
                      </div>
                  </div>

                  <h5 class="mt-4 mb-3">Resultados do Leucograma</h5>
                  <div class="row g-3">
                      <div class="col-md-4">
                          <label for="leucocitos" class="form-label">Leucócitos ($/mm^3$)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="leucocitos" name="leucocitos" placeholder="Ex: 8.000">
                              <span class="input-group-text">Ref: 4.000-11.000</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="bastonetes" class="form-label">Bastonetes (%)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="bastonetes" name="bastonetes" placeholder="Ex: 0">
                              <span class="input-group-text">Ref: 0-5</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="segmentados" class="form-label">Segmentados (%)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="segmentados" name="segmentados" placeholder="Ex: 55">
                              <span class="input-group-text">Ref: 40-70</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="eosinofilos" class="form-label">Eosinófilos (%)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="eosinofilos" name="eosinofilos" placeholder="Ex: 2">
                              <span class="input-group-text">Ref: 1-5</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="monocitos" class="form-label">Monócitos (%)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="monocitos" name="monocitos" placeholder="Ex: 7">
                              <span class="input-group-text">Ref: 3-10</span>
                          </div>
                      </div>
                  </div>

                  <h5 class="mt-4 mb-3">Resultados da Série Plaquetária</h5>
                  <div class="row g-3">
                      <div class="col-md-4">
                          <label for="plaquetas" class="form-label">Plaquetas ($10^3/\mu L$)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="plaquetas" name="plaquetas" placeholder="Ex: 167">
                              <span class="input-group-text">Ref: 130-450</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="vmp" class="form-label">VMP (fL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="vmp" name="vmp" placeholder="Ex: 11.8">
                              <span class="input-group-text">Ref: 6.8-12.6</span>
                          </div>
                      </div>
                  </div>

                  <h5 class="mt-4 mb-3">Outros Exames</h5>
                  <div class="row g-3">
                      <div class="col-md-4">
                          <label for="fsh" class="form-label">FSH (mUI/mL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="fsh" name="fsh" placeholder="Ex: 7.2">
                              <span class="input-group-text">Ref: Variável</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="t4_livre" class="form-label">T4 Livre (ng/dL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="t4_livre" name="t4_livre" placeholder="Ex: 1.2">
                              <span class="input-group-text">Ref: 0.8-1.8</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="glicemia" class="form-label">Glicemia (mg/dL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="glicemia" name="glicemia" placeholder="Ex: 95">
                              <span class="input-group-text">Ref: 70-99</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="prolactina" class="form-label">Prolactina (ng/mL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="prolactina" name="prolactina" placeholder="Ex: 15.0">
                              <span class="input-group-text">Ref: Variável</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="estradiol" class="form-label">Estradiol (pg/mL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="estradiol" name="estradiol" placeholder="Ex: 50.0">
                              <span class="input-group-text">Ref: Variável</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="ck_mb" class="form-label">CK-MB (ng/mL)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="ck_mb" name="ck_mb" placeholder="Ex: 5.0">
                              <span class="input-group-text">Ref: < 25</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="ast" class="form-label">AST (U/L)</label>
                          <div class="input-group exam-input-group">
                              <input type="number" step="0.01" class="form-control" id="ast" name="ast" placeholder="Ex: 20">
                              <span class="input-group-text">Ref: < 35</span>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <label for="urina" class="form-label">Exame de Urina (Observações)</label>
                          <input type="text" class="form-control" id="urina" name="urina" placeholder="Ex: Leucócitos 5-10/campo">
                      </div>
                      <div class="col-md-4">
                          <label for="diabetes_obs" class="form-label">Curva Glicêmica (Observações)</label>
                          <input type="text" class="form-control" id="diabetes_obs" name="diabetes_obs" placeholder="Ex: 90 mg/dL (jejum), 140 mg/dL (1h)">
                      </div>
                  </div>
              </div>

              <div class="mb-3">
                  <label for="observacoes_gerais_exame" class="form-label">Observações Gerais do Exame</label>
                  <textarea class="form-control form-control-custom" id="observacoes_gerais_exame" name="observacoes_gerais_exame" rows="3" placeholder="Informações adicionais relevantes para o exame."></textarea>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-4">
                <button type="submit" name="submit_resultados_biomedico" class="btn send-button">Gerar PDF do Resultado</button>

                <!-- Section for displaying generated PDF link (from previous request) -->
                <?php if ($generatedPdfLink): ?>
                    <div class="mt-3">
                        <p class="mb-2">Link do Resultado Gerado:</p>
                        <a href="<?php echo htmlspecialchars($generatedPdfLink); ?>" target="_blank" class="btn btn-info">
                            <i class="fas fa-file-pdf me-2"></i> Abrir PDF do Resultado
                        </a>
                    </div>
                <?php else: ?>
                    <div class="mt-3">
                        <p class="mb-2 text-muted">Para gerar um link, preencha os dados e clique em "Gerar PDF do Resultado". (Isso exigiria modificações no backend para salvar o PDF e retornar um link)</p>
                    </div>
                <?php endif; ?>
              </div>
            </form>

            <hr class="my-4">

            <!-- Nova seção para Gerar Link de Imagem (Blob) -->
            <div class="mb-4">
                <h5 class="mb-3">Gerar Link de Imagem (Blob)</h5>
                <div class="mb-3">
                    <label for="imageUpload" class="form-label">Selecione uma Imagem</label>
                    <input type="file" class="form-control form-control-custom" id="imageUpload" accept="image/*">
                </div>
                <button type="button" class="btn btn-primary send-button" id="generateImageBlobLinkBtn">
                    <i class="fas fa-link me-2"></i> Gerar Link da Imagem
                </button>
                <div id="imageBlobOutput" class="mt-3" style="display: none;">
                    <p class="mb-2">Link do Blob da Imagem:</p>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" id="imageBlobLink" readonly>
                        <button class="btn btn-outline-secondary" type="button" id="copyImageBlobLinkBtn">Copiar Link</button>
                    </div>
                    <div class="mb-2">
                        <p>Prévia da Imagem:</p>
                        <img id="imagePreview" src="#" alt="Prévia da Imagem" class="img-fluid rounded" style="max-width: 300px; display: none;">
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <!-- Nova seção para Gerar Link de PDF (Blob) -->
            <div class="mb-4">
                <h5 class="mb-3">Gerar Link de PDF (Blob)</h5>
                <div class="mb-3">
                    <label for="pdfUpload" class="form-label">Selecione um Arquivo PDF</label>
                    <input type="file" class="form-control form-control-custom" id="pdfUpload" accept="application/pdf">
                </div>
                <button type="button" class="btn btn-primary send-button" id="generatePdfBlobLinkBtn">
                    <i class="fas fa-file-pdf me-2"></i> Gerar Link do PDF
                </button>
                <div id="pdfBlobOutput" class="mt-3" style="display: none;">
                    <p class="mb-2">Link do Blob do PDF:</p>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" id="pdfBlobLink" readonly>
                        <button class="btn btn-outline-secondary" type="button" id="copyPdfBlobLinkBtn">Copiar Link</button>
                    </div>
                    <div class="mb-2">
                        <p>Prévia do PDF:</p>
                        <!-- Usar um iframe para exibir o PDF -->
                        <iframe id="pdfPreview" src="#" class="w-100 rounded" style="height: 500px; border: 1px solid #ced4da; display: none;"></iframe>
                    </div>
                </div>
            </div>

          </div>

          <div id="chat-medico" class="content-section" style="display: <?php echo ($activeSection === 'chat-medico' ? 'block' : 'none'); ?>;">
            <h2 class="fs-4 fw-bold text-dark mb-3">
              <i class="fas fa-comments"></i> Chat com Médico
            </h2>
            <div class="form-section">
                <?php echo $chatNotification; // Exibe a notificação aqui ?>
                <div class="mb-3">
                    <label for="medicoSelect" class="form-label">Selecionar Médico</label>
                    <select class="form-select form-select-lg" id="medicoSelect" onchange="window.location.href = 'acessexamdata.php?section=chat-medico&selected_medico=' + this.value;">
                        <option value="">-- Selecione um médico --</option>
                        <?php foreach ($allMedicos as $medico): ?>
                            <option value="<?php echo htmlspecialchars($medico['id_medico']); ?>"
                                <?php echo ($selectedMedicoId == $medico['id_medico'] ? 'selected' : ''); ?>>
                                <?php echo htmlspecialchars($medico['nome'] . ' (CRM: ' . $medico['crm'] . ', ' . $medico['especialidade'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="hidden" id="id_medico_selecionado" value="<?php echo htmlspecialchars($selectedMedicoId ?? ''); ?>">
                    <?php if ($selectedMedicoId): ?>
                        <?php
                            $selectedMedicoInfoText = 'Nenhum médico selecionado.';
                            foreach ($allMedicos as $medico) {
                                if ($medico['id_medico'] == $selectedMedicoId) {
                                    $selectedMedicoInfoText = 'Conversando com: ' . htmlspecialchars($medico['nome'] . ' (CRM: ' . $medico['crm'] . ', ' . $medico['especialidade'] . ')');
                                    break;
                                }
                            }
                        ?>
                        <small class="form-text text-muted" id="selectedMedicoInfo"><?php echo $selectedMedicoInfoText; ?></small>
                    <?php else: ?>
                        <small class="form-text text-muted" id="selectedMedicoInfo">Nenhum médico selecionado.</small>
                    <?php endif; ?>
                </div>

                <div class="chat-box" id="medico-chat-box">
                    <?php echo $chatMessagesHtml; ?>
                </div>

                <div class="mt-3" id="chat-form-container" style="display: <?php echo ($selectedMedicoId ? 'block' : 'none'); ?>;">
                    <form action="acessexamdata.php" method="POST">
                        <input type="hidden" name="action" value="send_chat_message_sync">
                        <input type="hidden" name="id_medico" value="<?php echo htmlspecialchars($selectedMedicoId ?? ''); ?>">
                        <div class="mb-2">
                            <input type="file" class="form-control" id="chatFileUpload" name="arquivo" accept="image/*,.pdf,.doc,.docx" disabled>
                            <small class="text-muted">*Upload de arquivos desabilitado para este chat*</small>
                        </div>
                        <div class="input-group">
                            <textarea class="form-control" id="chatMessageInput" name="mensagem" rows="2"
                                      placeholder="Digite sua mensagem..." <?php echo ($selectedMedicoId ? '' : 'disabled'); ?>></textarea>
                            <button type="submit" class="btn btn-primary" <?php echo ($selectedMedicoId ? '' : 'disabled'); ?>>
                                <i class="fas fa-paper-plane"></i> Enviar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
          </div>
        </div>
      </div>

      <footer class="text-center py-0 bg-light mt-auto">
      </footer>
    </div>

    <div id="customAlertModal" class="modal-custom">
        <div class="modal-content-custom">
            <span class="close-button-custom" onclick="closeModal()">&times;</span>
            <p id="customAlertMessage"></p>
            <button class="btn btn-primary" onclick="closeModal()">OK</button>
        </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      crossorigin="anonymous"
    ></script>

    <script>
        // Função para exibir o modal customizado (mantida caso outras partes do site precisem)
        function showModal(message) {
            document.getElementById('customAlertMessage').textContent = message;
            document.getElementById('customAlertModal').style.display = 'block';
        }

        // Função para fechar o modal customizado (mantida caso outras partes do site precisem)
        function closeModal() {
            document.getElementById('customAlertModal').style.display = 'none';
        }

        // Este script é apenas para inicializar o scroll do chat e gerenciar a seleção de médico no lado do cliente
        document.addEventListener('DOMContentLoaded', function() {
            const medicoChatBox = document.getElementById('medico-chat-box');
            if (medicoChatBox) {
                medicoChatBox.scrollTop = medicoChatBox.scrollHeight;
            }

            // O `onchange` do select já faz o redirecionamento, então não precisamos de um listener JS aqui.
            // A seleção do médico e o carregamento das mensagens são feitos via PHP no carregamento da página.
            // As mensagens de sucesso/erro do chat também são exibidas via PHP e sessão.

            // Lógica para Gerar Link de Imagem (Blob)
            const imageUpload = document.getElementById('imageUpload');
            const generateImageBlobLinkBtn = document.getElementById('generateImageBlobLinkBtn');
            const imageBlobOutput = document.getElementById('imageBlobOutput');
            const imageBlobLinkInput = document.getElementById('imageBlobLink');
            const copyImageBlobLinkBtn = document.getElementById('copyImageBlobLinkBtn');
            const imagePreview = document.getElementById('imagePreview');

            generateImageBlobLinkBtn.addEventListener('click', function() {
                if (imageUpload.files.length > 0) {
                    const file = imageUpload.files[0];
                    const blobUrl = URL.createObjectURL(file);

                    imageBlobLinkInput.value = blobUrl;
                    imagePreview.src = blobUrl;
                    imagePreview.style.display = 'block';
                    imageBlobOutput.style.display = 'block';
                } else {
                    showModal('Por favor, selecione uma imagem primeiro.');
                }
            });

            copyImageBlobLinkBtn.addEventListener('click', function() {
                imageBlobLinkInput.select();
                document.execCommand('copy');
                showModal('Link copiado para a área de transferência!');
            });

            // Lógica para Gerar Link de PDF (Blob)
            const pdfUpload = document.getElementById('pdfUpload');
            const generatePdfBlobLinkBtn = document.getElementById('generatePdfBlobLinkBtn');
            const pdfBlobOutput = document.getElementById('pdfBlobOutput');
            const pdfBlobLinkInput = document.getElementById('pdfBlobLink');
            const copyPdfBlobLinkBtn = document.getElementById('copyPdfBlobLinkBtn');
            const pdfPreview = document.getElementById('pdfPreview');

            generatePdfBlobLinkBtn.addEventListener('click', function() {
                if (pdfUpload.files.length > 0) {
                    const file = pdfUpload.files[0];
                    // Verifica se o arquivo é realmente um PDF
                    if (file.type === 'application/pdf') {
                        const blobUrl = URL.createObjectURL(file);

                        pdfBlobLinkInput.value = blobUrl;
                        pdfPreview.src = blobUrl;
                        pdfPreview.style.display = 'block';
                        pdfBlobOutput.style.display = 'block';
                    } else {
                        showModal('Por favor, selecione um arquivo PDF válido.');
                        pdfPreview.style.display = 'none'; // Esconde a prévia se o arquivo não for PDF
                        pdfBlobOutput.style.display = 'none';
                    }
                } else {
                    showModal('Por favor, selecione um arquivo PDF primeiro.');
                }
            });

            copyPdfBlobLinkBtn.addEventListener('click', function() {
                pdfBlobLinkInput.select();
                document.execCommand('copy');
                showModal('Link copiado para a área de transferência!');
            });
        });
    </script>
</body>
</html>
