<?php
session_start();
include_once 'conexao.php';

$erro = false;
$cadastro_sucesso = false;
$mensagem_erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'login') {
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $tipo  = $_POST['tipo'];

        try {
            if ($tipo === 'paciente') {
                $stmt = $conn->prepare("SELECT * FROM pacientes WHERE email = :email AND senha = :senha");
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':senha', $senha);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {
                    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['tipo_usuario'] = 'paciente';
                    header("Location: acesspacdata.php");
                    exit();
                } else {
                    $erro = true;
                    $mensagem_erro = 'Email ou senha incorretos para Paciente.';
                }
            } elseif ($tipo === 'medico') {
                $stmt = $conn->prepare("SELECT * FROM medicos WHERE email = :email AND senha = :senha");
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':senha', $senha);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {
                    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['tipo_usuario'] = 'medico';
                    header("Location: acessmedicdata.php");
                    exit();
                } else {
                    $erro = true;
                    $mensagem_erro = 'Email ou senha incorretos para Médico.';
                }
           } elseif ($tipo === 'exame') {
                $stmt = $conn->prepare("SELECT * FROM estabelecimentos_exame WHERE email = :email AND senha = :senha");
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':senha', $senha);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {
                    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['tipo_usuario'] = 'estabelecimento_exame';
                    header("Location: acessexamdata.php");
                    exit();
                } else {
                    $erro = true;
                    $mensagem_erro = 'Email ou senha incorretos para Exame.';
                }
            }
        } catch (PDOException $e) {
            $erro = true;
            $mensagem_erro = 'Erro no servidor. Tente novamente mais tarde.';
            error_log("Erro de login: " . $e->getMessage());
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'cadastro_paciente') {
        // Campos para cadastro de paciente
        $nome_paciente = $_POST['nome_paciente'];
        $email_paciente = $_POST['email_paciente'];
        $senha_paciente = $_POST['senha_paciente'];
        $cpf_paciente = $_POST['cpf_paciente'];
        $data_nascimento_paciente = $_POST['data_nascimento_paciente'];
        $genero_paciente = $_POST['genero_paciente'];
        $telefone_paciente = isset($_POST['telefone_paciente']) ? $_POST['telefone_paciente'] : null;
        $endereco_paciente = isset($_POST['endereco_paciente']) ? $_POST['endereco_paciente'] : null;
        $aceite_privacidade = isset($_POST['aceite_privacidade']);

        // Validação básica de CPF (apenas números)
        if (!preg_match('/^\d{11}$/', $cpf_paciente)) {
            $erro = true;
            $mensagem_erro = 'CPF inválido. Digite apenas 11 números.';
        } elseif (empty($nome_paciente) || empty($email_paciente) || empty($senha_paciente) || empty($cpf_paciente) || empty($data_nascimento_paciente) || empty($genero_paciente) || !$aceite_privacidade) {
            $erro = true;
            $mensagem_erro = 'Por favor, preencha todos os campos obrigatórios e aceite a política de privacidade.';
        } else {
            try {
                // Verificar se o CPF já existe
                $stmt_check_cpf = $conn->prepare("SELECT COUNT(*) FROM pacientes WHERE cpf = :cpf");
                $stmt_check_cpf->bindParam(':cpf', $cpf_paciente);
                $stmt_check_cpf->execute();
                if ($stmt_check_cpf->fetchColumn() > 0) {
                    $erro = true;
                    $mensagem_erro = 'CPF já cadastrado.';
                }

                // Verificar se o email já existe
                $stmt_check_email = $conn->prepare("SELECT COUNT(*) FROM pacientes WHERE email = :email");
                $stmt_check_email->bindParam(':email', $email_paciente);
                $stmt_check_email->execute();
                if ($stmt_check_email->fetchColumn() > 0) {
                    $erro = true;
                    $mensagem_erro = 'Email já cadastrado.';
                }

                if (!$erro) {
                    // ATENÇÃO: EM PRODUÇÃO, SEMPRE FAÇA HASH DA SENHA!
                    // Exemplo: $senha_hash = password_hash($senha_paciente, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO pacientes (nome, cpf, data_nascimento, genero, telefone, email, senha, endereco) VALUES (:nome, :cpf, :data_nascimento, :genero, :telefone, :email, :senha, :endereco)");
                    $stmt->bindParam(':nome', $nome_paciente);
                    $stmt->bindParam(':cpf', $cpf_paciente);
                    $stmt->bindParam(':data_nascimento', $data_nascimento_paciente);
                    $stmt->bindParam(':genero', $genero_paciente);
                    $stmt->bindParam(':telefone', $telefone_paciente);
                    $stmt->bindParam(':email', $email_paciente);
                    $stmt->bindParam(':senha', $senha_paciente); // Mudar para $senha_hash em produção
                    $stmt->bindParam(':endereco', $endereco_paciente);
                    $stmt->execute();
                    $cadastro_sucesso = true;
                }
            } catch (PDOException $e) {
                $erro = true;
                $mensagem_erro = 'Erro ao cadastrar. Tente novamente.';
                error_log("Erro de cadastro: " . $e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - AgilixMedtech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Variáveis CSS para o tema */
        :root {
            /* Light Theme Variables */
            --bg-color: #f8f9fa;
            --text-color: #262626;
            --card-bg: #ffffff;
            --card-border: #dbdbdb;
            --input-bg: #fafafa;
            --input-border: #dbdbdb;
            --input-focus-border: #a8a8a8;
            --link-color: #007bff;
            --link-hover-color: #0056b3;
            --button-switch-bg: #e0f2f7;
            --button-switch-color: #007bff;
            --button-switch-hover-bg: #d1ecf1;
            --button-switch-hover-color: #0056b3;
            /* Error and Success colors are theme-agnostic */
            --error-color: #ed4956;
            --success-color: #28a745;
        }

        [data-theme="dark"] {
            /* Dark Theme Overrides */
            --bg-color: #121212;
            --text-color: #e0e0e0;
            --card-bg: #1e1e1e;
            --card-border: #333333;
            --input-bg: #2c2c2c;
            --input-border: #555555;
            --input-focus-border: #007bff;
            --link-color: #66b3ff;
            --link-hover-color: #3399ff;
            --button-switch-bg: #004085;
            --button-switch-color: #a8d8ff;
            --button-switch-hover-bg: #0056b3;
            --button-switch-hover-color: #ffffff;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
            overflow: hidden;
        }
        .login-card {
            background-color: var(--card-bg);
            border: 1px solid var(--card-border);
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        input[type="email"],
        input[type="password"],
        input[type="text"],
        input[type="date"],
        input[type="number"],
        select,
        textarea {
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 3px;
            padding: 10px 12px;
            font-size: 14px;
            color: var(--text-color);
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }
        input[type="email"]::placeholder,
        input[type="password"]::placeholder,
        input[type="text"]::placeholder,
        input[type="date"]::placeholder,
        input[type="number"]::placeholder,
        select::placeholder,
        textarea::placeholder {
            color: var(--text-color);
            opacity: 0.7;
        }
        input[type="email"]:focus,
        input[type="password"]:focus,
        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="number"]:focus,
        select:focus,
        textarea:focus {
            border-color: var(--input-focus-border);
            outline: none;
            box-shadow: none;
        }
        .login-button {
            background-color: var(--button-primary-bg);
            color: white;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background-color 0.2s ease;
        }
        .login-button:hover {
            background-color: var(--button-primary-hover-bg);
        }
        .login-button:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
        .error-message {
            color: var(--error-color);
            font-size: 12px;
            margin-top: 8px;
            text-align: center;
        }
        .success-message {
            color: var(--success-color);
            font-size: 14px;
            margin-top: 8px;
            text-align: center;
            font-weight: bold;
        }
        .switch-login-type-button {
            padding: 8px 12px;
            border-radius: 6px;
            font-weight: 500;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        #btn-paciente { background-color: #3b82f6; color: white; }
        #btn-paciente.active { background-color: #2563eb; }
        #btn-medico { background-color: #22c55e; color: white; }
        #btn-medico.active { background-color: #16a34a; }
        #btn-exame { background-color: #a855f7; color: white; }
        #btn-exame.active { background-color: #9333ea; }

        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, .3);
            border-radius: 50%;
            border-top-color: #007bff;
            animation: spin 1s ease-in-out infinite;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            display: none;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        #backgroundCanvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: -1;
            background-color: var(--bg-color);
        }

        .content-overlay {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1rem;
        }

        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: var(--card-bg);
            color: var(--text-color);
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
            z-index: 1000;
            max-width: 95%;
            width: 450px;
            box-sizing: border-box;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal button {
            margin-top: 10px;
            padding: 6px 12px;
            background: var(--link-color);
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            font-size: 0.875rem;
        }
        .modal button:hover {
            background: var(--link-hover-color);
        }
        .modal .cancel-button {
            background: #6c757d;
        }
        .modal .cancel-button:hover {
            background: #5a6268;
        }
        .modal h3 {
            color: var(--text-color);
            font-size: 1rem;
            margin-bottom: 10px;
        }

        /* Responsive adjustments */
        @media (max-width: 640px) {
            .modal {
                width: 95%;
                padding: 10px;
            }
            .modal h3 {
                font-size: 1rem;
            }
        }

        /* Compact registration modal */
        #modalCadastroCompletoPaciente {
            width: 450px;
            max-width: 95%;
            padding: 12px 15px;
        }
        #modalCadastroCompletoPaciente input,
        #modalCadastroCompletoPaciente select {
            padding: 6px 8px;
            font-size: 0.75rem;
        }
        #modalCadastroCompletoPaciente label {
            font-size: 0.75rem;
            margin-bottom: 3px;
        }
        #modalCadastroCompletoPaciente .grid div {
            margin-bottom: 0;
        }
        #modalCadastroCompletoPaciente .text-xs {
            font-size: 0.75rem;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">

<div class="absolute top-4 right-4">
    <button id="theme-toggle" class="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
        <svg id="sun-icon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h1M3 12h1m15.325-7.757l-.707.707M5.385 18.325l-.707.707m12.728 0l-.707-.707M6.092 5.385l-.707-.707"></path>
        </svg>
        <svg id="moon-icon" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path>
        </svg>
    </button>
</div>

<canvas id="backgroundCanvas"></canvas>

<div class="content-overlay">
    <div class="bg-white rounded-xl shadow-lg p-6 max-w-md w-full animate-fadeIn login-card">
        <div class="text-center mb-6">
            <h1 class="text-lg font-semibold text-gray-700">AgilixMedtech</h1>
        </div>

        <?php if ($erro): ?>
            <div class="error-message mb-4">
                <?php echo htmlspecialchars($mensagem_erro); ?>
            </div>
        <?php endif; ?>
        <?php if ($cadastro_sucesso): ?>
            <div class="success-message mb-4">
                Cadastro realizado com sucesso! Faça login.
            </div>
        <?php endif; ?>

        <div class="flex justify-center mb-4 gap-2">
            <button type="button" onclick="showLoginType('paciente')" class="switch-login-type-button active" id="btn-paciente">Paciente</button>
            <button type="button" onclick="showLoginType('medico')" class="switch-login-type-button" id="btn-medico">Médico</button>
            <button type="button" onclick="showLoginType('exame')" class="switch-login-type-button" id="btn-exame">Exame</button>
        </div>

        <div id="paciente-login" class="login-form">
            <h2 class="text-center text-blue-600 text-base font-semibold mb-3">Login Paciente</h2>
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="paciente">
                <input type="email" name="email" placeholder="Email" required class="w-full p-2 border rounded text-sm">
                <input type="password" name="senha" placeholder="Senha" required class="w-full p-2 border rounded text-sm">
                <button type="submit" class="w-full bg-blue-600 text-white py-2 text-sm rounded hover:bg-blue-700">Entrar</button>
            </form>
            <p class="text-center text-sm mt-3">Não tem uma conta? <a href="#" onclick="openCadastroModalCompleto(); return false;" class="text-blue-500 font-semibold hover:underline">Cadastre-se</a></p>
        </div>

        <div id="medico-login" class="login-form hidden">
            <h2 class="text-center text-green-600 text-base font-semibold mb-3">Login Médico</h2>
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="medico">
                <input type="email" name="email" placeholder="Email Profissional" required class="w-full p-2 border rounded text-sm">
                <input type="password" name="senha" placeholder="Senha" required class="w-full p-2 border rounded text-sm">
                <button type="submit" class="w-full bg-green-600 text-white py-2 text-sm rounded hover:bg-green-700">Entrar</button>
            </form>
            <p class="text-center text-sm mt-3">Não tem uma conta? <a href="#" onclick="openCadastroModalCompleto(); return false;" class="text-blue-500 font-semibold hover:underline">Cadastre-se</a></p>
        </div>

        <div id="exame-login" class="login-form hidden">
            <h2 class="text-center text-purple-600 text-base font-semibold mb-3">Login Exame</h2>
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="exame">
                <input type="email" name="email" placeholder="Email" required class="w-full p-2 border rounded text-sm">
                <input type="password" name="senha" placeholder="Senha" required class="w-full p-2 border rounded text-sm">
                <button type="submit" class="w-full bg-purple-600 text-white py-2 text-sm rounded hover:bg-purple-700">Entrar</button>
            </form>
            <p class="text-center text-sm mt-3">Não tem uma conta? <a href="#" onclick="openCadastroModalCompleto(); return false;" class="text-blue-500 font-semibold hover:underline">Cadastre-se</a></p>
        </div>

        <div class="text-center mt-4">
            <a href="#" class="text-blue-500 text-sm font-semibold hover:underline">Esqueceu a senha?</a>
        </div>
    </div>
</div>

<div class="modal" id="modalErro">
    <h3 style="text-align:center;">😢 Não foi sua culpa, tente novamente!</h3>
    <p style="text-align:center; color: var(--error-color); font-weight: bold; font-size: 14px;"><?php echo $mensagem_erro; ?></p>
    <div style="text-align:center;">
        <button onclick="closeModal('modalErro')">Fechar</button>
    </div>
</div>

<!-- Modal de Cadastro Completo de Paciente (Compacto) -->
<div class="modal" id="modalCadastroCompletoPaciente">
    <h3 class="text-center text-blue-600 text-sm font-semibold mb-2">Cadastre-se como Paciente</h3>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="space-y-2">
        <input type="hidden" name="action" value="cadastro_paciente">
        <input type="text" name="nome_paciente" placeholder="Nome Completo" required class="w-full p-1 rounded text-xs">
        <input type="email" name="email_paciente" placeholder="Email" required class="w-full p-1 rounded text-xs">
        <input type="password" name="senha_paciente" placeholder="Senha" required class="w-full p-1 rounded text-xs">
        <input type="text" name="cpf_paciente" placeholder="CPF (somente números)" required class="w-full p-1 rounded text-xs" pattern="\d{11}" title="Digite apenas 11 números para o CPF">
        <input type="date" name="data_nascimento_paciente" required class="w-full p-1 rounded text-xs">
        <select name="genero_paciente" required class="w-full p-1 rounded text-xs">
            <option value="">Gênero</option>
            <option value="Masculino">Masculino</option>
            <option value="Feminino">Feminino</option>
            <option value="Outro">Outro</option>
        </select>
        <input type="text" name="telefone_paciente" placeholder="Telefone (Opcional)" class="w-full p-1 rounded text-xs">

        <div class="relative">
            <label for="modal-cep" class="block text-xs font-medium mb-1">CEP</label>
            <input type="text" name="cep" id="modal-cep" placeholder="00000-000" required class="w-full p-1 rounded text-xs" onblur="consultarCepModal()">
            <div id="cep-loading-spinner-modal" class="loading-spinner"></div>
        </div>
        <div>
            <label for="modal-logradouro" class="block text-xs font-medium mb-1">Logradouro</label>
            <input type="text" name="logradouro" id="modal-logradouro" placeholder="Rua, Avenida, etc." required class="w-full p-1 rounded text-xs">
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-1">
            <div>
                <label for="modal-numero" class="block text-xs font-medium mb-1">Número</label>
                <input type="text" name="numero" id="modal-numero" placeholder="Número" class="w-full p-1 rounded text-xs">
            </div>
            <div>
                <label for="modal-complemento" class="block text-xs font-medium mb-1">Complemento</label>
                <input type="text" name="complemento" id="modal-complemento" placeholder="Apto, Bloco, etc." class="w-full p-1 rounded text-xs">
            </div>
            <div>
                <label for="modal-bairro" class="block text-xs font-medium mb-1">Bairro</label>
                <input type="text" name="bairro" id="modal-bairro" placeholder="Bairro" required class="w-full p-1 rounded text-xs">
            </div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-1">
            <div>
                <label for="modal-localidade" class="block text-xs font-medium mb-1">Cidade</label>
                <input type="text" name="localidade" id="modal-localidade" placeholder="Cidade" required class="w-full p-1 rounded text-xs">
            </div>
            <div>
                <label for="modal-uf" class="block text-xs font-medium mb-1">Estado (UF)</label>
                <input type="text" name="uf" id="modal-uf" placeholder="UF" maxlength="2" required class="w-full p-1 rounded text-xs">
            </div>
        </div>

        <div class="mt-2 p-2 text-xs" style="background-color: var(--input-bg); border-radius: 0.375rem;">
            <h3 class="font-bold mb-1">Política de Privacidade</h3>
            <p>Ao se cadastrar, você concorda com a nossa política de privacidade. Seus dados serão utilizados apenas para fins de gerenciamento de saúde e não serão compartilhados com terceiros sem seu consentimento explícito.</p>
            <label class="inline-flex items-center mt-1">
                <input type="checkbox" name="aceite_privacidade" required class="form-checkbox text-blue-600">
                <span class="ml-2">Li e aceito a Política de Privacidade</span>
            </label>
        </div>

        <button type="submit" class="w-full bg-blue-600 text-white py-1 text-xs rounded mt-2">Cadastrar</button>
    </form>
    <div style="text-align:center; margin-top: 10px;">
        <button onclick="closeModal('modalCadastroCompletoPaciente')" class="cancel-button text-xs px-3 py-1">Cancelar</button>
    </div>
</div>

<div class="modal" id="modalCadastroSucesso">
    <h3 style="text-align:center; color: var(--success-color);">🎉 Cadastro realizado com sucesso!</h3>
    <p style="text-align:center;">Agora você pode fazer login com suas credenciais.</p>
    <div style="text-align:center;">
        <button onclick="closeModal('modalCadastroSucesso')">Fechar</button>
    </div>
</div>

<script>
    const themeToggleBtn = document.getElementById('theme-toggle');
    const sunIcon = document.getElementById('sun-icon');
    const moonIcon = document.getElementById('moon-icon');

    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.setAttribute('data-theme', 'dark');
        sunIcon.classList.add('hidden');
        moonIcon.classList.remove('hidden');
    } else {
        document.documentElement.setAttribute('data-theme', 'light');
        sunIcon.classList.remove('hidden');
        moonIcon.classList.add('hidden');
    }

    themeToggleBtn.addEventListener('click', () => {
        if (document.documentElement.getAttribute('data-theme') === 'dark') {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
    });

    function showLoginType(type) {
        const loginForms = document.querySelectorAll('.login-form');
        loginForms.forEach(form => form.classList.add('hidden'));

        const buttons = document.querySelectorAll('.switch-login-type-button');
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`${type}-login`).classList.remove('hidden');
        document.getElementById(`btn-${type}`).classList.add('active');
    }

    function openCadastroModalCompleto() {
        document.getElementById('modalCadastroCompletoPaciente').style.display = 'block';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
        if (modalId === 'modalErro') {
            document.getElementById('modalErro').classList.remove('error-shake');
        }
    }

    async function consultarCepModal() {
        const cepInput = document.getElementById('modal-cep');
        const logradouroInput = document.getElementById('modal-logradouro');
        const bairroInput = document.getElementById('modal-bairro');
        const localidadeInput = document.getElementById('modal-localidade');
        const ufInput = document.getElementById('modal-uf');
        const spinner = document.getElementById('cep-loading-spinner-modal');

        const cep = cepInput.value.replace(/\D/g, '');

        if (cep.length !== 8) {
            logradouroInput.value = '';
            bairroInput.value = '';
            localidadeInput.value = '';
            ufInput.value = '';
            return;
        }

        spinner.style.display = 'inline-block';

        try {
            const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await response.json();

            if (data.erro) {
                document.getElementById('modalErro').querySelector('p').textContent = 'CEP não encontrado.';
                document.getElementById('modalErro').style.display = 'block';
                document.getElementById('modalErro').classList.add('error-shake');

                logradouroInput.value = '';
                bairroInput.value = '';
                localidadeInput.value = '';
                ufInput.value = '';
            } else {
                logradouroInput.value = data.logradouro;
                bairroInput.value = data.bairro;
                localidadeInput.value = data.localidade;
                ufInput.value = data.uf;
            }
        } catch (error) {
            console.error('Erro ao consultar CEP:', error);
            document.getElementById('modalErro').querySelector('p').textContent = 'Erro ao consultar CEP. Tente novamente.';
            document.getElementById('modalErro').style.display = 'block';
            document.getElementById('modalErro').classList.add('error-shake');

            logradouroInput.value = '';
            bairroInput.value = '';
            localidadeInput.value = '';
            ufInput.value = '';
        } finally {
            spinner.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        showLoginType('paciente');
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('show_register_success') === 'true') {
            document.getElementById('modalCadastroSucesso').style.display = 'block';
        }
    });
</script>

</body>
</html>