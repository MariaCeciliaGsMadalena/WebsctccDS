 // Função para alternar entre os formulários de login e cadastro
    function showLoginType(type) {
        // Esconder todos os formulários de login
        document.querySelectorAll('.login-form').forEach(form => {
            form.classList.add('hidden');
        });
        // Remover a classe 'active' de todos os botões de tipo de login
        document.querySelectorAll('.switch-login-type-button').forEach(button => {
            button.classList.remove('active');
        });

        // Esconder a seção de cadastro
        document.getElementById('cadastro-section').classList.add('hidden');
        // Mostrar as seções de login e o link de cadastro
        document.getElementById('login-main-card').classList.remove('hidden');
        document.getElementById('signup-section-link').classList.remove('hidden');


        // Mostrar o formulário de login selecionado
        document.getElementById(type + '-login').classList.remove('hidden');
        // Adicionar a classe 'active' ao botão de tipo de login clicado
        document.getElementById('btn-' + type).classList.add('active');
    }

    function showRegistrationForm() {
        // Esconder todas as seções de login e seus botões
        document.querySelectorAll('.login-form').forEach(form => {
            form.classList.add('hidden');
        });
        document.querySelectorAll('.switch-login-type-button').forEach(button => {
            button.classList.remove('active');
        });
        document.getElementById('login-main-card').classList.add('hidden');
        document.getElementById('signup-section-link').classList.add('hidden');

        // Mostrar a seção de cadastro
        document.getElementById('cadastro-section').classList.remove('hidden');
        // Garantir que os campos de médico estejam ocultos por padrão no cadastro
        document.getElementById('doctor-fields').classList.add('hidden');
        document.getElementById('register-user-type').value = 'paciente'; // Define o tipo padrão
        document.querySelector('input[name="register_user_type_radio"][value="paciente"]').checked = true;
    }

    function showLoginForms() {
        // Esconder a seção de cadastro
        document.getElementById('cadastro-section').classList.add('hidden');

        // Mostrar as seções de login e o link de cadastro
        document.getElementById('login-main-card').classList.remove('hidden');
        document.getElementById('signup-section-link').classList.remove('hidden');

        // Mostrar o formulário de login de paciente por padrão e ativar o botão correspondente
        showLoginType('paciente');
    }

    function toggleDoctorFields() {
        const userTypeRadios = document.querySelectorAll('input[name="register_user_type_radio"]');
        let selectedType = 'paciente';
        for (const radio of userTypeRadios) {
            if (radio.checked) {
                selectedType = radio.value;
                break;
            }
        }

        const doctorFields = document.getElementById('doctor-fields');
        const registerUserTypeHidden = document.getElementById('register-user-type');

        if (selectedType === 'medico') {
            doctorFields.classList.remove('hidden');
        } else {
            doctorFields.classList.add('hidden');
        }
        registerUserTypeHidden.value = selectedType; // Update hidden input for form submission
    }

    // --- Lógica do Modo Escuro/Claro ---
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;
    const sunIcon = document.getElementById('sun-icon');
    const moonIcon = document.getElementById('moon-icon');

    // Função para aplicar o tema
    function applyTheme(theme) {
        if (theme === 'dark') {
            body.setAttribute('data-theme', 'dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        } else {
            body.removeAttribute('data-theme'); // Remove o atributo para usar o tema claro padrão
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        }
        localStorage.setItem('theme', theme); // Salva a preferência
    }

    // Carrega o tema salvo ou define o padrão do sistema
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        applyTheme(savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        // Se o sistema operacional estiver em modo escuro e não houver preferência salva, aplica o modo escuro
        applyTheme('dark');
    } else {
        // Por padrão, se não há preferência salva e o sistema não está em dark mode, inicia em dark mode
        applyTheme('dark'); // Alterado para iniciar em dark mode por padrão
    }

    // Alterna o tema ao clicar no botão
    themeToggle.addEventListener('click', () => {
        const currentTheme = body.getAttribute('data-theme');
        if (currentTheme === 'dark') {
            applyTheme('light');
        } else {
            applyTheme('dark');
        }
    });

    // --- Lógica ViaCEP ---
    async function consultarCep() {
        const cepInput = document.getElementById('register-cep');
        const logradouroInput = document.getElementById('register-logradouro');
        const bairroInput = document.getElementById('register-bairro');
        const localidadeInput = document.getElementById('register-localidade');
        const ufInput = document.getElementById('register-uf');
        const cepSpinner = document.getElementById('cep-loading-spinner');

        let cep = cepInput.value.replace(/\D/g, ''); // Remove caracteres não numéricos

        // Limpa os campos de endereço enquanto consulta
        logradouroInput.value = '';
        bairroInput.value = '';
            localidadeInput.value = '';
            ufInput.value = '';

        if (cep.length !== 8) {
            return; // CEP inválido (não tem 8 dígitos)
        }

        cepSpinner.style.display = 'inline-block'; // Mostra o spinner

        try {
            const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await response.json();

            if (!data.erro) {
                logradouroInput.value = data.logradouro;
                bairroInput.value = data.bairro;
                localidadeInput.value = data.localidade;
                ufInput.value = data.uf;
            } else {
                // CEP não encontrado
                alert('CEP não encontrado. Por favor, verifique o CEP digitado.');
            }
        } catch (error) {
            console.error('Erro ao consultar ViaCEP:', error);
            alert('Ocorreu um erro ao consultar o CEP. Tente novamente.');
        } finally {
            cepSpinner.style.display = 'none'; // Esconde o spinner
        }
    }
    // Torna a função global para ser acessível pelo onblur no HTML
    window.consultarCep = consultarCep;


    // Inicializa mostrando o login de paciente por padrão ao carregar a página
    document.addEventListener('DOMContentLoaded', () => {
        // Verifica se a URL contém um parâmetro para mostrar a mensagem de sucesso de cadastro
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('show_register_success') === 'true') {
            showLoginForms(); // Volta para a tela de login
        } else {
            showLoginType('paciente');
        }
    });