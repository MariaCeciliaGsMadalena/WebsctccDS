<?php
session_start();
include_once 'conexao.php';

// Funções de verificação embutidas:
function verificarLoginPaciente($conn, $email, $senha) {
    $sql = "SELECT * FROM pacientes WHERE email = ? AND senha = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$email, $senha]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function verificarLoginMedico($conn, $email, $senha) {
    $sql = "SELECT * FROM medicos WHERE email = ? AND senha = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$email, $senha]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Se for um POST, processa o login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    $tipo = $_POST['tipo'] ?? '';

    if ($tipo === 'paciente') {
        $paciente = verificarLoginPaciente($conn, $email, $senha);
        if ($paciente) {
            echo "<script>alert('Bem-vindo(a), {$paciente['nome']}!'); window.location.href='acesspacdata.php';</script>";
            exit;
        } else {
            echo "<script>alert('Email ou senha de paciente incorretos.'); window.location.href='login.php';</script>";
            exit;
        }
    } elseif ($tipo === 'medico') {
        $medico = verificarLoginMedico($conn, $email, $senha);
        if ($medico) {
            echo "<script>alert('Bem-vindo(a), Dr(a). {$medico['nome']}!'); window.location.href='acessmedicdata.php';</script>";
            exit;
        } else {
            echo "<script>alert('Email ou senha de médico incorretos.'); window.location.href='login.php';</script>";
            exit;
        }
    } else {
        echo "<script>alert('Tipo de login inválido.'); window.location.href='login.php';</script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Portal Saúde</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen px-4">

<div class="bg-white rounded-xl shadow-lg p-6 max-w-md w-full">
    <div class="text-center mb-6">
        <h1 class="text-lg font-semibold text-gray-700">AgilixMedtech</h1>
    </div>

    <div class="flex justify-center mb-4 gap-2">
        <button onclick="showSlide('paciente')" class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">Paciente</button>
        <button onclick="showSlide('medico')" class="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600">Médico</button>
    </div>

    <!-- Formulário PACIENTE -->
    <div id="paciente" class="slide active">
        <h2 class="text-center text-blue-600 text-base font-semibold mb-3">Login Paciente</h2>
        <form method="POST" class="space-y-3">
            <input type="hidden" name="tipo" value="paciente">
            <input type="email" name="email" placeholder="Email" required class="w-full p-2 border rounded text-sm">
            <input type="password" name="senha" placeholder="Senha" required class="w-full p-2 border rounded text-sm">
            <button type="submit" class="w-full bg-blue-600 text-white py-2 text-sm rounded hover:bg-blue-700">Entrar</button>
        </form>
    </div>

    <!-- Formulário MÉDICO -->
    <div id="medico" class="slide hidden">
        <h2 class="text-center text-green-600 text-base font-semibold mb-3">Login Médico</h2>
        <form method="POST" class="space-y-3">
            <input type="hidden" name="tipo" value="medico">
            <input type="email" name="email" placeholder="Email Profissional" required class="w-full p-2 border rounded text-sm">
            <input type="password" name="senha" placeholder="Senha" required class="w-full p-2 border rounded text-sm">
            <button type="submit" class="w-full bg-green-600 text-white py-2 text-sm rounded hover:bg-green-700">Entrar</button>
        </form>
    </div>
</div>

<script>
    function showSlide(slideId) {
        const slides = document.querySelectorAll('.slide');
        slides.forEach(slide => slide.classList.add('hidden'));
        document.getElementById(slideId).classList.remove('hidden');
    }
</script>

</body>
</html>
