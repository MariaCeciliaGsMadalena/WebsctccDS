<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Médico - SUS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="stylemenu.css">
</head>
<body>

    <div id="wrapper">
        <div id="sidebar-wrapper">
            <div class="sidebar-heading">
                <i class="fas fa-user-md"></i> Médico
                <small class="d-block mt-1">CRM: 123456</small>
            </div>
            <div class="list-group list-group-flush">
                <a href="#" class="list-group-item list-group-item-action active" id="menu-dashboard"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-new-consultation"><i class="fas fa-stethoscope"></i> Nova Consulta</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-patient-history"><i class="fas fa-notes-medical"></i> Histórico Paciente</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-appointments"><i class="fas fa-calendar-alt"></i> Agendamentos</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-medical-certificates"><i class="fas fa-file-medical"></i> Atestados</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-exams"><i class="fas fa-x-ray"></i> Exames</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-reports"><i class="fas fa-chart-pie"></i> Relatórios</a>
                <a href="#" class="list-group-item list-group-item-action" id="menu-settings"><i class="fas fa-cogs"></i> Configurações</a>
            </div>
        </div>
        <div id="page-content-wrapper">
            <div class="container-fluid">

                <div id="dashboard" class="content-section">
                    <h2><i class="fas fa-chart-line"></i> Visão Geral do Dia</h2>
                    <div class="row dashboard-cards">
                        <div class="col-md-4">
                            <div class="card text-white bg-primary mb-3">
                                <div class="card-header">Consultas de Hoje</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="consultasHoje">0</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-white bg-success mb-3">
                                <div class="card-header">Tempo Médio das Últimas 10 Consultas</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="tempoMedio">0 min</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-dark bg-warning mb-3">
                                <div class="card-header">Próximo Paciente</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="proximoPacienteNome">Nenhum</h5>
                                    <p id="proximoPacienteHorario">Horário: --:--</p>
                                    <p id="proximoPacienteMotivo">Motivo: -</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-4">
                        <div class="card-header"><i class="fas fa-history"></i> Últimas Consultas (Recentes)</div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush" id="recent-consultations-list">
                                <li class="list-group-item">
                                    <strong>Maria Souza</strong> (45 anos) - Motivo: Dor de cabeça - <small>10/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>Carlos Alberto</strong> (28 anos) - Motivo: Resfriado - <small>09/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>Ana Paula</strong> (60 anos) - Motivo: Checape Anual - <small>08/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                            </ul>
                            <button class="btn btn-sm btn-outline-primary mt-3">Ver Todas as Consultas</button>
                        </div>
                    </div>
                </div>

                <div id="new-consultation" class="content-section" style="display: none;">
                    <h2><i class="fas fa-stethoscope"></i> Iniciar Nova Consulta</h2>
                    <div class="form-section">
                        <h4 class="mb-3">Começar consulta</h4>
                        <div class="timer-display" id="timer">00:00:00</div>
                        <div class="mb-3 btn-group-timer">
                            <button class="btn btn-success" id="startBtn"><i class="fas fa-play"></i> Iniciar</button>
                            <button class="btn btn-warning" id="pauseBtn"><i class="fas fa-pause"></i> Pausar</button>
                            <button class="btn btn-danger" id="resetBtn"><i class="fas fa-redo"></i> Resetar</button>
                        </div>
                        <p><strong>Status:</strong> <span id="consultationStatus">Primeira consulta</span></p>
                        <p><strong>CPF do paciente:</strong> <span id="patientCpf">CPF não informado</span></p>
                    </div>

                    <div class="form-section">
                        <h4 class="mb-3">Dados do Paciente</h4>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="patientName" class="form-label">Nome do Paciente</label>
                                <input type="text" class="form-control" id="patientName" placeholder="Nome Completo do Paciente">
                            </div>
                            <div class="col-md-3">
                                <label for="patientAge" class="form-label">Idade</label>
                                <input type="number" class="form-control" id="patientAge" min="0">
                            </div>
                            <div class="col-md-3">
                                <label for="patientGender" class="form-label">Sexo</label>
                                <select class="form-select" id="patientGender">
                                    <option selected>Selecione</option>
                                    <option value="M">Masculino</option>
                                    <option value="F">Feminino</option>
                                    <option value="O">Outro</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="patientCpfInput" class="form-label">CPF do Paciente</label>
                            <input type="text" class="form-control" id="patientCpfInput" placeholder="000.000.000-00">
                        </div>
                        <div class="mb-3">
                            <label for="patientReason" class="form-label">Motivo da Consulta</label>
                            <textarea class="form-control" id="patientReason" rows="3" placeholder="Sintomas, queixas, etc."></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="patientDiagnosis" class="form-label">Diagnóstico (CID-10)</label>
                            <textarea class="form-control" id="patientDiagnosis" rows="2" placeholder="Ex: R51 - Cefaleia"></textarea>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="mb-3">Receita Médica</h4>
                        <div class="mb-3">
                            <label for="prescribedMedications" class="form-label">Medicamentos Prescritos</label>
                            <textarea class="form-control" id="prescribedMedications" rows="5" placeholder="Ex: Paracetamol 500mg, 2x ao dia por 5 dias"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="observations" class="form-label">Observações</label>
                            <textarea class="form-control" id="observations" rows="3" placeholder="Instruções adicionais, repouso, etc."></textarea>
                        </div>
                        <button class="btn btn-primary" id="generatePdfBtn"><i class="fas fa-file-pdf"></i> Gerar Receita em PDF</button>
                    </div>

                    <div class="form-section text-center">
                        <button class="btn btn-success btn-lg"><i class="fas fa-save"></i> Finalizar e Salvar Consulta</button>
                    </div>
                </div>

                <div id="patient-history" class="content-section" style="display: none;">
                    <h2><i class="fas fa-notes-medical"></i> Histórico do Paciente</h2>
                    <div class="form-section">
                        <div class="mb-3">
                            <label for="searchPatientCpf" class="form-label">Buscar Paciente por CPF</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="searchPatientCpf" placeholder="Digite o CPF do paciente">
                                <button class="btn btn-outline-primary" type="button" id="searchPatientBtn"><i class="fas fa-search"></i> Buscar</button>
                            </div>
                        </div>
                        <div id="patient-details" style="display: none;">
                            <h4>Detalhes do Paciente: <span id="displayPatientName"></span> (<span id="displayPatientCpf"></span>)</h4>
                            <p><strong>Idade:</strong> <span id="displayPatientAge"></span></p>
                            <p><strong>Sexo:</strong> <span id="displayPatientGender"></span></p>
                            <h5>Histórico de Consultas</h5>
                            <ul class="list-group" id="consultation-history-list">
                                <li class="list-group-item">
                                    <strong>15/05/2025 - Resfriado Comum</strong>
                                    <p><small>Diagnóstico: J00 (Resfriado Comum)</small></p>
                                    <p><small>Medicamentos: Amoxicilina 500mg, 1x ao dia por 7 dias.</small></p>
                                    <p><small>Observações: Repouso por 3 dias.</small></p>
                                    <button class="btn btn-sm btn-outline-info mt-2">Ver Detalhes Completos</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>01/03/2025 - Dor de Estômago</strong>
                                    <p><small>Diagnóstico: R10.1 (Dor abdominal superior)</small></p>
                                    <p><small>Medicamentos: Omeprazol 20mg, 1x ao dia por 14 dias.</small></p>
                                    <p><small>Observações: Dieta leve.</small></p>
                                    <button class="btn btn-sm btn-outline-info mt-2">Ver Detalhes Completos</button>
                                </li>
                            </ul>
                        </div>
                        <div id="no-patient-found" class="alert alert-warning mt-3" style="display: none;">
                            Nenhum paciente encontrado com o CPF informado.
                        </div>
                    </div>
                </div>

                <div id="appointments" class="content-section" style="display: none;">
                    <h2><i class="fas fa-calendar-alt"></i> Agendamentos</h2>
                    <div class="form-section">
                        <h4>Agendamentos do Dia</h4>
                        <ul class="list-group mb-3">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>09:00</strong> - Ana Pereira (40 anos) - Consulta de Rotina
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success me-2"><i class="fas fa-check"></i> Atender</button>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i> Cancelar</button>
                                </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>10:30</strong> - Roberto Costa (55 anos) - Retorno de Exames
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success me-2"><i class="fas fa-check"></i> Atender</button>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i> Cancelar</button>
                                </div>
                            </li>
                        </ul>
                        <button class="btn btn-primary"><i class="fas fa-plus"></i> Novo Agendamento</button>
                    </div>
                    <div class="form-section mt-3">
                        <h4>Calendário de Agendamentos</h4>
                        <div class="alert alert-info">
                            Funcionalidade de calendário seria implementada aqui (requer biblioteca JS).
                        </div>
                    </div>
                </div>
<div id="medical-certificates" class="content-section" style="display: none;">
    <h2><i class="fas fa-file-medical"></i> Gerar Atestado Médico</h2>
    <div class="form-section">
        <form action="gerar_atestado.php" method="POST" target="_blank"> <div class="mb-3">
                <label for="attestPatientName" class="form-label">Nome do Paciente</label>
                <input type="text" class="form-control" id="attestPatientName" name="attestPatientName" placeholder="Nome Completo do Paciente" required>
            </div>
            <div class="mb-3">
                <label for="attestRg" class="form-label">Número do RG</label>
                <input type="text" class="form-control" id="attestRg" name="attestRg" placeholder="Ex: 12.345.678-9" required>
            </div>
            <div class="mb-3">
                <label for="attestDate" class="form-label">Data do Atendimento</label>
                <input type="date" class="form-control" id="attestDate" name="attestDate" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="mb-3">
                <label for="attestDays" class="form-label">Número de Dias de Afastamento</label>
                <input type="number" class="form-control" id="attestDays" name="attestDays" min="1" value="1" required>
            </div>
            <div class="mb-3">
                <label for="attestReason" class="form-label">Motivo do Afastamento</label>
                <textarea class="form-control" id="attestReason" name="attestReason" rows="3" placeholder="Ex: Repouso devido a gripe." required></textarea>
            </div>
            <div class="mb-3">
                <label for="attestRelevantInfo" class="form-label">Informações Relevantes (Opcional)</label>
                <textarea class="form-control" id="attestRelevantInfo" name="attestRelevantInfo" rows="3" placeholder="Qualquer informação adicional para o atestado."></textarea>
            </div>
            <div class="mb-3">
                <label for="attestLocal" class="form-label">Local de Emissão</label>
                <input type="text" class="form-control" id="attestLocal" name="attestLocal" value="Franca-SP" placeholder="Cidade-UF">
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-file-pdf"></i> Gerar Atestado em PDF</button>
        </form>
    </div>
</div>
            

                <div id="exams" class="content-section" style="display: none;">
                    <h2><i class="fas fa-x-ray"></i> Solicitar/Visualizar Exames</h2>
                    <div class="form-section">
                        <h4>Solicitar Novo Exame</h4>
                        <div class="mb-3">
                            <label for="examPatientName" class="form-label">Nome do Paciente</label>
                            <input type="text" class="form-control" id="examPatientName" placeholder="Nome Completo do Paciente">
                        </div>
                        <div class="mb-3">
                            <label for="examType" class="form-label">Tipo de Exame</label>
                            <input type="text" class="form-control" id="examType" placeholder="Ex: Hemograma Completo, Raio-X de Tórax">
                        </div>
                        <div class="mb-3">
                            <label for="examObservations" class="form-label">Observações para o Exame</label>
                            <textarea class="form-control" id="examObservations" rows="3" placeholder="Informações adicionais para o laboratório/técnico."></textarea>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-file-alt"></i> Gerar Pedido de Exame</button>
                    </div>

                    <div class="form-section mt-3">
                        <h4>Exames Pendentes/Realizados</h4>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>João Silva</strong> - Hemograma Completo (<small>Pedido em: 05/06/2025</small>)
                                </div>
                                <div>
                                    <span class="badge bg-warning text-dark me-2">Pendente</span>
                                    <button class="btn btn-sm btn-outline-info">Ver Pedido</button>
                                </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>Fernanda Lima</strong> - Raio-X de Tórax (<small>Realizado em: 01/06/2025</small>)
                                </div>
                                <div>
                                    <span class="badge bg-success">Concluído</span>
                                    <button class="btn btn-sm btn-outline-primary"><i class="fas fa-file-medical-alt"></i> Ver Resultado</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>

                <div id="reports" class="content-section" style="display: none;">
                    <h2><i class="fas fa-chart-pie"></i> Relatórios</h2>
                    <div class="form-section">
                        <h4>Relatórios Disponíveis</h4>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Relatório de Consultas por Período
                                <button class="btn btn-sm btn-outline-secondary">Gerar</button>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Relatório de Medicamentos Prescritos
                                <button class="btn btn-sm btn-outline-secondary">Gerar</button>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Relatório de Atendimentos por Faixa Etária
                                <button class="btn btn-sm btn-outline-secondary">Gerar</button>
                            </li>
                        </ul>
                        <div class="mt-3">
                            <label for="reportStartDate" class="form-label">Data Início</label>
                            <input type="date" class="form-control" id="reportStartDate">
                        </div>
                        <div class="mb-3">
                            <label for="reportEndDate" class="form-label">Data Fim</label>
                            <input type="date" class="form-control" id="reportEndDate">
                        </div>
                        <button class="btn btn-primary mt-2"><i class="fas fa-download"></i> Exportar Relatório Geral</button>
                    </div>
                </div>

                <div id="settings" class="content-section" style="display: none;">
                    <h2><i class="fas fa-cogs"></i> Configurações</h2>
                    <div class="form-section">
                        <h4>Minhas Informações</h4>
                        <div class="mb-3">
                            <label for="docName" class="form-label">Nome Completo</label>
                            <input type="text" class="form-control" id="docName" value="Dr. João da Silva" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="docCrm" class="form-label">CRM</label>
                            <input type="text" class="form-control" id="docCrm" value="123456-SP" disabled>
                        </div>
                        <button class="btn btn-secondary"><i class="fas fa-edit"></i> Editar Perfil</button>
                    </div>
                    <div class="form-section mt-3">
                        <h4>Configurações do Sistema</h4>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" id="darkModeSwitch">
                            <label class="form-check-label" for="darkModeSwitch">Modo Escuro</label>
                        </div>
                        <button class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Sair</button>
                    </div>
                </div>

            </div>
        </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="funpainelmed.js"></script>
    <script>
       
    </script>
</body>
</html>