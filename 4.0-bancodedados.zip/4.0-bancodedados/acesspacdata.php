<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Paciente - Aglix MedTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="stylemenupac.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3b82f6', // Azul principal para botões, links, etc.
                        secondary: '#8b5cf6', // Roxo secundário para detalhes, renovar
                        darkBg: '#1a202c', // Fundo escuro para o modo dark
                        darkCard: '#2d3748', // Cor de card no modo dark
                        darkText: '#e2e8f0', // Texto no modo dark
                        lightBg: '#f8f9fa', // Fundo claro
                        lightCard: '#ffffff', // Cor de card no modo claro
                        lightText: '#2d3748' // Texto no modo claro
                    },
                    fontFamily: {
                        sans: ['Arial', 'Helvetica', 'sans-serif'], // Fontes mais profissionais
                    },
                },
            },
            darkMode: 'class', // Habilita o modo escuro com a classe 'dark' no html
        };
    </script>
    <script src="https://kit.fontawesome.com/a2d9d5eada.js" crossorigin="anonymous"></script>
</head>

<body class="bg-lightBg dark:bg-darkBg text-lightText dark:text-darkText font-sans">

    <div class="flex flex-col md:flex-row min-h-screen">

        <aside class="w-full md:w-64 bg-lightCard dark:bg-darkCard shadow-lg flex flex-col p-4 md:p-6 sticky top-0 h-auto md:h-screen z-10">
            <div class="flex flex-col items-center border-b border-gray-200 dark:border-gray-700 pb-4 mb-4">
                <input type="file" id="profilePicInput" class="hidden" accept="image/*" onchange="changeProfilePic()">
                <img id="profilePic" src="https://via.placeholder.com/100" alt="Foto de Perfil" class="w-24 h-24 rounded-full object-cover border-2 border-primary shadow-md">
                <button onclick="document.getElementById('profilePicInput').click()" class="mt-2 text-sm text-primary hover:underline font-medium">
                    <i class="fas fa-camera mr-1"></i> Alterar Foto
                </button>
                <h2 class="text-xl font-bold mt-3">Teste Pessoa</h2>
                <p class="text-sm text-gray-600 dark:text-gray-400 text-center mt-1">
                    <span class="block">Idade: <span class="font-semibold">28</span> | Peso: <span class="font-semibold">75kg</span></span>
                    <span class="block">Altura: <span class="font-semibold">175cm</span> | Sangue: <span class="font-semibold">A+</span></span>
                </p>
                <p class="text-xs text-gray-500 dark:text-gray-500 mt-2">
                    <i class="fas fa-id-card mr-1"></i> CPF: 123.456.789-00
                </p>
            </div>

            <nav class="flex flex-col flex-grow space-y-2">
                <a href="#" id="nav-dashboard" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 active" onclick="showSection('dashboard', this)">
                    <i class="fas fa-chart-line text-lg"></i> Dashboard
                </a>
                <a href="agendamento.html" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" id="nav-agendar-consulta">
                    <i class="fas fa-calendar-plus text-lg"></i> Agendar Consulta
                </a>
                <a href="#" id="nav-meus-exames" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('meus-exames', this)">
                    <i class="fas fa-flask-vial text-lg"></i> Meus Exames
                </a>
                <a href="#" id="nav-minhas-receitas" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('minhas-receitas', this)">
                    <i class="fas fa-notes-medical text-lg"></i> Minhas Receitas
                </a>
                <a href="#" id="nav-medicamentos-uso" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('medicamentos-uso', this)">
                    <i class="fas fa-pills text-lg"></i> Medicamentos em Uso
                </a>
                <a href="#" id="nav-consultas-anteriores" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('consultas-anteriores', this)">
                    <i class="fas fa-history text-lg"></i> Consultas Anteriores
                </a>
                <a href="#" id="nav-notificacoes" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('notificacoes', this)">
                    <i class="fas fa-bell text-lg"></i> Notificações <span class="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full" id="notification-count">3</span>
                </a>
                <a href="#" id="nav-feedback" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('feedback', this)">
                    <i class="fas fa-comment-dots text-lg"></i> Enviar Feedback
                </a>
                <a href="#" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="alert('Funcionalidade de Chat/Suporte em breve!')">
                    <i class="fas fa-headset text-lg"></i> Chat/Suporte
                </a>
                <a href="#" id="nav-configuracoes" class="sidebar-item flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onclick="showSection('configuracoes', this)">
                    <i class="fas fa-cogs text-lg"></i> Configurações
                </a>
            </nav>

            <div class="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
                <button onclick="toggleDarkMode()" class="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 w-full text-left text-sm font-medium">
                    <i class="fas fa-adjust text-lg"></i> Modo Claro/Escuro
                </button>
                <a href="#" class="flex items-center gap-3 p-3 rounded-lg hover:bg-red-100 dark:hover:bg-red-800/50 text-red-600 dark:text-red-400 w-full text-left text-sm font-medium mt-2">
                    <i class="fas fa-sign-out-alt text-lg"></i> Sair
                </a>
            </div>
        </aside>

        <main class="flex-1 p-6 md:p-8 overflow-y-auto">
            <header class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
                <h1 class="text-3xl font-extrabold text-gray-800 dark:text-darkText">
                    Bem-vindo(a), <span class="text-primary">Teste Pessoa!</span>
                </h1>
                <div class="mt-4 sm:mt-0 flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <i class="fas fa-calendar-day mr-2"></i> Hoje: Sexta-feira, 14 de junho de 2025
                </div>
            </header>

            <section id="dashboard" class="content-section active bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-tachometer-alt mr-3 text-primary"></i> Visão Geral
                </h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="bg-primary/10 border-l-4 border-primary p-4 rounded-lg shadow-sm">
                        <h3 class="text-lg font-semibold text-primary mb-2 flex items-center"><i class="fas fa-calendar-check mr-2"></i> Próxima Consulta</h3>
                        <p class="text-gray-700 dark:text-gray-300">
                            <span class="font-medium">26 de julho de 2025 às 10:30</span><br>
                            Com <span class="font-medium">Dra. Roberta Silva</span> (Clínica Geral)
                        </p>
                        <a href="agendamento.html" class="mt-3 inline-block text-primary hover:underline text-sm font-semibold">
                            <i class="fas fa-external-link-alt mr-1"></i> Ver detalhes
                        </a>
                    </div>
                    <div class="bg-green-100 dark:bg-green-800/30 border-l-4 border-green-500 p-4 rounded-lg shadow-sm">
                        <h3 class="text-lg font-semibold text-green-700 dark:text-green-400 mb-2 flex items-center"><i class="fas fa-flask-vial mr-2"></i> Último Exame</h3>
                        <p class="text-gray-700 dark:text-gray-300">
                            <span class="font-medium">Hemograma Completo</span><br>
                            Realizado em: <span class="font-medium">20 de maio de 2025</span>
                        </p>
                        <button class="mt-3 inline-block text-green-700 dark:text-green-400 hover:underline text-sm font-semibold" onclick="openDetailsModal('exam', 'Hemograma Completo', '20 de maio de 2025', 'Normal. Sem alterações significativas. Valores dentro da faixa de referência.', 'Link para PDF do Hemograma')">
                            <i class="fas fa-file-alt mr-1"></i> Ver Detalhes
                        </button>
                    </div>
                    <div class="bg-purple-100 dark:bg-purple-800/30 border-l-4 border-purple-500 p-4 rounded-lg shadow-sm">
                        <h3 class="text-lg font-semibold text-purple-700 dark:text-purple-400 mb-2 flex items-center"><i class="fas fa-notes-medical mr-2"></i> Última Receita</h3>
                        <p class="text-gray-700 dark:text-gray-300">
                            <span class="font-medium">Paracetamol 500mg</span><br>
                            Prescrita em: <span class="font-medium">05 de junho de 2025</span>
                        </p>
                        <button class="mt-3 inline-block text-purple-700 dark:text-purple-400 hover:underline text-sm font-semibold" onclick="openDetailsModal('recipe', 'Paracetamol 500mg', '05 de junho de 2025', 'Tomar 1 comprimido a cada 6 horas, conforme a dor. Não exceder 4 comprimidos por dia. Usar por 5 dias.', 'Link para PDF do Paracetamol')">
                            <i class="fas fa-file-alt mr-1"></i> Ver Detalhes
                        </button>
                    </div>
                </div>
            </section>

            <section id="meus-exames" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-flask-vial mr-3 text-primary"></i> Meus Exames
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Histórico de Exames</h3>
                    <a href="agendamento.html" class="btn-primary-link text-primary hover:underline flex items-center gap-2 font-medium">
                        <i class="fas fa-calendar-plus"></i> Agendar Novo Exame
                    </a>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Tipo de Exame</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Data</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Hemograma Completo</td>
                                <td class="py-3 px-4">25/05/2025</td>
                                <td class="py-3 px-4"><span class="bg-yellow-100 text-yellow-800 dark:bg-yellow-800/30 dark:text-yellow-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Agendado</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-primary hover:underline text-sm" onclick="openDetailsModal('exam', 'Hemograma Completo', '25 de maio de 2025', 'Exame de rotina. Necessário jejum de 8h. Favor comparecer 15 minutos antes.', 'N/A')"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Raio-X de Tórax</td>
                                <td class="py-3 px-4">30/05/2025</td>
                                <td class="py-3 px-4"><span class="bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Concluído</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-green-700 dark:text-green-400 hover:underline text-sm" onclick="openDetailsModal('exam', 'Raio-X de Tórax', '30 de maio de 2025', 'Resultados normais. Pulmões limpos.', 'Link para PDF do Raio-X')"><i class="fas fa-download mr-1"></i> Baixar</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Ultrassonografia Abdominal</td>
                                <td class="py-3 px-4">10/06/2025</td>
                                <td class="py-3 px-4"><span class="bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Concluído</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-green-700 dark:text-green-400 hover:underline text-sm" onclick="openDetailsModal('exam', 'Ultrassonografia Abdominal', '10 de junho de 2025', 'Sem alterações significativas nos órgãos abdominais. Necessário jejum de 6h.', 'Link para PDF da Ultrassonografia')"><i class="fas fa-download mr-1"></i> Baixar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="minhas-receitas" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-notes-medical mr-3 text-primary"></i> Minhas Receitas
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Receitas Ativas</h3>
                    <button onclick="gerarNovaReceita()" class="btn-primary flex items-center gap-2">
                        <i class="fas fa-plus"></i> Solicitar Nova Receita
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-darkCard rounded-lg overflow-hidden shadow-sm">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Medicamento</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Data da Prescrição</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="listaReceitas">
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Carbonato de Lítio (300mg)</td>
                                <td class="py-3 px-4">10/01/2025</td>
                                <td class="py-3 px-4"><span class="bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Ativa</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Carbonato de Lítio (300mg)', '10 de janeiro de 2025', 'Tomar 1 cápsula via oral, 2 vezes ao dia (a cada 12h), após as refeições. Uso contínuo. Monitorar níveis séricos de lítio.', 'Link para PDF da Receita de Lítio')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                                </td>
                            </tr>
                            <tr class="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                                <td class="py-3 px-4">Metilfenidato (10mg)</td>
                                <td class="py-3 px-4">20/01/2025</td>
                                <td class="py-3 px-4"><span class="bg-red-100 text-red-800 dark:bg-red-800/30 dark:text-red-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Vencida</span></td>
                                <td class="py-3 px-4">
                                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Metilfenidato (10mg)', '20 de janeiro de 2025', 'Tomar 1 comprimido via oral, pela manhã. Não exceder a dose prescrita. Não tomar à noite. Receita controlada.', 'Link para PDF da Receita de Metilfenidato')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="medicamentos-uso" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-pills mr-3 text-primary"></i> Medicamentos em Uso
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-4">Esta seção lista todos os medicamentos que você está tomando atualmente.</p>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                        <h3 class="font-semibold text-lg text-blue-800 dark:text-blue-300">Amlodipino 5mg</h3>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            **Posologia:** 1 comprimido, 1x ao dia (manhã)<br>
                            **Início:** 01/01/2024<br>
                            **Indicação:** Controle de Pressão Arterial
                        </p>
                        <button class="mt-2 text-primary hover:underline text-sm"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                        <h3 class="font-semibold text-lg text-blue-800 dark:text-blue-300">Sinvastatina 20mg</h3>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            **Posologia:** 1 comprimido, 1x ao dia (noite)<br>
                            **Início:** 15/03/2023<br>
                            **Indicação:** Controle de Colesterol
                        </p>
                        <button class="mt-2 text-primary hover:underline text-sm"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
                        <h3 class="font-semibold text-lg text-blue-800 dark:text-blue-300">Vitamina D 2000 UI</h3>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            **Posologia:** 1 cápsula, 1x ao dia (manhã)<br>
                            **Início:** 01/06/2025<br>
                            **Indicação:** Suplementação
                        </p>
                        <button class="mt-2 text-primary hover:underline text-sm"><i class="fas fa-info-circle mr-1"></i> Detalhes</button>
                    </div>
                </div>
            </section>

            <section id="consultas-anteriores" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-history mr-3 text-primary"></i> Consultas Anteriores
                </h2>
                <ul class="divide-y divide-gray-200 dark:divide-gray-700">
                    <li class="py-4 flex items-start">
                        <div class="flex-shrink-0 text-gray-500 dark:text-gray-400 mr-4">
                            <i class="fas fa-calendar-alt text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-lg font-semibold mb-1">18 de agosto de 2024 - Urologista | Dr. Tanaba</p>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">
                                <span class="font-medium">Motivo:</span> Exame de rotina para check-up anual.<br>
                                <span class="font-medium">Diagnóstico:</span> Sem alterações significativas.
                            </p>
                            <button class="mt-2 text-primary hover:underline text-sm" onclick="openDetailsModal('consultation', 'Consulta com Dr. Tanaba (Urologista)', '18 de agosto de 2024', 'Motivo: Exame de rotina para check-up anual.\nDiagnóstico: Sem alterações significativas.\nRecomendações: Manter hábitos saudáveis.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Ver Prontuário</button>
                        </div>
                    </li>
                    <li class="py-4 flex items-start">
                        <div class="flex-shrink-0 text-gray-500 dark:text-gray-400 mr-4">
                            <i class="fas fa-calendar-alt text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-lg font-semibold mb-1">30 de janeiro de 2024 - Nefrologista | Dr. Andre</p>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">
                                <span class="font-medium">Motivo:</span> Acompanhamento de quadro de hipertensão.<br>
                                <span class="font-medium">Diagnóstico:</span> Pressão arterial controlada com medicação.
                            </p>
                            <button class="mt-2 text-primary hover:underline text-sm" onclick="openDetailsModal('consultation', 'Consulta com Dr. Andre (Nefrologista)', '30 de janeiro de 2024', 'Motivo: Acompanhamento de quadro de hipertensão.\nDiagnóstico: Pressão arterial controlada com medicação.\nRecomendações: Continuar com medicação e controle da dieta.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Ver Prontuário</button>
                        </div>
                    </li>
                    <li class="py-4 flex items-start">
                        <div class="flex-shrink-0 text-gray-500 dark:text-gray-400 mr-4">
                            <i class="fas fa-calendar-alt text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-lg font-semibold mb-1">15 de dezembro de 2023 - Clínico Geral | Dra. Juliana</p>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">
                                <span class="font-medium">Motivo:</span> Sintomas de gripe e tosse persistente.<br>
                                <span class="font-medium">Diagnóstico:</span> Gripe viral. Prescrito repouso e analgésicos.
                            </p>
                            <button class="mt-2 text-primary hover:underline text-sm" onclick="openDetailsModal('consultation', 'Consulta com Dra. Juliana (Clínico Geral)', '15 de dezembro de 2023', 'Motivo: Sintomas de gripe e tosse persistente.\nDiagnóstico: Gripe viral. Prescrito repouso e analgésicos.\nRecomendações: Hidratação e acompanhamento dos sintomas.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Ver Prontuário</button>
                        </div>
                    </li>
                </ul>
            </section>

            <section id="notificacoes" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-bell mr-3 text-primary"></i> Minhas Notificações
                </h2>
                <div id="notifications-list" class="space-y-4">
                    <div class="bg-blue-50 dark:bg-blue-800/20 p-4 rounded-lg border-l-4 border-blue-500 flex items-start">
                        <i class="fas fa-info-circle text-blue-600 dark:text-blue-400 mr-3 text-xl mt-1"></i>
                        <div>
                            <h3 class="font-semibold text-lg">Lembrete de Consulta</h3>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">Você tem uma consulta agendada com Dra. Roberta Silva em 26/07/2025 às 10:30.</p>
                            <button class="text-primary hover:underline text-xs mt-1" onclick="markNotificationAsRead(this.closest('.flex'))">Marcar como lida</button>
                        </div>
                    </div>
                    <div class="bg-green-50 dark:bg-green-800/20 p-4 rounded-lg border-l-4 border-green-500 flex items-start">
                        <i class="fas fa-check-circle text-green-600 dark:text-green-400 mr-3 text-xl mt-1"></i>
                        <div>
                            <h3 class="font-semibold text-lg">Resultado de Exame Disponível</h3>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">Seu resultado do Hemograma Completo de 20/05/2025 está disponível para visualização.</p>
                            <button class="text-primary hover:underline text-xs mt-1" onclick="markNotificationAsRead(this.closest('.flex'))">Marcar como lida</button>
                        </div>
                    </div>
                    <div class="bg-orange-50 dark:bg-orange-800/20 p-4 rounded-lg border-l-4 border-orange-500 flex items-start">
                        <i class="fas fa-exclamation-triangle text-orange-600 dark:text-orange-400 mr-3 text-xl mt-1"></i>
                        <div>
                            <h3 class="font-semibold text-lg">Receita Médica Vencida</h3>
                            <p class="text-gray-700 dark:text-gray-300 text-sm">Sua receita de Metilfenidato venceu. Por favor, solicite a renovação.</p>
                            <button class="text-primary hover:underline text-xs mt-1" onclick="markNotificationAsRead(this.closest('.flex'))">Marcar como lida</button>
                        </div>
                    </div>
                </div>
                <button class="btn-primary-outline mt-6" onclick="clearAllNotifications()">Limpar todas as notificações</button>
            </section>

            <section id="feedback" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-comment-dots mr-3 text-primary"></i> Enviar Feedback
                </h2>
                <p class="text-gray-700 dark:text-gray-300 mb-4">Sua opinião é muito importante para nós! Ajude-nos a melhorar nossos serviços.</p>
                <form onsubmit="submitFeedback(event)">
                    <div class="mb-4">
                        <label for="feedbackSubject" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Assunto</label>
                        <input type="text" id="feedbackSubject" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" placeholder="Ex: Sugestão para agendamento">
                    </div>
                    <div class="mb-4">
                        <label for="feedbackMessage" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Sua Mensagem</label>
                        <textarea id="feedbackMessage" rows="5" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" placeholder="Descreva sua sugestão, elogio ou problema..."></textarea>
                    </div>
                    <button type="submit" class="btn-primary"><i class="fas fa-paper-plane mr-2"></i> Enviar Feedback</button>
                </form>
            </section>

            <section id="configuracoes" class="content-section bg-lightCard dark:bg-darkCard p-6 rounded-xl shadow-lg mb-6">
                <h2 class="text-2xl font-bold mb-5 flex items-center text-gray-800 dark:text-darkText">
                    <i class="fas fa-cogs mr-3 text-primary"></i> Configurações da Conta
                </h2>
                <div class="space-y-6">
                    <div>
                        <h3 class="text-xl font-semibold mb-3">Informações Pessoais</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="nomeCompleto" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Nome Completo</label>
                                <input type="text" id="nomeCompleto" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-gray-50 dark:bg-gray-700 text-lightText dark:text-darkText p-2" value="Teste Pessoa" disabled>
                            </div>
                            <div>
                                <label for="cpfPaciente" class="block text-sm font-medium text-gray-700 dark:text-gray-400">CPF</label>
                                <input type="text" id="cpfPaciente" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-gray-50 dark:bg-gray-700 text-lightText dark:text-darkText p-2" value="123.456.789-00" disabled>
                            </div>
                            <div>
                                <label for="emailPaciente" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Email</label>
                                <input type="email" id="emailPaciente" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="teste.pessoa@email.com">
                            </div>
                            <div>
                                <label for="telefonePaciente" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Telefone</label>
                                <input type="text" id="telefonePaciente" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary focus:ring-primary bg-lightCard dark:bg-darkCard text-lightText dark:text-darkText p-2" value="(11) 98765-4321">
                            </div>
                        </div>
                        <button class="mt-6 btn-primary"><i class="fas fa-save mr-2"></i> Salvar Alterações</button>
                    </div>

                    <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
                        <h3 class="text-xl font-semibold mb-3">Preferências</h3>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-700 dark:text-gray-300">Receber notificações por e-mail</span>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" value="" class="sr-only peer" checked>
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                            </label>
                        </div>
                    </div>
                </div>
            </section>

        </main>
    </div>

    <div id="detailsModal" class="modal-overlay">
        <div class="modal-content">
            <button class="modal-close-button" onclick="closeDetailsModal()">&times;</button>
            <h3 id="modalTitle" class="text-2xl font-bold mb-4 text-gray-800 dark:text-darkText"></h3>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
                <span class="font-semibold">Data:</span> <span id="modalDate"></span>
            </p>
            <div class="mb-4">
                <p class="text-gray-700 dark:text-gray-300 font-semibold mb-1">Informações Detalhadas:</p>
                <p id="modalDescription" class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap"></p>
            </div>
            <a id="modalDownloadLink" href="#" target="_blank" class="btn-primary mt-4 hidden"><i class="fas fa-download mr-2"></i> Baixar PDF Completo</a>
            <p id="modalNoPdfMessage" class="text-sm text-gray-500 mt-2 hidden"><i class="fas fa-info-circle mr-1"></i> Não há um PDF disponível para este item.</p>
        </div>
    </div>

    <script>
        // Função para alternar a exibição das seções de conteúdo
        function showSection(sectionId, clickedElement) {
            // Remove 'active' de todas as seções e esconde-as
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            // Remove 'active' de todos os itens da sidebar
            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('active');
            });

            // Adiciona 'active' à seção clicada e a mostra
            document.getElementById(sectionId).classList.add('active');
            // Adiciona 'active' ao item da sidebar clicado
            clickedElement.classList.add('active');

            // Atualiza a contagem de notificações se a seção de notificações for ativada
            if (sectionId === 'notificacoes') {
                updateNotificationCount();
            }
        }

        // Troca de imagem de perfil
        function changeProfilePic() {
            const input = document.getElementById('profilePicInput');
            const img = document.getElementById('profilePic');
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
            }
        }

        // Toggle modo claro/escuro
        function toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
        }

        // Gerar nova receita (apenas adiciona um item simulado à lista)
        function gerarNovaReceita() {
            const lista = document.getElementById('listaReceitas');
            const newRow = document.createElement('tr');
            const today = new Date();
            const formattedDate = today.toLocaleDateString('pt-BR'); // Ex: 14/06/2025

            newRow.classList.add('border-b', 'border-gray-200', 'dark:border-gray-600', 'last:border-b-0');
            newRow.innerHTML = `
                <td class="py-3 px-4">Medicamento Genérico (X mg)</td>
                <td class="py-3 px-4">${formattedDate}</td>
                <td class="py-3 px-4"><span class="bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Ativa</span></td>
                <td class="py-3 px-4">
                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Medicamento Genérico (X mg)', '${formattedDate}', 'Esta é uma nova receita genérica para demonstração. Posologia: 1 comprimido ao dia. Uso por 30 dias.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                </td>
            `;
            lista.prepend(newRow); // Adiciona no início da lista
            alert('Sua solicitação de nova receita foi enviada e está aguardando análise médica. Você receberá uma notificação quando ela for aprovada.');
        }

        // Função para submeter feedback
        function submitFeedback(event) {
            event.preventDefault(); // Evita o recarregamento da página
            const subject = document.getElementById('feedbackSubject').value;
            const message = document.getElementById('feedbackMessage').value;

            if (subject.trim() === '' || message.trim() === '') {
                alert('Por favor, preencha o assunto e a mensagem do seu feedback.');
                return;
            }

            // Simulação de envio
            console.log('Feedback enviado:', { subject, message });
            alert('Obrigado pelo seu feedback! Recebemos sua mensagem e entraremos em contato se necessário.');

            // Limpa o formulário
            document.getElementById('feedbackSubject').value = '';
            document.getElementById('feedbackMessage').value = '';
        }

        // Funções para Notificações
        function updateNotificationCount() {
            const notificationItems = document.querySelectorAll('#notifications-list > div');
            let unreadCount = 0;
            notificationItems.forEach(item => {
                if (!item.classList.contains('bg-gray-100')) { // Simplificado: considera não lida se não for cinza
                    unreadCount++;
                }
            });
            const notificationBadge = document.getElementById('notification-count');
            if (unreadCount > 0) {
                notificationBadge.textContent = unreadCount;
                notificationBadge.classList.remove('hidden');
            } else {
                notificationBadge.classList.add('hidden');
            }
        }

        function markNotificationAsRead(element) {
            element.classList.remove('bg-blue-50', 'bg-green-50', 'bg-orange-50', 'dark:bg-blue-800/20', 'dark:bg-green-800/20', 'dark:bg-orange-800/20');
            element.classList.add('bg-gray-100', 'dark:bg-gray-700');
            element.querySelector('i').classList.add('text-gray-500'); // Mudar cor do ícone para cinza
            element.querySelector('button').remove(); // Remover botão "Marcar como lida"
            updateNotificationCount();
        }

        function clearAllNotifications() {
            const notificationsList = document.getElementById('notifications-list');
            notificationsList.innerHTML = '<p class="text-center text-gray-500 dark:text-gray-400">Nenhuma notificação.</p>';
            updateNotificationCount();
            alert('Todas as notificações foram limpas.');
        }

        // Funções do Modal de Detalhes
        function openDetailsModal(type, title, date, description, downloadLink) {
            const modal = document.getElementById('detailsModal');
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalDate').textContent = date;
            document.getElementById('modalDescription').textContent = description;

            const downloadBtn = document.getElementById('modalDownloadLink');
            const noPdfMsg = document.getElementById('modalNoPdfMessage');

            if (downloadLink && downloadLink !== 'N/A') {
                downloadBtn.href = downloadLink;
                downloadBtn.classList.remove('hidden');
                noPdfMsg.classList.add('hidden');
            } else {
                downloadBtn.classList.add('hidden');
                noPdfMsg.classList.remove('hidden');
            }

            modal.classList.add('show');
        }

        function closeDetailsModal() {
            document.getElementById('detailsModal').classList.remove('show');
        }

        // Fechar modal ao clicar fora ou pressionar ESC
        document.getElementById('detailsModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeDetailsModal();
            }
        });
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && document.getElementById('detailsModal').classList.contains('show')) {
                closeDetailsModal();
            }
        });


        // Inicializa a exibição do dashboard e a contagem de notificações ao carregar a página
        document.addEventListener('DOMContentLoaded', () => {
            showSection('dashboard', document.getElementById('nav-dashboard'));
            updateNotificationCount(); // Chamar ao carregar para exibir o número inicial
        });
    </script>
</body>
</html>