  document.addEventListener('DOMContentLoaded', function() {
    const sidebarLinks = document.querySelectorAll('#sidebar-wrapper .list-group-item');
    const contentSections = document.querySelectorAll('.content-section');

    // Function to show a specific content section
    function showSection(sectionId) {
        contentSections.forEach(section => {
            section.style.display = 'none';
        });
        document.getElementById(sectionId).style.display = 'block';

        sidebarLinks.forEach(link => {
            link.classList.remove('active');
        });
        document.getElementById('menu-' + sectionId).classList.add('active');
    }

    // Event listeners for sidebar navigation
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.id.replace('menu-', '');
            showSection(sectionId);
        });
    });

    // Timer functionality for "Nova Consulta"
    let timer;
    let seconds = 0;
    let isRunning = false;

    const timerDisplay = document.getElementById('timer');
    const startBtn = document.getElementById('startBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const resetBtn = document.getElementById('resetBtn');

    function formatTime(sec) {
        const h = String(Math.floor(sec / 3600)).padStart(2, '0');
        const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
        const s = String(sec % 60).padStart(2, '0');
        return `${h}:${m}:${s}`;
    }

    startBtn.addEventListener('click', () => {
        if (!isRunning) {
            isRunning = true;
            timer = setInterval(() => {
                seconds++;
                timerDisplay.textContent = formatTime(seconds);
            }, 1000);
            document.getElementById('consultationStatus').textContent = 'Em andamento';
        }
    });

    pauseBtn.addEventListener('click', () => {
        if (isRunning) {
            isRunning = false;
            clearInterval(timer);
            document.getElementById('consultationStatus').textContent = 'Pausada';
        }
    });

    resetBtn.addEventListener('click', () => {
        isRunning = false;
        clearInterval(timer);
        seconds = 0;
        timerDisplay.textContent = '00:00:00';
        document.getElementById('consultationStatus').textContent = 'Primeira consulta';
    });

    // Patient CPF update
    document.getElementById('patientCpfInput').addEventListener('input', function() {
        document.getElementById('patientCpf').textContent = this.value || 'CPF não informado';
    });

    // Simulate patient search for "Histórico Paciente"
    document.getElementById('searchPatientBtn').addEventListener('click', function() {
        const searchCpf = document.getElementById('searchPatientCpf').value.trim();
        const patientDetailsDiv = document.getElementById('patient-details');
        const noPatientFoundDiv = document.getElementById('no-patient-found');

        // Basic simulation: if CPF is '111.111.111-11', show patient details
        if (searchCpf === '111.111.111-11') {
            document.getElementById('displayPatientName').textContent = 'Fulano de Tal';
            document.getElementById('displayPatientCpf').textContent = '111.111.111-11';
            document.getElementById('displayPatientAge').textContent = '35 anos';
            document.getElementById('displayPatientGender').textContent = 'Masculino';
            patientDetailsDiv.style.display = 'block';
            noPatientFoundDiv.style.display = 'none';
            // In a real system, you would fetch and populate consultation history here
        } else {
            patientDetailsDiv.style.display = 'none';
            noPatientFoundDiv.style.display = 'block';
        }
    });

    // Initial view: show dashboard
    showSection('dashboard');

    // Simulate some dashboard data (in a real app, this would come from a backend)
    document.getElementById('consultasHoje').textContent = Math.floor(Math.random() * 10) + 3; // Random 3-12
    document.getElementById('tempoMedio').textContent = (Math.random() * 10 + 15).toFixed(0) + ' min'; // Random 15-25 min
    // Simulate next patient
    const patients = [{name: "Paula Rego", time: "14:30", reason: "Consulta de Rotina"}, {name: "Pedro Álvares", time: "15:00", reason: "Dor nas costas"}, {name: "Carla Nunes", time: "16:00", reason: "Retorno"}];
    const nextPatient = patients[Math.floor(Math.random() * patients.length)];
    document.getElementById('proximoPacienteNome').textContent = nextPatient.name;
    document.getElementById('proximoPacienteHorario').textContent = `Horário: ${nextPatient.time}`;
    document.getElementById('proximoPacienteMotivo').textContent = `Motivo: ${nextPatient.reason}`;

    // Placeholder for PDF generation (requires a library like jsPDF)
    document.getElementById('generatePdfBtn').addEventListener('click', () => {
        alert('A funcionalidade de gerar PDF requer uma biblioteca externa (ex: jsPDF) e lógica de implementação.');
        // Example of how you might use jsPDF (pseudo-code):
        // const { jsPDF } = window.jspdf;
        // const doc = new jsPDF();
        // doc.text("Receita Médica", 10, 10);
        // doc.text(`Paciente: ${document.getElementById('patientName').value}`, 10, 20);
        // doc.text(`Medicamentos: ${document.getElementById('prescribedMedications').value}`, 10, 30);
        // doc.save('receita_medica.pdf');
    });
});