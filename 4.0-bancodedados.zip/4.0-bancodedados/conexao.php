<?php
$host = 'localhost';
$dbname = 'agilixbd';
$username = 'root';
$password = 'usbw';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

    // Ativar erros PDO como exceções
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Alerta estilo "Windows"
    echo "<script>alert('Conexão PDO bem-sucedida!');</script>";
} catch (PDOException $e) {
    echo "<script>alert('Erro ao conectar via PDO: " . addslashes($e->getMessage()) . "');</script>";
}
?>
