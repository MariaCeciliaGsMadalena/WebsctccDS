
<?php
require('fpdf.php');

// Classe estendida do FPDF para cabeçalho e rodapé personalizados
class PDF extends FPDF
{
    // Cabeçalho
    function Header()
    {
        // Aglix MedTech no cabeçalho
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(44, 62, 80); // Cor mais escura para o texto
        $this->Cell(0, 10, 'Aglix MedTech', 0, 1, 'C'); // Título centralizado
        $this->Ln(5); // Linha em branco
    }

    // Rodapé
    function Footer()
    {
        // Posição a 1.5 cm do fim
        $this->SetY(-15);
        // Fonte Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Número da página
        $this->Cell(0, 10, 'Página ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        // Chave de autenticação (exemplo)
        $this->SetY(-10); // Um pouco mais acima para a chave
        $this->SetFont('Arial', '', 7);
        $this->SetTextColor(100, 100, 100); // Cor mais clara para a chave
        // Gerar uma chave de autenticação simples baseada na data/hora
        $authentication_key = hash('md5', uniqid(rand(), true));
        $this->Cell(0, 5, 'Chave de Autenticacao: ' . strtoupper($authentication_key), 0, 0, 'C');
    }

    // Função para adicionar moldura verde
    function AddGreenFrame() {
        $this->SetDrawColor(0, 150, 136); // Cor verde-água (RGB)
        $this->SetLineWidth(1); // Largura da linha
        $this->Rect(10, 10, $this->GetPageWidth() - 20, $this->GetPageHeight() - 20); // Retângulo com margem de 10mm
    }
}

// Criação do objeto PDF
$pdf = new PDF('P', 'mm', 'A4');
$pdf->AliasNbPages(); // Para contar o número total de páginas
$pdf->AddPage();
$pdf->AddGreenFrame(); // Adiciona a moldura verde
$pdf->SetMargins(20, 20, 20); // Define as margens (esquerda, topo, direita)

// --- Título do Atestado ---
$pdf->SetFont('Arial', 'B', 20);
$pdf->SetTextColor(0); // Preto
$pdf->Ln(20); // Espaço do cabeçalho
$pdf->Cell(0, 10, utf8_decode('ATESTADO MÉDICO'), 0, 1, 'C');
$pdf->SetDrawColor(0, 150, 136); // Cor da linha de sublinhado
$pdf->SetLineWidth(0.5);
$pdf->Line($pdf->GetX() + ($pdf->GetStringWidth(utf8_decode('ATESTADO MÉDICO')) / 2) + 60, $pdf->GetY(), $pdf->GetX() + ($pdf->GetStringWidth(utf8_decode('ATESTADO MÉDICO')) / 2) + 140, $pdf->GetY());
$pdf->Ln(15); // Espaço após o título


// --- Coleta de Dados do Formulário (Validação básica para fins de exemplo) ---
$nome_paciente = isset($_POST['attestPatientName']) ? htmlspecialchars($_POST['attestPatientName']) : '';
$numero_rg = isset($_POST['attestRg']) ? htmlspecialchars($_POST['attestRg']) : '';
$data_atendimento = isset($_POST['attestDate']) ? htmlspecialchars($_POST['attestDate']) : date('d/m/Y');
$periodo_afastamento = isset($_POST['attestDays']) ? (int)$_POST['attestDays'] : 1;
$motivo_afastamento = isset($_POST['attestReason']) ? htmlspecialchars($_POST['attestReason']) : '';
$informacoes_relevantes = isset($_POST['attestRelevantInfo']) ? htmlspecialchars($_POST['attestRelevantInfo']) : 'Nenhuma informação relevante adicionada.';
$local_emissao = isset($_POST['attestLocal']) ? htmlspecialchars($_POST['attestLocal']) : 'Franca-SP'; // Usando Franca-SP como padrão

// Formatação da data de afastamento
$data_inicio = new DateTime($data_atendimento);
$data_fim = clone $data_inicio;
$data_fim->modify("+$periodo_afastamento days");

$data_atendimento_formatada = (new DateTime($data_atendimento))->format('d/m/Y');
$data_inicio_afastamento = $data_atendimento_formatada; // Assume que o afastamento começa na data do atendimento
$data_fim_afastamento = $data_fim->format('d/m/Y');


// --- Conteúdo do Atestado ---
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(0); // Preto

$line_height = 8; // Altura da linha para parágrafos

$text = utf8_decode("Atesto para os devidos fins que o Sr.(a) ");
$pdf->Write($line_height, $text);
$pdf->SetFont('Arial', 'U', 12); // Sublinhado para o nome do paciente
$pdf->Write($line_height, $nome_paciente);
$pdf->SetFont('Arial', '', 12);
$text = utf8_decode(", portador(a) da Carteira de Identidade nº ");
$pdf->Write($line_height, $text);
$pdf->SetFont('Arial', 'U', 12); // Sublinhado para o RG
$pdf->Write($line_height, $numero_rg);
$pdf->SetFont('Arial', '', 12);
$text = utf8_decode(" esteve sob cuidados médicos no dia ");
$pdf->Write($line_height, $text);
$pdf->SetFont('Arial', 'U', 12); // Sublinhado para a data de atendimento
$pdf->Write($line_height, $data_atendimento_formatada);
$pdf->SetFont('Arial', '', 12);
$text = utf8_decode(" e deverá se afastar de suas atividades pelo período de ");
$pdf->Write($line_height, $text);
$pdf->SetFont('Arial', 'U', 12); // Sublinhado para o período
$pdf->Write($line_height, $periodo_afastamento . ' dia(s)');
$pdf->SetFont('Arial', '', 12);
$text = utf8_decode(" até ");
$pdf->Write($line_height, $text);
$pdf->SetFont('Arial', 'U', 12); // Sublinhado para a data final do afastamento
$pdf->Write($line_height, $data_fim_afastamento);
$pdf->SetFont('Arial', '', 12);
$text = utf8_decode(" por motivo de: ");
$pdf->Write($line_height, $text);
$pdf->SetFont('Arial', 'U', 12); // Sublinhado para o motivo
$pdf->MultiCell(0, $line_height, utf8_decode($motivo_afastamento), 0, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Ln(5);

// --- Informações Relevantes ---
$pdf->SetFillColor(240, 248, 255); // Azul claro para o fundo da caixa
$pdf->SetDrawColor(0, 150, 136); // Borda verde-água
$pdf->SetLineWidth(0.3);

$pdf->Cell(0, $line_height, utf8_decode('Informações relevantes'), 1, 1, 'C', true); // Título da caixa
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 6, utf8_decode($informacoes_relevantes), 1, 'L', false); // Conteúdo da caixa
$pdf->Ln(10);


// --- Local e Data ---
$pdf->SetFont('Arial', '', 12);
$pdf->SetX(20); // Reset X para a margem esquerda

$pdf->Cell(60, 10, utf8_decode('Local: '), 0, 0, 'L');
$pdf->SetFont('Arial', 'U', 12);
$pdf->Cell(50, 10, utf8_decode($local_emissao), 0, 0, 'L'); // Local
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(20, 10, utf8_decode('Data: '), 0, 0, 'R');
$pdf->SetFont('Arial', 'U', 12);
$pdf->Cell(0, 10, date('d/m/Y'), 0, 1, 'L'); // Data atual de emissão
$pdf->Ln(20);

// --- Carimbo e Assinatura ---
$pdf->SetX(20); // Reset X
$pdf->Cell(0, 5, utf8_decode('_______________________________________'), 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, utf8_decode('Carimbo e Assinatura do Médico'), 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, utf8_decode('Dr(a). [Nome do Médico]'), 0, 1, 'C'); // Substituir pelo nome real do médico
$pdf->Cell(0, 5, utf8_decode('CRM: [CRM do Médico]'), 0, 1, 'C'); // Substituir pelo CRM real do médico

// Saída do PDF
$pdf->Output('I', utf8_decode('Atestado_Médico_' . str_replace(' ', '_', $nome_paciente) . '.pdf'));

?>
?>