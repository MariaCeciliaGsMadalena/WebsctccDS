<?php
require('fpdf.php');

// Função para limpar e sanitizar os dados
function limpar($dado) {
    return htmlspecialchars(trim($dado));
}

// Classe para o PDF personalizado
class ComprovantePDF extends FPDF {
    private $primaryColor = [0, 92, 175]; // Azul similar a passagens aéreas
    private $secondaryColor = [241, 241, 241]; // Cinza claro
    
    function Header() {
        // Cabeçalho estilo passagem aérea
        $this->SetFillColor($this->primaryColor[0], $this->primaryColor[1], $this->primaryColor[2]);
        $this->SetTextColor(255);
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 15, 'COMPROVANTE DE AGENDAMENTO', 0, 1, 'C', true);
        
        // Linha de informações superiores
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(0);
        $this->Cell(95, 8, 'Emitido em: ' . date('d/m/Y H:i'), 0, 0);
        $this->Cell(95, 8, 'Consulta em: ' . date('d/m/Y', strtotime('+3 days')), 0, 1, 'R');
        $this->Ln(5);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Documento gerado automaticamente em ' . $this->PageNo(), 0, 0, 'C');
    }
    
    function addSectionTitle($title) {
        $this->SetFillColor($this->secondaryColor[0], $this->secondaryColor[1], $this->secondaryColor[2]);
        $this->SetTextColor($this->primaryColor[0], $this->primaryColor[1], $this->primaryColor[2]);
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, $title, 0, 1, 'L', true);
        $this->SetTextColor(0);
    }
    
    function addInfoRow($label, $value, $icon = '') {
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(40, 8, $icon . ' ' . $label, 0, 0);
        $this->SetFont('', '');
        $this->Cell(0, 8, $value, 0, 1);
    }
    
    function addBarcode($code) {
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor($this->primaryColor[0], $this->primaryColor[1], $this->primaryColor[2]);
        $this->Cell(0, 10, 'Codigo DO AGENDAMENTO', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 24);
        $this->Cell(0, 15, $code, 0, 1, 'C');
        
        // Simulação de código de barras (simples)
        $this->SetFillColor(0);
        for($i=0; $i<20; $i++) {
            $height = rand(5, 15);
            $this->Rect(50 + ($i*5), $this->GetY(), 3, $height, 'F');
        }
        $this->Ln(20);
    }
    
    function addSpecialties($especialidades) {
        $this->addSectionTitle('Medico');
        
        if(empty($especialidades)) {
            $this->SetFont('', 'I');
            $this->Cell(0, 8, 'Nenhuma especialidade selecionada', 0, 1);
            $this->SetFont('', '');
        } else {
            foreach($especialidades as $esp) {
                $this->Cell(5, 8, '', 0, 0);
                $this->Cell(0, 8, ' ' . $esp, 0, 1);
            }
        }
    }
}

// Verificar se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Coletar e limpar os dados
    $nome = limpar($_POST['nome'] ?? 'Não informado');
    $sobrenome = limpar($_POST['sobrenome'] ?? 'Não informado');
    $nome_completo = $nome . ' ' . $sobrenome;
    $idade = limpar($_POST['idade'] ?? 'Não informado');
    $motivo = limpar($_POST['motivo'] ?? 'Não informado');
    $cpf = limpar($_POST['cpf'] ?? 'Não informado');
    $urgencia = limpar($_POST['urgencia'] ?? 'Não informado');
    $especialidades = $_POST['especialidades'] ?? [];
    $chave = str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);

    // Criar PDF
    $pdf = new ComprovantePDF();
    $pdf->AddPage();

    // Seção de informações do paciente
    $pdf->addSectionTitle(' PACIENTE');
    $pdf->addInfoRow('Nome completo', $nome_completo, '');
    $pdf->addInfoRow('Idade', $idade . ' anos', '');
    $pdf->addInfoRow('CPF', $cpf, '');
    $pdf->addInfoRow('Motivo', $motivo, '');
    $pdf->addInfoRow('Nivel urgencia', $urgencia, '');

    // Seção de especialidades
    $pdf->addSpecialties($especialidades);

    // Código de confirmação
    $pdf->addBarcode($chave);

    // Notas importantes
    $pdf->addSectionTitle('INFORMAÇÕES IMPORTANTES');
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 6, " Apresente este comprovante no dia da consulta\n Chegue com 15 minutos de antecedência\n Em caso de desistência, favor cancelar com 24h de antecedência\nTrazer documentos originais e exames anteriores, se houver");
    $pdf->Ln(5);
    $pdf->SetFont('', 'I');
    $pdf->Cell(0, 6, 'Agradecemos sua preferência!', 0, 1, 'C');

    // Saída do PDF
    $pdf->Output('I', 'comprovante_agendamento_' . $chave . '.pdf');
} else {
    // Redirecionar se acessado diretamente
    header('Location: index.html');
    exit;
}
?>