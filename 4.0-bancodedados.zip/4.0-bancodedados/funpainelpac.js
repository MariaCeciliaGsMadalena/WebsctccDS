 // Função para alternar a exibição das seções de conteúdo
        function showSection(sectionId, clickedElement) {
            // Remove 'active' de todas as seções e esconde-as
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            // Remove 'active' de todos os itens da sidebar
            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('active');
            });

            // Adiciona 'active' à seção clicada e a mostra
            document.getElementById(sectionId).classList.add('active');
            // Adiciona 'active' ao item da sidebar clicado
            clickedElement.classList.add('active');

            // Atualiza a contagem de notificações se a seção de notificações for ativada
            if (sectionId === 'notificacoes') {
                updateNotificationCount();
            }
        }

        // Troca de imagem de perfil
        function changeProfilePic() {
            const input = document.getElementById('profilePicInput');
            const img = document.getElementById('profilePic');
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
            }
        }

        // Toggle modo claro/escuro
        function toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
        }

        // Gerar nova receita (apenas adiciona um item simulado à lista)
        function gerarNovaReceita() {
            const lista = document.getElementById('listaReceitas');
            const newRow = document.createElement('tr');
            const today = new Date();
            const formattedDate = today.toLocaleDateString('pt-BR'); // Ex: 14/06/2025

            newRow.classList.add('border-b', 'border-gray-200', 'dark:border-gray-600', 'last:border-b-0');
            newRow.innerHTML = `
                <td class="py-3 px-4">Medicamento Genérico (X mg)</td>
                <td class="py-3 px-4">${formattedDate}</td>
                <td class="py-3 px-4"><span class="bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Ativa</span></td>
                <td class="py-3 px-4">
                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Medicamento Genérico (X mg)', '${formattedDate}', 'Esta é uma nova receita genérica para demonstração. Posologia: 1 comprimido ao dia. Uso por 30 dias.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                </td>
            `;
            lista.prepend(newRow); // Adiciona no início da lista
            alert('Sua solicitação de nova receita foi enviada e está aguardando análise médica. Você receberá uma notificação quando ela for aprovada.');
        }

        // Função para submeter feedback
        function submitFeedback(event) {
            event.preventDefault(); // Evita o recarregamento da página
            const subject = document.getElementById('feedbackSubject').value;
            const message = document.getElementById('feedbackMessage').value;

            if (subject.trim() === '' || message.trim() === '') {
                alert('Por favor, preencha o assunto e a mensagem do seu feedback.');
                return;
            }

            // Simulação de envio
            console.log('Feedback enviado:', { subject, message });
            alert('Obrigado pelo seu feedback! Recebemos sua mensagem e entraremos em contato se necessário.');

            // Limpa o formulário
            document.getElementById('feedbackSubject').value = '';
            document.getElementById('feedbackMessage').value = '';
        }

        // Funções para Notificações
        function updateNotificationCount() {
            const notificationItems = document.querySelectorAll('#notifications-list > div');
            let unreadCount = 0;
            notificationItems.forEach(item => {
                if (!item.classList.contains('bg-gray-100')) { // Simplificado: considera não lida se não for cinza
                    unreadCount++;
                }
            });
            const notificationBadge = document.getElementById('notification-count');
            if (unreadCount > 0) {
                notificationBadge.textContent = unreadCount;
                notificationBadge.classList.remove('hidden');
            } else {
                notificationBadge.classList.add('hidden');
            }
        }

        function markNotificationAsRead(element) {
            element.classList.remove('bg-blue-50', 'bg-green-50', 'bg-orange-50', 'dark:bg-blue-800/20', 'dark:bg-green-800/20', 'dark:bg-orange-800/20');
            element.classList.add('bg-gray-100', 'dark:bg-gray-700');
            element.querySelector('i').classList.add('text-gray-500'); // Mudar cor do ícone para cinza
            element.querySelector('button').remove(); // Remover botão "Marcar como lida"
            updateNotificationCount();
        }

        function clearAllNotifications() {
            const notificationsList = document.getElementById('notifications-list');
            notificationsList.innerHTML = '<p class="text-center text-gray-500 dark:text-gray-400">Nenhuma notificação.</p>';
            updateNotificationCount();
            alert('Todas as notificações foram limpas.');
        }

        // Funções do Modal de Detalhes
        function openDetailsModal(type, title, date, description, downloadLink) {
            const modal = document.getElementById('detailsModal');
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalDate').textContent = date;
            document.getElementById('modalDescription').textContent = description;

            const downloadBtn = document.getElementById('modalDownloadLink');
            const noPdfMsg = document.getElementById('modalNoPdfMessage');

            if (downloadLink && downloadLink !== 'N/A') {
                downloadBtn.href = downloadLink;
                downloadBtn.classList.remove('hidden');
                noPdfMsg.classList.add('hidden');
            } else {
                downloadBtn.classList.add('hidden');
                noPdfMsg.classList.remove('hidden');
            }

            modal.classList.add('show');
        }

        function closeDetailsModal() {
            document.getElementById('detailsModal').classList.remove('show');
        }

        // Fechar modal ao clicar fora ou pressionar ESC
        document.getElementById('detailsModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeDetailsModal();
            }
        });
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && document.getElementById('detailsModal').classList.contains('show')) {
                closeDetailsModal();
            }
        });


        // Inicializa a exibição do dashboard e a contagem de notificações ao carregar a página
        document.addEventListener('DOMContentLoaded', () => {
            showSection('dashboard', document.getElementById('nav-dashboard'));
            updateNotificationCount(); // Chamar ao carregar para exibir o número inicial
        });