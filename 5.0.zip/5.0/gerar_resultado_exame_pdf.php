<?php
require 'fpdf.php'; // Inclui a biblioteca FPDF
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_resultados_biomedico'])) {
    $id_paciente = $_POST['id_paciente_biomedico'] ?? NULL;

    // Dados do Hemograma
    $hemacias = $_POST['hemacias'] ?? NULL;
    $hemoglobina = $_POST['hemoglobina'] ?? NULL;
    $hematocrito = $_POST['hematocrito'] ?? NULL;
    $vcm = $_POST['vcm'] ?? NULL;
    $hcm = $_POST['hcm'] ?? NULL;
    $chcm = $_POST['chcm'] ?? NULL;
    $rdw = $_POST['rdw'] ?? NULL;

    // Dados do Leucograma
    $leucocitos = $_POST['leucocitos'] ?? NULL;
    $bastonetes = $_POST['bastonetes'] ?? NULL;
    $segmentados = $_POST['segmentados'] ?? NULL;
    $eosinofilos = $_POST['eosinofilos'] ?? NULL;
    $monocitos = $_POST['monocitos'] ?? NULL;

    // Dados da Série Plaquetária
    $plaquetas = $_POST['plaquetas'] ?? NULL;
    $vmp = $_POST['vmp'] ?? NULL;

    // Outros Exames
    $fsh = $_POST['fsh'] ?? NULL;
    $t4_livre = $_POST['t4_livre'] ?? NULL;
    $glicemia = $_POST['glicemia'] ?? NULL;
    $prolactina = $_POST['prolactina'] ?? NULL;
    $estradiol = $_POST['estradiol'] ?? NULL;
    $ck_mb = $_POST['ck_mb'] ?? NULL;
    $ast = $_POST['ast'] ?? NULL;
    $urina = $_POST['urina'] ?? NULL;
    $diabetes_obs = $_POST['diabetes_obs'] ?? NULL;

    $observacoes_gerais_exame = $_POST['observacoes_gerais_exame'] ?? '';

    if ($id_paciente) {
        try {
            $conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4", DB_USERNAME, DB_PASSWORD);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Buscar dados do paciente
            $stmt_paciente = $conn->prepare("SELECT nome, cpf, data_nascimento, genero FROM pacientes WHERE id_paciente = :id_paciente");
            $stmt_paciente->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
            $stmt_paciente->execute();
            $paciente_data = $stmt_paciente->fetch(PDO::FETCH_ASSOC);

            if ($paciente_data) {
                // Inserir os resultados do exame no banco de dados (tabela 'exames')
                // Você pode ajustar o campo 'tipo_exame' para ser mais específico,
                // ou criar uma nova tabela para resultados detalhados.
                $tipo_exame_geral = "Hemograma Completo, FSH, T4 Livre e Outros";
                $resultado_json = json_encode([
                    'hemograma' => [
                        'hemacias' => $hemacias, 'hemoglobina' => $hemoglobina, 'hematocrito' => $hematocrito,
                        'vcm' => $vcm, 'hcm' => $hcm, 'chcm' => $chcm, 'rdw' => $rdw,
                        'leucocitos' => $leucocitos, 'bastonetes' => $bastonetes, 'segmentados' => $segmentados,
                        'eosinofilos' => $eosinofilos, 'monocitos' => $monocitos,
                        'plaquetas' => $plaquetas, 'vmp' => $vmp
                    ],
                    'outros' => [
                        'fsh' => $fsh, 't4_livre' => $t4_livre, 'glicemia' => $glicemia,
                        'prolactina' => $prolactina, 'estradiol' => $estradiol,
                        'ck_mb' => $ck_mb, 'ast' => $ast, 'urina' => $urina, 'diabetes_obs' => $diabetes_obs
                    ],
                    'observacoes_gerais' => $observacoes_gerais_exame
                ]);

                $stmt_insert_exam = $conn->prepare("INSERT INTO exames (id_paciente, tipo_exame, data_realizacao, data_resultado, resultado, status_exame, observacoes) VALUES (:id_paciente, :tipo_exame, CURDATE(), CURDATE(), :resultado, 'Concluído', :observacoes)");
                $stmt_insert_exam->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
                $stmt_insert_exam->bindParam(':tipo_exame', $tipo_exame_geral, PDO::PARAM_STR);
                $stmt_insert_exam->bindParam(':resultado', $resultado_json, PDO::PARAM_STR);
                $stmt_insert_exam->bindParam(':observacoes', $observacoes_gerais_exame, PDO::PARAM_STR);
                $stmt_insert_exam->execute();

                // --- Geração do PDF ---
                $pdf = new FPDF();
                $pdf->AddPage();
                $pdf->SetFont('Arial', 'B', 16);
                $pdf->Cell(0, 10, mb_convert_encoding('Relatório de Exames Laboratoriais', 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(0, 5, mb_convert_encoding('AgilixMedtech - Laboratório de Análises Clínicas', 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
                $pdf->Cell(0, 5, mb_convert_encoding('Data do Relatório: ' . date('d/m/Y H:i:s'), 'ISO-8859-1', 'UTF-8'), 0, 1, 'R');
                $pdf->Ln(10);

                // Informações do Paciente
                $pdf->SetFont('Arial', 'B', 12);
                $pdf->Cell(0, 7, mb_convert_encoding('Dados do Paciente:', 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(0, 6, mb_convert_encoding('Nome: ' . $paciente_data['nome'], 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $pdf->Cell(0, 6, mb_convert_encoding('CPF: ' . $paciente_data['cpf'], 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $data_nascimento = new DateTime($paciente_data['data_nascimento']);
                $hoje = new DateTime();
                $idade = $hoje->diff($data_nascimento)->y;
                $pdf->Cell(0, 6, mb_convert_encoding("Idade: {$idade} anos", 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $pdf->Cell(0, 6, mb_convert_encoding('Gênero: ' . $paciente_data['genero'], 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $pdf->Ln(10);

                // Hemograma Completo
                $pdf->SetFont('Arial', 'B', 12);
                $pdf->Cell(0, 7, mb_convert_encoding('HEMOGRAMA COMPLETO', 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->Cell(60, 7, mb_convert_encoding('Exame', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
                $pdf->Cell(40, 7, mb_convert_encoding('Resultado', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
                $pdf->Cell(50, 7, mb_convert_encoding('Valores de Referência', 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
                $pdf->SetFont('Arial', '', 9);

                $hemograma_results = [
                    ['Hemácias', $hemacias, '4.00-6.10 $10^6/\mu L$'],
                    ['Hemoglobina', $hemoglobina, '13.0-18.0 g/dL'],
                    ['Hematócrito', $hematocrito, '39.0-54.0 %'],
                    ['VCM', $vcm, '80.0-98.0 fL'],
                    ['HCM', $hcm, '27.0-32.0 pg'],
                    ['CHCM', $chcm, '30.0-36.0 g/dL'],
                    ['RDW', $rdw, '11.0-16.0 %'],
                    ['Leucócitos', $leucocitos, '4.000-11.000 $/mm^3$'],
                    ['Bastonetes', $bastonetes, '0-5 %'],
                    ['Segmentados', $segmentados, '40-70 %'],
                    ['Eosinófilos', $eosinofilos, '1-5 %'],
                    ['Monócitos', $monocitos, '3-10 %'],
                    ['Plaquetas', $plaquetas, '130-450 $10^3/\mu L$'],
                    ['VMP', $vmp, '6.8-12.6 fL']
                ];

                foreach ($hemograma_results as $item) {
                    $pdf->Cell(60, 6, mb_convert_encoding($item[0], 'ISO-8859-1', 'UTF-8'), 1, 0, 'L');
                    $pdf->Cell(40, 6, mb_convert_encoding($item[1] ?? 'N/A', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
                    $pdf->Cell(50, 6, mb_convert_encoding($item[2], 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
                }
                $pdf->Ln(10);

                // Outros Exames Específicos
                $pdf->SetFont('Arial', 'B', 12);
                $pdf->Cell(0, 7, mb_convert_encoding('OUTROS EXAMES', 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->Cell(60, 7, mb_convert_encoding('Exame', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
                $pdf->Cell(40, 7, mb_convert_encoding('Resultado', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
                $pdf->Cell(50, 7, mb_convert_encoding('Valores de Referência', 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
                $pdf->SetFont('Arial', '', 9);

                $other_exams_results = [
                    ['FSH', $fsh, 'Variável (mUI/mL)'],
                    ['T4 Livre', $t4_livre, '0.8-1.8 ng/dL'],
                    ['Glicemia', $glicemia, '70-99 mg/dL'],
                    ['Prolactina', $prolactina, 'Variável (ng/mL)'],
                    ['Estradiol', $estradiol, 'Variável (pg/mL)'],
                    ['CK-MB', $ck_mb, '< 25 ng/mL'],
                    ['AST', $ast, '< 35 U/L']
                ];

                foreach ($other_exams_results as $item) {
                    $pdf->Cell(60, 6, mb_convert_encoding($item[0], 'ISO-8859-1', 'UTF-8'), 1, 0, 'L');
                    $pdf->Cell(40, 6, mb_convert_encoding($item[1] ?? 'N/A', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
                    $pdf->Cell(50, 6, mb_convert_encoding($item[2], 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
                }
                $pdf->Ln(5);

                if (!empty($urina)) {
                    $pdf->SetFont('Arial', 'B', 10);
                    $pdf->Cell(60, 6, mb_convert_encoding('Exame de Urina', 'ISO-8859-1', 'UTF-8'), 1, 0, 'L');
                    $pdf->SetFont('Arial', '', 9);
                    $pdf->MultiCell(90, 6, mb_convert_encoding($urina, 'ISO-8859-1', 'UTF-8'), 1, 'L');
                    $pdf->Ln(0);
                }
                if (!empty($diabetes_obs)) {
                    $pdf->SetFont('Arial', 'B', 10);
                    $pdf->Cell(60, 6, mb_convert_encoding('Curva Glicêmica (Diabetes)', 'ISO-8859-1', 'UTF-8'), 1, 0, 'L');
                    $pdf->SetFont('Arial', '', 9);
                    $pdf->MultiCell(90, 6, mb_convert_encoding($diabetes_obs, 'ISO-8859-1', 'UTF-8'), 1, 'L');
                    $pdf->Ln(0);
                }
                $pdf->Ln(10);

                // Observações Gerais
                if (!empty($observacoes_gerais_exame)) {
                    $pdf->SetFont('Arial', 'B', 12);
                    $pdf->Cell(0, 7, mb_convert_encoding('Observações Gerais:', 'ISO-8859-1', 'UTF-8'), 0, 1, 'L');
                    $pdf->SetFont('Arial', '', 10);
                    $pdf->MultiCell(0, 6, mb_convert_encoding($observacoes_gerais_exame, 'ISO-8859-1', 'UTF-8'), 0, 'L');
                    $pdf->Ln(10);
                }

                // Rodapé com informações do laboratório e do biomédico (exemplo)
                $pdf->SetFont('Arial', '', 8);
                $pdf->Cell(0, 5, mb_convert_encoding('Liberado Eletronicamente por: [Nome do Biomédico], CRBM: [Número do CRBM]', 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
                $pdf->Cell(0, 5, mb_convert_encoding('Assinatura Digital: [Código de Autenticação]', 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
                $pdf->Cell(0, 5, mb_convert_encoding('Para a interpretação de laudos laboratoriais é necessário correlacionar com informações clínicas conhecidas apenas por seu médico assistente. AgilixMedtech.', 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
                $pdf->Output('I', mb_convert_encoding('Resultado_Exame_' . $paciente_data['nome'] . '.pdf', 'ISO-8859-1', 'UTF-8'));

            } else {
                echo "Paciente não encontrado.";
            }

        } catch (PDOException $e) {
            echo "Erro de banco de dados: " . $e->getMessage();
        } finally {
            $conn = null;
        }
    } else {
        echo "ID do paciente não fornecido.";
    }
} else {
    echo "Acesso inválido. Este script deve ser acessado via POST do formulário.";
}
?>
