<<?php
session_start();
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

// Mensagens de feedback para o usuário
$error_message = '';
$success_message = '';

// Verifica se há uma mensagem de sucesso de cadastro na sessão (após redirecionamento)
if (isset($_SESSION['registration_success'])) {
    $success_message = $_SESSION['registration_success'];
    unset($_SESSION['registration_success']); // Limpa a mensagem da sessão
}

/**
 * Autentica um usuário em uma tabela específica.
 *
 * @param PDO $conn Objeto de conexão PDO.
 * @param string $table Nome da tabela (ex: 'pacientes', 'medicos').
 * @param string $email Email do usuário.
 * @param string $senha Senha fornecida pelo usuário.
 * @param string|null $crm (Opcional) CRM do médico, se for o caso.
 * @return array|false Dados do usuário se a autenticação for bem-sucedida, caso contrário, false.
 */
function authenticateUser($conn, $table, $email, $senha, $crm = null) {
    $sql = "SELECT * FROM {$table} WHERE email = :email";
    $params = [':email' => $email];

    if ($table === 'medicos' && $crm !== null) {
        $sql .= " AND crm = :crm";
        $params[':crm'] = $crm;
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // ATENÇÃO: Para TCC, estamos removendo o hashing. Em produção, use password_verify($senha, $user['senha'])
    if ($user && $user['senha'] === $senha) { // Comparação direta da senha
        return $user;
    }
    return false;
}

// Processa requisições POST (login ou cadastro)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING) ?? '';

    try {
        $conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4", DB_USERNAME, DB_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($action === 'login') {
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $senha = $_POST['senha'] ?? ''; // Senha não sanitizada para comparação direta
            $tipo = filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_STRING) ?? '';

            $user = false;
            $redirect_page = '';
            $session_type = '';

            switch ($tipo) {
                case 'paciente':
                    $user = authenticateUser($conn, 'pacientes', $email, $senha);
                    $redirect_page = 'acesspacdata.php';
                    $session_type = 'paciente';
                    $error_message = 'Email ou senha de paciente incorretos.';
                    break;
                case 'medico':
                    // Para médico, o CRM pode ser um campo adicional de segurança ou apenas um detalhe.
                    // Se o CRM não for um campo de login, remova-o da chamada authenticateUser.
                    // Aqui, assumimos que o CRM não é usado para autenticação inicial, apenas email/senha.
                    $user = authenticateUser($conn, 'medicos', $email, $senha);
                    $redirect_page = 'acessmedicdata.php';
                    $session_type = 'medico';
                    $error_message = 'Email ou senha de médico incorretos.';
                    break;
                case 'acesso_exames':
                    // Assumimos que o acesso a exames é para pacientes
                    $user = authenticateUser($conn, 'pacientes', $email, $senha);
                    $redirect_page = 'acessexamdata.php'; // Redireciona para a página de exames
                    $session_type = 'acesso_exames';
                    $error_message = 'Email ou senha para acesso a exames incorretos.';
                    break;
                default:
                    $error_message = 'Tipo de login inválido.';
            }

            if ($user) {
                $_SESSION['user_id'] = $user["id_{$session_type}"]; // Ajusta para id_paciente ou id_medico
                $_SESSION['user_name'] = $user['nome'];
                $_SESSION['user_type'] = $session_type;

                if ($session_type === 'medico') {
                    $_SESSION['medico_logado'] = [
                        'id_medico' => $user['id_medico'],
                        'nome' => $user['nome'],
                        'especialidade' => $user['especialidade'],
                        'crm' => $user['crm']
                    ];
                }
                header('Location: ' . $redirect_page);
                exit;
            }

        } elseif ($action === 'register') {
            $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $senha = $_POST['senha'] ?? '';
            $confirm_senha = $_POST['confirm_senha'] ?? '';
            $cpf = filter_input(INPUT_POST, 'cpf', FILTER_SANITIZE_STRING);
            $data_nascimento = filter_input(INPUT_POST, 'data_nascimento', FILTER_SANITIZE_STRING);
            $genero = filter_input(INPUT_POST, 'genero', FILTER_SANITIZE_STRING);
            $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
            $cep = filter_input(INPUT_POST, 'cep', FILTER_SANITIZE_STRING);
            $logradouro = filter_input(INPUT_POST, 'logradouro', FILTER_SANITIZE_STRING);
            $numero = filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_STRING);
            $complemento = filter_input(INPUT_POST, 'complemento', FILTER_SANITIZE_STRING);
            $bairro = filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_STRING);
            $localidade = filter_input(INPUT_POST, 'localidade', FILTER_SANITIZE_STRING);
            $uf = filter_input(INPUT_POST, 'uf', FILTER_SANITIZE_STRING);
            $register_user_type = filter_input(INPUT_POST, 'register_user_type_radio', FILTER_SANITIZE_STRING) ?? '';
            $aceite_privacidade = isset($_POST['aceite_privacidade']);

            $especialidade = ($register_user_type === 'medico') ? filter_input(INPUT_POST, 'especialidade', FILTER_SANITIZE_STRING) : null;
            $crm = ($register_user_type === 'medico') ? filter_input(INPUT_POST, 'crm', FILTER_SANITIZE_STRING) : null;

            // Validação básica
            if (empty($nome) || empty($email) || empty($senha) || empty($confirm_senha) || empty($cpf) || empty($data_nascimento) || empty($genero) || empty($cep) || empty($logradouro) || empty($bairro) || empty($localidade) || empty($uf) || !$aceite_privacidade) {
                $error_message = 'Por favor, preencha todos os campos obrigatórios e aceite a política de privacidade.';
            } elseif ($senha !== $confirm_senha) {
                $error_message = 'As senhas não coincidem.';
            } else {
                // ATENÇÃO: Para TCC, estamos removendo o hashing. Em produção, use password_hash($senha, PASSWORD_DEFAULT);
                $raw_password = $senha; // Senha em texto puro
                $endereco_completo = "$logradouro, $numero" . ($complemento ? " - $complemento" : "") . ", $bairro, $localidade - $uf, CEP: $cep";

                // Verifica se email ou CPF/CRM já existem
                $email_exists_paciente = false;
                $cpf_exists_paciente = false;
                $email_exists_medico = false;
                $crm_exists_medico = false;

                $stmt_check = $conn->prepare("SELECT COUNT(*) FROM pacientes WHERE email = :email OR cpf = :cpf");
                $stmt_check->execute([':email' => $email, ':cpf' => $cpf]);
                if ($stmt_check->fetchColumn() > 0) {
                    $email_exists_paciente = true;
                    $cpf_exists_paciente = true; // Simplificado, pode ser mais granular
                }

                if ($register_user_type === 'medico') {
                    $stmt_check = $conn->prepare("SELECT COUNT(*) FROM medicos WHERE email = :email OR crm = :crm");
                    $stmt_check->execute([':email' => $email, ':crm' => $crm]);
                    if ($stmt_check->fetchColumn() > 0) {
                        $email_exists_medico = true;
                        $crm_exists_medico = true;
                    }
                }

                if ($email_exists_paciente || $email_exists_medico) {
                    $error_message = 'Este email já está cadastrado.';
                } elseif ($cpf_exists_paciente && $register_user_type === 'paciente') {
                    $error_message = 'Este CPF já está cadastrado como paciente.';
                } elseif ($crm_exists_medico && $register_user_type === 'medico') {
                    $error_message = 'Este CRM já está cadastrado como médico.';
                } elseif ($register_user_type === 'medico' && (empty($especialidade) || empty($crm))) {
                    $error_message = 'Por favor, preencha a especialidade e o CRM para cadastro de médico.';
                } else {
                    if ($register_user_type === 'paciente') {
                        $sql_insert = "INSERT INTO pacientes (nome, email, senha, cpf, data_nascimento, genero, telefone, endereco) VALUES (:nome, :email, :senha, :cpf, :data_nascimento, :genero, :telefone, :endereco)";
                        $stmt_insert = $conn->prepare($sql_insert);
                        $stmt_insert->execute([
                            ':nome' => $nome, ':email' => $email, ':senha' => $raw_password, ':cpf' => $cpf,
                            ':data_nascimento' => $data_nascimento, ':genero' => $genero, ':telefone' => $telefone, ':endereco' => $endereco_completo
                        ]);
                        $_SESSION['registration_success'] = 'Cadastro de paciente realizado com sucesso! Faça login.';
                    } elseif ($register_user_type === 'medico') {
                        $sql_insert = "INSERT INTO medicos (nome, email, crm, senha, especialidade, telefone, endereco, data_nascimento, genero, ativo) VALUES (:nome, :email, :crm, :senha, :especialidade, :telefone, :endereco, :data_nascimento, :genero, TRUE)";
                        $stmt_insert = $conn->prepare($sql_insert);
                        $stmt_insert->execute([
                            ':nome' => $nome, ':email' => $email, ':crm' => $crm, ':senha' => $raw_password,
                            ':especialidade' => $especialidade, ':telefone' => $telefone, ':endereco' => $endereco_completo,
                            ':data_nascimento' => $data_nascimento, ':genero' => $genero
                        ]);
                        $_SESSION['registration_success'] = 'Cadastro de médico realizado com sucesso! Faça login.';
                    }
                    header('Location: ' . $_SERVER['PHP_SELF'] . '?show_register_success=true');
                    exit;
                }
            }
        }
    } catch (PDOException $e) {
        $error_message = 'Erro de conexão com o banco de dados: ' . $e->getMessage();
        error_log("Erro no processamento POST: " . $e->getMessage());
    } finally {
        $conn = null; // Fecha a conexão
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login/Cadastro - SUS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Grand+Hotel&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Variáveis CSS para o tema */
        :root {
            /* Light Theme Variables */
            --bg-color: #f8f9fa;
            --text-color: #262626;
            --card-bg: #ffffff;
            --card-border: #dbdbdb;
            --input-bg: #fafafa;
            --input-border: #dbdbdb;
            --input-focus-border: #a8a8a8;
            --link-color: #007bff;
            --link-hover-color: #0056b3;
            --button-switch-bg: #e0f2f7;
            --button-switch-color: #007bff;
            --button-switch-hover-bg: #d1ecf1;
            --button-switch-hover-color: #0056b3;
            /* Error and Success colors are theme-agnostic */
            --error-color: #ed4956;
            --success-color: #28a745;
        }

        [data-theme="dark"] {
            /* Dark Theme Overrides */
            --bg-color: #121212;
            --text-color: #e0e0e0;
            --card-bg: #1e1e1e;
            --card-border: #333333;
            --input-bg: #2c2c2c;
            --input-border: #555555;
            --input-focus-border: #007bff;
            --link-color: #66b3ff;
            --link-hover-color: #3399ff;
            --button-switch-bg: #004085;
            --button-switch-color: #a8d8ff;
            --button-switch-hover-bg: #0056b3;
            --button-switch-hover-color: #ffffff;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-color); /* Use the dynamic variable */
            color: var(--text-color); /* Use the dynamic variable */
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .instagram-font {
            font-family: 'Grand Hotel', cursive;
        }
        .login-card {
            background-color: var(--card-bg);
            border: 1px solid var(--card-border);
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        input[type="email"],
        input[type="password"],
        input[type="text"],
        input[type="date"],
        input[type="number"],
        select,
        textarea {
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 3px;
            padding: 10px 12px;
            font-size: 14px;
            color: var(--text-color); /* Use dynamic text color */
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }
        input[type="email"]::placeholder,
        input[type="password"]::placeholder,
        input[type="text"]::placeholder,
        input[type="date"]::placeholder,
        input[type="number"]::placeholder,
        select::placeholder,
        textarea::placeholder {
            color: var(--text-color); /* Ajusta a cor do placeholder */
            opacity: 0.7; /* Torna o placeholder um pouco mais transparente */
        }
        input[type="email"]:focus,
        input[type="password"]:focus,
        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="number"]:focus,
        select:focus,
        textarea:focus {
            border-color: var(--input-focus-border);
            outline: none;
            box-shadow: none;
        }
        .login-button {
            background-color: var(--button-primary-bg);
            color: white;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background-color 0.2s ease;
        }
        .login-button:hover {
            background-color: var(--button-primary-hover-bg);
        }
        .login-button:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
        .error-message {
            color: var(--error-color);
            font-size: 12px;
            margin-top: 8px;
            text-align: center;
        }
        .success-message {
            color: var(--success-color);
            font-size: 14px;
            margin-top: 8px;
            text-align: center;
            font-weight: bold;
        }
        .switch-login-type-button {
            background-color: var(--button-switch-bg);
            color: var(--button-switch-color);
            padding: 8px 12px;
            border-radius: 6px;
            font-weight: 500;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .switch-login-type-button.active {
            background-color: var(--link-color); /* Usa a cor de link para o ativo */
            color: white;
        }
        .switch-login-type-button:hover:not(.active) {
            background-color: var(--button-switch-hover-bg);
            color: var(--button-switch-hover-color);
        }

        /* Spinner para ViaCEP */
        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, .3);
            border-radius: 50%;
            border-top-color: #007bff;
            animation: spin 1s ease-in-out infinite;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            display: none; /* Hidden by default */
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">

<div class="absolute top-4 right-4">
    <button id="theme-toggle" class="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
        <!-- Ícone do sol (modo claro) -->
        <svg id="sun-icon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h1M3 12h1m15.325-7.757l-.707.707M5.385 18.325l-.707.707m12.728 0l-.707-.707M6.092 5.385l-.707-.707"></path>
        </svg>
        <!-- Ícone da lua (modo escuro) -->
        <svg id="moon-icon" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path>
        </svg>
    </button>
</div>

<div class="flex flex-col items-center justify-center w-full max-w-4xl px-4">
    <!-- Main Login Card -->
    <div id="login-main-card" class="login-card p-8 rounded-lg shadow-sm w-full mb-4">
        <div class="text-center mb-6">
            <h1 class="instagram-font text-4xl" style="color: var(--text-color);">SUS</h1>
            <p class="text-lg font-semibold" style="color: var(--text-color);">Portal de Acesso à Saúde</p>
        </div>

        <!-- Error Message Display -->
        <?php if ($error_message): ?>
            <div class="error-message mb-4">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <div class="success-message mb-4">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <!-- Login Type Switcher -->
        <div class="flex justify-center mb-6 space-x-2">
            <button type="button" onclick="showLoginType('paciente')" class="switch-login-type-button active" id="btn-paciente">Paciente</button>
            <button type="button" onclick="showLoginType('medico')" class="switch-login-type-button" id="btn-medico">Médico</button>
            <button type="button" onclick="showLoginType('acesso_exames')" class="switch-login-type-button" id="btn-acesso-exames">Acesso Exames</button>
        </div>

        <!-- Patient Login Form -->
        <div id="paciente-login" class="login-form">
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="paciente">
                <input type="email" name="email" placeholder="Email do Paciente" required class="w-full">
                <input type="password" name="senha" placeholder="Senha" required class="w-full">
                <button type="submit" class="w-full login-button">Entrar como Paciente</button>
            </form>
        </div>

        <!-- Doctor Login Form -->
        <div id="medico-login" class="login-form hidden">
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="medico">
                <input type="email" name="email" placeholder="Email do Médico" required class="w-full">
                <input type="password" name="senha" placeholder="Senha" required class="w-full">
                <button type="submit" class="w-full login-button">Entrar como Médico</button>
            </form>
        </div>

        <!-- Exam Access Login Form -->
        <div id="acesso_exames-login" class="login-form hidden">
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="tipo" value="acesso_exames">
                <input type="email" name="email" placeholder="Email ou CPF para Exames" required class="w-full">
                <input type="password" name="senha" placeholder="Senha de Acesso" required class="w-full">
                <button type="submit" class="w-full login-button">Acessar Exames</button>
            </form>
        </div>

        <div class="text-center mt-4">
            <a href="#" class="text-blue-500 text-sm font-semibold hover:underline">Esqueceu a senha?</a>
        </div>
    </div>

    <!-- Sign Up Section (linked to Registration Form) -->
    <div id="signup-section-link" class="login-card p-4 rounded-lg shadow-sm w-full text-center text-sm">
        <p style="color: var(--text-color);">Não tem uma conta? <a href="#" onclick="showRegistrationForm(); return false;" class="text-blue-500 font-semibold hover:underline">Cadastre-se</a></p>
    </div>

    <!-- New Registration Section (Compact and Wide) -->
    <div id="cadastro-section" class="login-card p-3 rounded-lg shadow-lg w-full hidden mb-4 max-w-xl">
        <h2 class="text-center text-2xl font-semibold mb-6" style="color: var(--text-color);">Cadastro de Usuário</h2>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="space-y-1">
            <input type="hidden" name="action" value="register">
            <input type="hidden" name="tipo" id="register-user-type" value="paciente">

            <div>
                <label for="register-name" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Nome Completo</label>
                <input type="text" name="nome" id="register-name" placeholder="Seu Nome Completo" required class="w-full p-2 rounded text-sm">
            </div>
            <div>
                <label for="register-email" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Email</label>
                <input type="email" name="email" id="register-email" placeholder="seu.email@exemplo.com" required class="w-full p-2 rounded text-sm">
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label for="register-password" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Senha</label>
                    <input type="password" name="senha" id="register-password" placeholder="Sua Senha" required class="w-full p-2 rounded text-sm">
                </div>
                <div>
                    <label for="register-confirm-password" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Confirmar Senha</label>
                    <input type="password" name="confirm_senha" id="register-confirm-password" placeholder="Confirme sua Senha" required class="w-full p-2 rounded text-sm">
                </div>
            </div>
            <div>
                <label for="register-cpf" class="block text-sm font-medium mb-1" style="color: var(--text-color);">CPF</label>
                <input type="text" name="cpf" id="register-cpf" placeholder="000.000.000-00" required class="w-full p-2 rounded text-sm">
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label for="register-dob" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Data de Nascimento</label>
                    <input type="date" name="data_nascimento" id="register-dob" required class="w-full p-2 rounded text-sm">
                </div>
                <div>
                    <label for="register-gender" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Gênero</label>
                    <select name="genero" id="register-gender" class="w-full p-2 rounded text-sm">
                        <option value="">Selecione</option>
                        <option value="Masculino">Masculino</option>
                        <option value="Feminino">Feminino</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
            </div>
            <div>
                <label for="register-phone" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Telefone</label>
                <input type="text" name="telefone" id="register-phone" placeholder="(XX) XXXXX-XXXX" class="w-full p-2 rounded text-sm">
            </div>

            <!-- ViaCEP Integration Fields -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div class="relative">
                    <label for="register-cep" class="block text-sm font-medium mb-1" style="color: var(--text-color);">CEP</label>
                    <input type="text" name="cep" id="register-cep" placeholder="00000-000" required class="w-full p-2 rounded text-sm" onblur="consultarCep()">
                    <div id="cep-loading-spinner" class="loading-spinner"></div>
                </div>
                <div>
                    <label for="register-logradouro" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Logradouro</label>
                    <input type="text" name="logradouro" id="register-logradouro" placeholder="Rua, Avenida, etc." required class="w-full p-2 rounded text-sm">
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                    <label for="register-numero" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Número</label>
                    <input type="text" name="numero" id="register-numero" placeholder="Número" class="w-full p-2 rounded text-sm">
                </div>
                <div>
                    <label for="register-complemento" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Complemento</label>
                    <input type="text" name="complemento" id="register-complemento" placeholder="Apto, Bloco, etc." class="w-full p-2 rounded text-sm">
                </div>
                <div>
                    <label for="register-bairro" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Bairro</label>
                    <input type="text" name="bairro" id="register-bairro" placeholder="Bairro" required class="w-full p-2 rounded text-sm">
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label for="register-localidade" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Cidade</label>
                    <input type="text" name="localidade" id="register-localidade" placeholder="Cidade" required class="w-full p-2 rounded text-sm">
                </div>
                <div>
                    <label for="register-uf" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Estado (UF)</label>
                    <input type="text" name="uf" id="register-uf" placeholder="UF" maxlength="2" required class="w-full p-2 rounded text-sm">
                </div>
            </div>

            <!-- User Type Selection (Radio Buttons) -->
            <div class="mt-4">
                <span class="block text-sm font-medium mb-2" style="color: var(--text-color);">Tipo de Cadastro:</span>
                <div class="flex space-x-4">
                    <label class="inline-flex items-center">
                        <input type="radio" name="register_user_type_radio" value="paciente" checked class="form-radio text-blue-600" onchange="toggleDoctorFields()">
                        <span class="ml-2" style="color: var(--text-color);">Paciente</span>
                    </label>
                    <label class="inline-flex items-center">
                        <input type="radio" name="register_user_type_radio" value="medico" class="form-radio text-blue-600" onchange="toggleDoctorFields()">
                        <span class="ml-2" style="color: var(--text-color);">Médico</span>
                    </label>
                </div>
            </div>

            <!-- Doctor Specific Fields (Initially Hidden) -->
            <div id="doctor-fields" class="space-y-3 hidden">
                <div>
                    <label for="register-specialty" class="block text-sm font-medium mb-1" style="color: var(--text-color);">Especialidade</label>
                    <input type="text" name="especialidade" id="register-specialty" placeholder="Ex: Cardiologia" class="w-full p-2 rounded text-sm">
                </div>
                <div>
                    <label for="register-crm" class="block text-sm font-medium mb-1" style="color: var(--text-color);">CRM</label>
                    <input type="text" name="crm" id="register-crm" placeholder="000000-UF" class="w-full p-2 rounded text-sm">
                </div>
            </div>

            <!-- Privacy Policy -->
            <div class="mt-4 p-3" style="background-color: var(--input-bg); border-radius: 0.375rem;">
                <h3 class="font-bold mb-2" style="color: var(--text-color);">Política de Privacidade</h3>
                <p style="color: var(--text-color);">Ao se cadastrar, você concorda com a nossa política de privacidade. Seus dados serão utilizados apenas para fins de gerenciamento de saúde e não serão compartilhados com terceiros sem seu consentimento explícito. Para mais detalhes, consulte a <a href="#" style="color: var(--link-color);" class="hover:underline">Política de Privacidade Completa</a>.</p>
                <label class="inline-flex items-center mt-2">
                    <input type="checkbox" name="aceite_privacidade" required class="form-checkbox text-blue-600">
                    <span class="ml-2" style="color: var(--text-color);">Li e aceito a Política de Privacidade</span>
                </label>
            </div>

            <button type="submit" class="w-full login-button mt-6">Cadastrar</button>
        </form>
        <div class="text-center mt-4">
            Já tem uma conta? <a href="#" onclick="showLoginForms(); return false;" style="color: var(--link-color);" class="font-semibold hover:underline">Fazer Login</a>
        </div>
    </div>
</div>

<script>
    // Theme Toggle
    const themeToggleBtn = document.getElementById('theme-toggle');
    const sunIcon = document.getElementById('sun-icon');
    const moonIcon = document.getElementById('moon-icon');

    // Check saved theme in localStorage or default to light
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.setAttribute('data-theme', 'dark');
        sunIcon.classList.add('hidden');
        moonIcon.classList.remove('hidden');
    } else {
        document.documentElement.setAttribute('data-theme', 'light');
        sunIcon.classList.remove('hidden');
        moonIcon.classList.add('hidden');
    }

    themeToggleBtn.addEventListener('click', () => {
        if (document.documentElement.getAttribute('data-theme') === 'dark') {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
    });

    // Form Switching Logic
    function showLoginType(type) {
        const loginForms = document.querySelectorAll('.login-form');
        loginForms.forEach(form => form.classList.add('hidden'));

        const buttons = document.querySelectorAll('.switch-login-type-button');
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`${type}-login`).classList.remove('hidden');
        document.getElementById(`btn-${type}`).classList.add('active');
    }

    function showRegistrationForm() {
        document.getElementById('login-main-card').classList.add('hidden');
        document.getElementById('signup-section-link').classList.add('hidden');
        document.getElementById('cadastro-section').classList.remove('hidden');
    }

    function showLoginForms() {
        document.getElementById('login-main-card').classList.remove('hidden');
        document.getElementById('signup-section-link').classList.remove('hidden');
        document.getElementById('cadastro-section').classList.add('hidden');
    }

    function toggleDoctorFields() {
        const userTypeRadio = document.querySelector('input[name="register_user_type_radio"]:checked');
        const doctorFields = document.getElementById('doctor-fields');
        const registerUserTypeHidden = document.getElementById('register-user-type');

        if (userTypeRadio && userTypeRadio.value === 'medico') {
            doctorFields.classList.remove('hidden');
            registerUserTypeHidden.value = 'medico';
        } else {
            doctorFields.classList.add('hidden');
            registerUserTypeHidden.value = 'paciente';
        }
    }

    // ViaCEP Integration
    async function consultarCep() {
        const cepInput = document.getElementById('register-cep');
        const logradouroInput = document.getElementById('register-logradouro');
        const bairroInput = document.getElementById('register-bairro');
        const localidadeInput = document.getElementById('register-localidade');
        const ufInput = document.getElementById('register-uf');
        const spinner = document.getElementById('cep-loading-spinner');

        const cep = cepInput.value.replace(/\D/g, ''); // Remove non-digits

        if (cep.length !== 8) {
            logradouroInput.value = '';
            bairroInput.value = '';
            localidadeInput.value = '';
            ufInput.value = '';
            return;
        }

        spinner.style.display = 'inline-block'; // Show spinner

        try {
            const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await response.json();

            if (data.erro) {
                alert('CEP não encontrado.');
                logradouroInput.value = '';
                bairroInput.value = '';
                localidadeInput.value = '';
                ufInput.value = '';
            } else {
                logradouroInput.value = data.logradouro;
                bairroInput.value = data.bairro;
                localidadeInput.value = data.localidade;
                ufInput.value = data.uf;
            }
        } catch (error) {
            console.error('Erro ao consultar CEP:', error);
            alert('Erro ao consultar CEP. Tente novamente.');
            logradouroInput.value = '';
            bairroInput.value = '';
            localidadeInput.value = '';
            ufInput.value = '';
        } finally {
            spinner.style.display = 'none'; // Hide spinner
        }
    }

    // Initialize form display on page load
    document.addEventListener('DOMContentLoaded', () => {
        showLoginType('paciente'); // Default to patient login
        // If there's a success message from registration, show registration form
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('show_register_success') === 'true') {
            showRegistrationForm();
        }
    });
</script>
</body>
</html>
