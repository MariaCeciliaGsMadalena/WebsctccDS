   // Função para alternar a exibição das seções de conteúdo
        function showSection(sectionId, clickedElement) {
            // Remove 'active' de todas as seções e esconde-as
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
                section.style.display = 'none'; // Esconde a seção
            });
            // Remove 'active' de todos os itens da sidebar
            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('active');
            });

            // Adiciona 'active' à seção clicada e a mostra
            const targetSection = document.getElementById(sectionId);
            if (targetSection) {
                targetSection.classList.add('active');
                targetSection.style.display = 'block'; // Mostra a seção
            }
            // Adiciona 'active' ao item da sidebar clicado
            if (clickedElement) {
                clickedElement.classList.add('active');
            }

            // Atualiza a contagem de notificações se a seção de notificações for ativada
            if (sectionId === 'notificacoes') {
                updateNotificationCount();
            }
        }

        // Troca de imagem de perfil
        function changeProfilePic() {
            const input = document.getElementById('profilePicInput');
            const img = document.getElementById('profilePic');
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
            }
        }

        // Toggle modo claro/escuro
        function toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
        }

        // Gerar nova receita (apenas adiciona um item simulado à lista)
        function gerarNovaReceita() {
            const lista = document.getElementById('listaReceitas');
            const newRow = document.createElement('tr');
            const today = new Date();
            const formattedDate = today.toLocaleDateString('pt-BR'); // Ex: 14/06/2025

            newRow.classList.add('border-b', 'border-gray-200', 'dark:border-gray-600', 'last:border-b-0');
            newRow.innerHTML = `
                <td class="py-3 px-4">Medicamento Genérico (X mg)</td>
                <td class="py-3 px-4">${formattedDate}</td>
                <td class="py-3 px-4"><span class="bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-400 text-xs font-semibold px-2.5 py-0.5 rounded-full">Ativa</span></td>
                <td class="py-3 px-4">
                    <button class="text-secondary hover:underline text-sm"><i class="fas fa-redo-alt mr-1"></i> Renovar</button>
                    <button class="text-primary hover:underline text-sm ml-2" onclick="openDetailsModal('recipe', 'Medicamento Genérico (X mg)', '${formattedDate}', 'Esta é uma nova receita genérica para demonstração. Posologia: 1 comprimido ao dia. Uso por 30 dias.', 'N/A')"><i class="fas fa-file-alt mr-1"></i> Detalhes</button>
                </td>
            `;
            lista.prepend(newRow); // Adiciona no início da lista
            alert('Sua solicitação de nova receita foi enviada e está aguardando análise médica. Você receberá uma notificação quando ela for aprovada.');
        }

        // Função para submeter feedback
        function submitFeedback(event) {
            event.preventDefault(); // Evita o recarregamento da página
            const subject = document.getElementById('feedbackSubject').value;
            const message = document.getElementById('feedbackMessage').value;

            if (subject.trim() === '' || message.trim() === '') {
                alert('Por favor, preencha o assunto e a mensagem do seu feedback.');
                return;
            }

            // Simulação de envio
            console.log('Feedback enviado:', { subject, message });
            alert('Obrigado pelo seu feedback! Recebemos sua mensagem e entraremos em contato se necessário.');

            // Limpa o formulário
            document.getElementById('feedbackSubject').value = '';
            document.getElementById('feedbackMessage').value = '';
        }

        // Funções para Notificações
        function updateNotificationCount() {
            const notificationItems = document.querySelectorAll('#notifications-list > div');
            let unreadCount = 0;
            notificationItems.forEach(item => {
                if (!item.classList.contains('bg-gray-100')) { // Simplificado: considera não lida se não for cinza
                    unreadCount++;
                }
            });
            const notificationBadge = document.getElementById('notification-count');
            if (unreadCount > 0) {
                notificationBadge.textContent = unreadCount;
                notificationBadge.classList.remove('hidden');
            } else {
                notificationBadge.classList.add('hidden');
            }
        }

        function markNotificationAsRead(element) {
            element.classList.remove('bg-blue-50', 'bg-green-50', 'bg-orange-50', 'dark:bg-blue-800/20', 'dark:bg-green-800/20', 'dark:bg-orange-800/20');
            element.classList.add('bg-gray-100', 'dark:bg-gray-700');
            element.querySelector('i').classList.add('text-gray-500'); // Mudar cor do ícone para cinza
            element.querySelector('button').remove(); // Remover botão "Marcar como lida"
            updateNotificationCount();
        }

        function clearAllNotifications() {
            const notificationsList = document.getElementById('notifications-list');
            notificationsList.innerHTML = '<p class="text-center text-gray-500 dark:text-gray-400">Nenhuma notificação.</p>';
            updateNotificationCount();
            alert('Todas as notificações foram limpas.');
        }

        // Funções do Modal de Detalhes
        function openDetailsModal(type, title, date, description, downloadLink) {
            const modal = document.getElementById('detailsModal');
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalDate').textContent = date;
            document.getElementById('modalDescription').textContent = description;

            const downloadBtn = document.getElementById('modalDownloadLink');
            const noPdfMsg = document.getElementById('modalNoPdfMessage');

            if (downloadLink && downloadLink !== 'N/A') {
                downloadBtn.href = downloadLink;
                downloadBtn.classList.remove('hidden');
                noPdfMsg.classList.add('hidden');
            } else {
                downloadBtn.classList.add('hidden');
                noPdfMsg.classList.remove('hidden');
            }

            modal.classList.add('show');
        }

        function closeDetailsModal() {
            document.getElementById('detailsModal').classList.remove('show');
        }

        // Fechar modal ao clicar fora ou pressionar ESC
        document.getElementById('detailsModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeDetailsModal();
            }
        });
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && document.getElementById('detailsModal').classList.contains('show')) {
                closeDetailsModal();
            }
        });

        // --- Gemini AI Assistant Logic ---
        const chatMessagesDiv = document.getElementById('chat-messages');
        const chatInput = document.getElementById('ai-chat-input');
        const sendButton = document.getElementById('ai-chat-send-button');
        const loadingSpinner = document.getElementById('ai-loading-spinner');

        sendButton.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        async function sendMessage() {
            const userMessage = chatInput.value.trim();
            if (userMessage === '') return;

            // Add user message to chat
            appendMessage(userMessage, 'user');
            chatInput.value = '';
            loadingSpinner.classList.remove('hidden'); // Show spinner

            try {
                // Call Gemini API
                let chatHistory = [];
                chatHistory.push({ role: "user", parts: [{ text: userMessage }] });

                const payload = { contents: chatHistory };
                const apiKey = "AIzaSyCrcQKq0_MYs4OhIqNRt2kItaSi3PWfYWE"; 
                const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                const result = await response.json();
                if (result.candidates && result.candidates.length > 0 &&
                    result.candidates[0].content && result.candidates[0].content.parts &&
                    result.candidates[0].content.parts.length > 0) {
                    const aiResponse = result.candidates[0].content.parts[0].text;
                    appendMessage(aiResponse, 'ai');
                } else {
                    appendMessage('Desculpe, não consegui gerar uma resposta. Por favor, tente novamente.', 'ai');
                    console.error("Unexpected API response structure:", result);
                }
            } catch (error) {
                console.error("Error calling Gemini API:", error);
                appendMessage('Ocorreu um erro ao conectar com o assistente. Por favor, tente novamente mais tarde.', 'ai');
            } finally {
                loadingSpinner.classList.add('hidden'); // Hide spinner
                chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight; // Scroll to bottom
            }
        }

        function appendMessage(text, sender) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message-bubble');
            if (sender === 'user') {
                messageDiv.classList.add('message-user');
            } else {
                messageDiv.classList.add('message-ai');
            }
            messageDiv.textContent = text;
            chatMessagesDiv.appendChild(messageDiv);
            chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight; // Scroll to bottom
        }


        // Inicializa a exibição do dashboard e a contagem de notificações ao carregar a página
        document.addEventListener('DOMContentLoaded', () => {
            showSection('dashboard', document.getElementById('nav-dashboard'));
            updateNotificationCount(); // Chamar ao carregar para exibir o número inicial
        });