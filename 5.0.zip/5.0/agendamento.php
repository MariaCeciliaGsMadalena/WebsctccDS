<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Agendamento Médico</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
     
    }
    .slide {
      display: none;
    }
    .active {
      display: block;
    }
  </style>
  <script>
   function login() {
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    if (email && senha) {
      document.getElementById('login').classList.add('hidden');
      document.getElementById('agendamento').classList.remove('hidden');
    } else {
      alert('Preencha todos os campos!');
    }
  }

  function continuarSemLogin() {
    document.getElementById('login').classList.add('hidden');
    document.getElementById('agendamento').classList.remove('hidden');
  }

  function toggleDesc(id) {
    const desc = document.getElementById(id);
    const icon = document.getElementById(id.replace('Desc', 'Icon'));
    if (desc.classList.contains('hidden')) {
      desc.classList.remove('hidden');
      icon.classList.remove('bi-plus-lg');
      icon.classList.add('bi-dash-lg');
    } else {
      desc.classList.add('hidden');
      icon.classList.remove('bi-dash-lg');
      icon.classList.add('bi-plus-lg');
    }
  }
  </script>
</head>
<body class="font-sans text-gray-800">

  <!-- Login -->
  <section id="login" class="flex justify-center items-center min-h-screen">
    <div class="bg-white p-8 rounded-xl shadow-xl w-full max-w-md">
      <h2 class="text-3xl font-bold text-blue-700 text-center mb-8">Bem-vindo!</h2>
      <form onsubmit="event.preventDefault(); login();" class="space-y-6">
        <input
          id="email"
          type="email"
          placeholder="E-mail"
          class="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
        <input
          id="senha"
          type="password"
          placeholder="Senha"
          class="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
        <p
          class="text-center text-sm text-gray-600 mt-2 cursor-pointer hover:text-blue-700 select-none"
          onclick="continuarSemLogin()"
        >
          Continuar sem login
        </p>
        <button
          type="submit"
          class="w-full bg-blue-600 text-white font-semibold p-3 rounded-md hover:bg-blue-700 transition-colors duration-300"
        >
          Entrar
        </button>
      </form>
    </div>
  </section>
  
  <!-- Agendamento -->
  <section id="agendamento" class="hidden max-w-xl mx-auto p-4">
    <h2 class="text-xl font-semibold mb-4 text-center text-white"><i class="fas fa-calendar-check"></i> Agendamento Médico</h2>
    <form action="gerar_comprovante.php" method="POST" class="bg-white p-6 rounded-lg shadow-lg space-y-4">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Nome</label>
          <input name="nome" placeholder="Nome" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Sobrenome</label>
          <input name="sobrenome" placeholder="Sobrenome" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
        </div>
      </div>
      
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Idade</label>
          <input name="idade" type="number" placeholder="Idade" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">CPF</label>
          <input name="cpf" placeholder="CPF" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
        </div>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Motivo da Consulta</label>
        <input name="motivo" placeholder="Motivo da Consulta" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nível de Urgência</label>
        <select name="urgencia" class="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
          <option value="">Selecione</option>
          <option value="Baixa">Baixa</option>
          <option value="Média">Média</option>
          <option value="Alta">Alta</option>
          <option value="Emergência">Emergência</option>
        </select>
      </div>

      <div>
        <p class="mb-2 font-medium text-gray-700">Especialidades:</p>
        <div class="grid grid-cols-2 gap-4">
          
          <!-- Cardiologia -->
          <div class="bg-blue-50 p-4 rounded-lg border border-blue-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('cardioDesc')">
              <div class="flex items-center">
                <i class="bi bi-heart-pulse text-blue-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Cardiologia" class="mr-2 align-middle"> Cardiologia
                </label>
              </div>
              <i id="cardioIcon" class="bi bi-plus-lg text-blue-600 text-xl"></i>
            </div>
            <p id="cardioDesc" class="mt-2 text-blue-700 text-sm hidden">
              Cardiologia é a especialidade médica que cuida do diagnóstico e tratamento das doenças do coração e do sistema circulatório.
            </p>
          </div>
      
          <!-- Urologia -->
          <div class="bg-green-50 p-4 rounded-lg border border-green-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('uroDesc')">
              <div class="flex items-center">
                <i class="bi bi-gender-male text-green-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Urologia" class="mr-2 align-middle"> Urologia
                </label>
              </div>
              <i id="uroIcon" class="bi bi-plus-lg text-green-600 text-xl"></i>
            </div>
            <p id="uroDesc" class="mt-2 text-green-700 text-sm hidden">
              Urologia é a especialidade médica que trata do sistema urinário e do sistema reprodutor masculino.
            </p>
          </div>
      
          <!-- Dermatologia -->
          <div class="bg-red-50 p-4 rounded-lg border border-red-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('dermaDesc')">
              <div class="flex items-center">
                <i class="bi bi-patch-check text-red-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Dermatologia" class="mr-2 align-middle"> Dermatologia
                </label>
              </div>
              <i id="dermaIcon" class="bi bi-plus-lg text-red-600 text-xl"></i>
            </div>
            <p id="dermaDesc" class="mt-2 text-red-700 text-sm hidden">
              Dermatologia é o ramo da medicina que estuda, diagnostica e trata doenças da pele, cabelo e unhas.
            </p>
          </div>
      
          <!-- Oftalmologia -->
          <div class="bg-purple-50 p-4 rounded-lg border border-purple-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('oftalmoDesc')">
              <div class="flex items-center">
                <i class="bi bi-eye text-purple-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Oftalmologia" class="mr-2 align-middle"> Oftalmologia
                </label>
              </div>
              <i id="oftalmoIcon" class="bi bi-plus-lg text-purple-600 text-xl"></i>
            </div>
            <p id="oftalmoDesc" class="mt-2 text-purple-700 text-sm hidden">
              Oftalmologia trata das doenças e cuidados dos olhos, incluindo exames, cirurgias e correções visuais.
            </p>
          </div>
      
          <!-- Ortopedia -->
          <div class="bg-orange-50 p-4 rounded-lg border border-orange-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('ortopediaDesc')">
              <div class="flex items-center">
                <i class="bi bi-bandaid text-orange-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Ortopedia" class="mr-2 align-middle"> Ortopedia
                </label>
              </div>
              <i id="ortopediaIcon" class="bi bi-plus-lg text-orange-600 text-xl"></i>
            </div>
            <p id="ortopediaDesc" class="mt-2 text-orange-700 text-sm hidden">
              Ortopedia cuida das doenças e lesões do sistema musculoesquelético, como ossos, articulações e músculos.
            </p>
          </div>
      
          <!-- Ginecologia -->
          <div class="bg-pink-50 p-4 rounded-lg border border-pink-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('ginecoDesc')">
              <div class="flex items-center">
                <i class="bi bi-gender-female text-pink-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Ginecologia" class="mr-2 align-middle"> Ginecologia
                </label>
              </div>
              <i id="ginecoIcon" class="bi bi-plus-lg text-pink-600 text-xl"></i>
            </div>
            <p id="ginecoDesc" class="mt-2 text-pink-700 text-sm hidden">
              Ginecologia é a especialidade médica que cuida da saúde do sistema reprodutor feminino.
            </p>
          </div>
      
          <!-- Clínico Geral -->
          <div class="bg-teal-50 p-4 rounded-lg border border-teal-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('clinicoDesc')">
              <div class="flex items-center">
                <i class="bi bi-file-earmark-medical text-teal-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Clínico Geral" class="mr-2 align-middle"> Clínico Geral
                </label>
              </div>
              <i id="clinicoIcon" class="bi bi-plus-lg text-teal-600 text-xl"></i>
            </div>
            <p id="clinicoDesc" class="mt-2 text-teal-700 text-sm hidden">
              O clínico geral é o médico que faz o primeiro atendimento e encaminha para especialistas quando necessário.
            </p>
          </div>
      
          <!-- Endocrinologia -->
          <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
            <div class="flex items-center justify-between cursor-pointer" onclick="toggleDesc('endocrinoDesc')">
              <div class="flex items-center">
                <i class="bi bi-clipboard-pulse text-yellow-600 text-2xl mr-3"></i>
                <label class="text-base font-semibold cursor-pointer">
                  <input type="checkbox" name="especialidades[]" value="Endocrinologia" class="mr-2 align-middle"> Endocrinologia
                </label>
              </div>
              <i id="endocrinoIcon" class="bi bi-plus-lg text-yellow-600 text-xl"></i>
            </div>
            <p id="endocrinoDesc" class="mt-2 text-yellow-700 text-sm hidden">
              Endocrinologia trata dos hormônios e glândulas, como diabetes e distúrbios metabólicos.
            </p>
          </div>
        </div>
      </div>

      <button type="submit" class="w-full bg-blue-600 text-white p-3 rounded-md hover:bg-blue-700 transition-colors duration-300 flex items-center justify-center gap-2">
        <i class="fas fa-file-pdf"></i> Gerar Comprovante
      </button>
    </form>
  </section>

</body>
</html>