   // Script para alternar as seções de conteúdo
        document.addEventListener('DOMContentLoaded', function() {
            const menuLinks = document.querySelectorAll('#sidebar-wrapper .list-group-item');
            const contentSections = document.querySelectorAll('.content-section');

            function showSection(id) {
                contentSections.forEach(section => {
                    section.style.display = 'none';
                });
                document.getElementById(id).style.display = 'block';

                menuLinks.forEach(link => {
                    link.classList.remove('active');
                });
                const targetMenuLink = document.getElementById('menu-' + id);
                if (targetMenuLink) {
                    targetMenuLink.classList.add('active');
                }
            }

            menuLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const targetId = this.getAttribute('href').substring(1);
                    showSection(targetId);
                });
            });

            // Mostra o dashboard por padrão ao carregar a página
            showSection('dashboard');

            // --- Lógica do Timer (Nova Consulta) ---
            let timerInterval;
            let seconds = 0;
            const timerDisplay = document.getElementById('timer');
            const startBtn = document.getElementById('startBtn');
            const pauseBtn = document.getElementById('pauseBtn');
            const resetBtn = document.getElementById('resetBtn');
            const consultationStatus = document.getElementById('consultationStatus');

            function formatTime(sec) {
                const h = Math.floor(sec / 3600);
                const m = Math.floor((sec % 3600) / 60);
                const s = sec % 60;
                return [h, m, s]
                    .map(v => v < 10 ? "0" + v : v)
                    .join(":");
            }

            startBtn.addEventListener('click', () => {
                if (!timerInterval) {
                    timerInterval = setInterval(() => {
                        seconds++;
                        timerDisplay.textContent = formatTime(seconds);
                    }, 1000);
                    consultationStatus.textContent = 'Em andamento';
                }
            });

            pauseBtn.addEventListener('click', () => {
                clearInterval(timerInterval);
                timerInterval = null;
                consultationStatus.textContent = 'Pausada';
            });

            resetBtn.addEventListener('click', () => {
                clearInterval(timerInterval);
                timerInterval = null;
                seconds = 0;
                timerDisplay.textContent = "00:00:00";
                consultationStatus.textContent = 'Primeira consulta';
            });

            // --- Lógica de Geração de Atestado ---
            const attestForm = document.getElementById('attestForm');
            const atestadoGeradoDiv = document.getElementById('atestadoGerado');
            const atestadoContentPre = document.getElementById('atestadoContent');
            const symptomsInput = document.getElementById('symptomsInput');
            const suggestReasonBtn = document.getElementById('suggestReasonBtn');
            const attestReasonTextarea = document.getElementById('attestReason');
            const attestLoadingSpinner = document.getElementById('attestLoadingSpinner');

            // Dados do médico logado (passados do PHP para o JavaScript)
            const medicoNome = "<?php echo $nome_medico; ?>";
            const medicoCrm = "<?php echo $crm_medico; ?>";
            const medicoEspecialidade = "<?php echo $especialidade_medico; ?>";


            // Função para chamar a API Gemini e sugerir o motivo do atestado
            suggestReasonBtn.addEventListener('click', async () => {
                const symptoms = symptomsInput.value.trim();
                if (!symptoms) {
                    alert('Por favor, digite os sintomas ou a condição para obter uma sugestão.');
                    return;
                }

                attestLoadingSpinner.style.display = 'inline-block'; // Mostra o spinner
                suggestReasonBtn.disabled = true; // Desabilita o botão

                try {
                    let chatHistory = [];
                    const prompt = `Com base nos seguintes sintomas ou condição do paciente, sugira um motivo conciso para um atestado médico, incluindo um possível CID-10 se aplicável. Responda apenas com o motivo e o CID, sem saudações ou explicações adicionais.
                    Sintomas/Condição: ${symptoms}`;
                    chatHistory.push({ role: "user", parts: [{ text: prompt }] });

                    const payload = { contents: chatHistory };
                    const apiKey = ""; // A API Key será fornecida pelo ambiente Canvas
                    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

                    const response = await fetch(apiUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });

                    const result = await response.json();
                    if (result.candidates && result.candidates.length > 0 &&
                        result.candidates[0].content && result.candidates[0].content.parts &&
                        result.candidates[0].content.parts.length > 0) {
                        const suggestedReason = result.candidates[0].content.parts[0].text;
                        attestReasonTextarea.value = suggestedReason; // Preenche o textarea
                    } else {
                        console.error("Estrutura de resposta da API inesperada:", result);
                        alert("Não foi possível gerar uma sugestão. Tente novamente.");
                    }
                } catch (error) {
                    console.error("Erro ao chamar a API Gemini:", error);
                    alert("Ocorreu um erro ao tentar gerar a sugestão. Verifique sua conexão ou tente mais tarde.");
                } finally {
                    attestLoadingSpinner.style.display = 'none'; // Esconde o spinner
                    suggestReasonBtn.disabled = false; // Habilita o botão
                }
            });

            attestForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const patientName = document.getElementById('attestPatientName').value;
                const attestCpf = document.getElementById('attestCpf').value;
                const attestDate = document.getElementById('attestDate').value;
                const attestDays = document.getElementById('attestDays').value;
                const attestReason = document.getElementById('attestReason').value;
                const attestRelevantInfo = document.getElementById('attestRelevantInfo').value;
                const attestLocal = document.getElementById('attestLocal').value;

                const attestContent = `
Atestado Médico

Declaro para os devidos fins que o(a) paciente ${patientName}, portador(a) do CPF ${attestCpf}, foi atendido(a) por mim nesta data (${attestDate}).

Necessita de afastamento de suas atividades por ${attestDays} dia(s), a partir de ${attestDate}.

Motivo do Afastamento: ${attestReason}
${attestRelevantInfo ? `Informações Relevantes: ${attestRelevantInfo}` : ''}

${attestLocal}, ${new Date().toLocaleDateString('pt-BR')}.

${medicoNome}
CRM: ${medicoCrm}
Especialidade: ${medicoEspecialidade}
                `;
                atestadoContentPre.textContent = attestContent;
                atestadoGeradoDiv.classList.remove('d-none'); // Mostra a div do atestado gerado
            });

            function printAttest() {
                const content = document.getElementById('atestadoContent').textContent;
                const printWindow = window.open('', '', 'height=600,width=800');
                printWindow.document.write('<html><head><title>Atestado Médico</title>');
                printWindow.document.write('<style>body { font-family: "Inter", sans-serif; line-height: 1.6; margin: 20px; white-space: pre-wrap; }</style>');
                printWindow.document.write('</head><body>');
                printWindow.document.write('<pre>' + content + '</pre>');
                printWindow.document.close();
                printWindow.print();
            }
            window.printAttest = printAttest; // Torna a função global para ser acessível pelo onclick

            // --- Lógica dos Gráficos Chart.js ---
            // Dados fictícios para os gráficos
            const atendimentosData = {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul'],
                datasets: [{
                    label: 'Número de Atendimentos',
                    data: [180, 220, 190, 250, 210, 280, 260],
                    backgroundColor: 'rgba(0, 123, 255, 0.7)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1,
                    borderRadius: 5
                }]
            };

            const tempoMedioData = {
                labels: ['Consulta Geral', 'Exame Laboratorial', 'Pequeno Procedimento', 'Vacinação', 'Curativo'],
                datasets: [{
                    label: 'Tempo Médio (minutos)',
                    data: [25, 15, 40, 10, 20],
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.7)',
                        'rgba(255, 193, 7, 0.7)',
                        'rgba(220, 53, 69, 0.7)',
                        'rgba(23, 162, 184, 0.7)',
                        'rgba(108, 117, 125, 0.7)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(255, 193, 7, 1)',
                        'rgba(220, 53, 69, 1)',
                        'rgba(23, 162, 184, 1)',
                        'rgba(108, 117, 125, 1)'
                    ],
                    borderWidth: 1
                }]
            };

            // Renderização do gráfico de Atendimentos
            const atendimentosCtx = document.getElementById('atendimentosChart');
            if (atendimentosCtx) {
                new Chart(atendimentosCtx, {
                    type: 'bar',
                    data: atendimentosData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Número de Atendimentos'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Mês'
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: false
                            }
                        }
                    }
                });
            }


            // Renderização do gráfico de Tempo Médio
            const tempoMedioCtx = document.getElementById('tempoMedioChart');
            if (tempoMedioCtx) {
                new Chart(tempoMedioCtx, {
                    type: 'doughnut',
                    data: tempoMedioData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right',
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        let label = context.label || '';
                                        if (label) {
                                            label += ': ';
                                        }
                                        if (context.parsed !== null) {
                                            label += context.parsed + ' min';
                                        }
                                        return label;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            // --- Lógica do Chat de Notificações de Exames ---
            const chatInput = document.getElementById('chatInput');
            const sendChatBtn = document.getElementById('sendChatBtn');
            const examNotificationsChat = document.getElementById('exam-notifications-chat');

            sendChatBtn.addEventListener('click', function() {
                const messageText = chatInput.value.trim();
                if (messageText) {
                    const messageDiv = document.createElement('div');
                    messageDiv.classList.add('chat-message');
                    // Usando data e hora estáticas para o exemplo HTML puro
                    messageDiv.innerHTML = `<strong>Você:</strong> ${messageText} <small>${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR')}</small>`;
                    examNotificationsChat.appendChild(messageDiv);
                    chatInput.value = ''; // Limpa o input
                    examNotificationsChat.scrollTop = examNotificationsChat.scrollHeight; // Rola para o final
                }
            });

            // Permite enviar mensagem com Enter
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendChatBtn.click();
                }
            });

            // --- Lógica de Busca de Pacientes e Preenchimento Automático ---
            let currentSearchTimeout = null;
            let currentSearchController = null; // Para cancelar requisições anteriores

            async function searchPatients(query, sectionId) {
                const suggestionsBox = document.getElementById(`patient-name-suggestions-${sectionId}`);
                
                if (currentSearchTimeout) {
                    clearTimeout(currentSearchTimeout);
                }
                if (currentSearchController) {
                    currentSearchController.abort(); // Cancela a requisição anterior
                }

                if (query.length < 3) { // Começa a buscar após 3 caracteres
                    suggestionsBox.style.display = 'none';
                    suggestionsBox.innerHTML = '';
                    return;
                }

                currentSearchTimeout = setTimeout(async () => {
                    currentSearchController = new AbortController();
                    const signal = currentSearchController.signal;

                    try {
                        const response = await fetch(`acessmedicdata.php?action=search_patient&query=${encodeURIComponent(query)}`, { signal });
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        const patients = await response.json();

                        suggestionsBox.innerHTML = '';
                        if (patients.length > 0) {
                            patients.forEach(patient => {
                                const item = document.createElement('a');
                                item.href = '#';
                                item.classList.add('list-group-item', 'list-group-item-action');
                                item.textContent = `${patient.nome} (CPF: ${patient.cpf})`;
                                item.addEventListener('click', (e) => {
                                    e.preventDefault();
                                    if (sectionId === 'new-consultation') {
                                        fillNewConsultationForm(patient);
                                    } else if (sectionId === 'patient-history') {
                                        displayPatientHistory(patient);
                                    }
                                    suggestionsBox.style.display = 'none';
                                });
                                suggestionsBox.appendChild(item);
                            });
                            suggestionsBox.style.display = 'block';
                        } else {
                            suggestionsBox.style.display = 'none';
                        }
                    } catch (error) {
                        if (error.name === 'AbortError') {
                            console.log('Fetch aborted');
                        } else {
                            console.error('Erro ao buscar pacientes:', error);
                            suggestionsBox.style.display = 'none';
                        }
                    } finally {
                        currentSearchController = null;
                    }
                }, 300); // Atraso de 300ms para evitar muitas requisições
            }

            function fillNewConsultationForm(patient) {
                document.getElementById('patientName').value = patient.nome;
                document.getElementById('patientAge').value = patient.idade;
                document.getElementById('patientGender').value = patient.genero;
                document.getElementById('patientCpfInput').value = patient.cpf;
                document.getElementById('patientIdNewConsultation').value = patient.id_paciente; // Armazena o ID do paciente
                document.getElementById('patientCpf').textContent = patient.cpf; // Atualiza o CPF no status da consulta
            }

            async function displayPatientHistory(patient) {
                const displayPatientName = document.getElementById('displayPatientName');
                const displayPatientCpf = document.getElementById('displayPatientCpf');
                const displayPatientAge = document.getElementById('displayPatientAge');
                const displayPatientGender = document.getElementById('displayPatientGender');
                const patientDetailsSection = document.getElementById('patient-details');
                const consultationHistoryList = document.getElementById('consultation-history-list');
                const noPatientFoundAlert = document.getElementById('no-patient-found');

                displayPatientName.textContent = patient.nome;
                displayPatientCpf.textContent = patient.cpf;
                displayPatientAge.textContent = patient.idade;
                displayPatientGender.textContent = patient.genero;

                patientDetailsSection.style.display = 'block';
                noPatientFoundAlert.style.display = 'none';
                consultationHistoryList.innerHTML = '<li class="list-group-item text-center">Carregando histórico...</li>';

                try {
                    const response = await fetch(`acessmedicdata.php?action=get_patient_history&id_paciente=${patient.id_paciente}`);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const history = await response.json();

                    consultationHistoryList.innerHTML = ''; // Limpa antes de preencher
                    if (history.length > 0) {
                        history.forEach(record => {
                            const listItem = document.createElement('li');
                            listItem.classList.add('list-group-item');

                            let detailsHtml = '';
                            for (const key in record.details) {
                                if (record.details.hasOwnProperty(key) && record.details[key]) {
                                    detailsHtml += `<p><small><strong>${key}:</strong> ${record.details[key]}</small></p>`;
                                }
                            }

                            listItem.innerHTML = `
                                <strong>${new Date(record.date).toLocaleDateString('pt-BR')} - ${record.type}</strong>
                                ${detailsHtml}
                                <button class="btn btn-sm btn-outline-info mt-2">Ver Detalhes Completos</button>
                            `;
                            consultationHistoryList.appendChild(listItem);
                        });
                    } else {
                        consultationHistoryList.innerHTML = '<li class="list-group-item text-center">Nenhum histórico encontrado para este paciente.</li>';
                    }
                } catch (error) {
                    console.error('Erro ao buscar histórico do paciente:', error);
                    consultationHistoryList.innerHTML = '<li class="list-group-item text-danger text-center">Erro ao carregar histórico.</li>';
                }
            }

            // Event listener para o botão de busca de paciente no histórico (para acionar a busca manual)
            document.getElementById('searchPatientBtn').addEventListener('click', () => {
                const query = document.getElementById('searchPatientInput').value;
                if (query.length >= 3) {
                    // A busca automática já deve ter preenchido as sugestões.
                    // Para o botão, podemos simular um clique na primeira sugestão ou fazer uma busca direta.
                    // Para simplificar, vou apenas garantir que a busca automática já tenha sido feita.
                    // Se o usuário clicar no botão, ele espera um resultado imediato, não uma sugestão.
                    // Então, vamos buscar diretamente e tentar exibir o histórico do primeiro resultado.
                    fetch(`acessmedicdata.php?action=search_patient&query=${encodeURIComponent(query)}`)
                        .then(response => response.json())
                        .then(patients => {
                            if (patients.length > 0) {
                                displayPatientHistory(patients[0]); // Exibe o histórico do primeiro paciente encontrado
                            } else {
                                document.getElementById('no-patient-found').textContent = 'Nenhum paciente encontrado com o nome ou CPF informado.';
                                document.getElementById('no-patient-found').style.display = 'block';
                                document.getElementById('patient-details').style.display = 'none';
                                document.getElementById('consultation-history-list').innerHTML = '';
                            }
                        })
                        .catch(error => {
                            console.error('Erro ao buscar paciente manualmente:', error);
                            document.getElementById('no-patient-found').textContent = 'Erro ao buscar paciente. Tente novamente.';
                            document.getElementById('no-patient-found').style.display = 'block';
                            document.getElementById('patient-details').style.display = 'none';
                            document.getElementById('consultation-history-list').innerHTML = '';
                        });
                } else {
                    document.getElementById('no-patient-found').textContent = 'Por favor, digite pelo menos 3 caracteres para buscar.';
                    document.getElementById('no-patient-found').style.display = 'block';
                    document.getElementById('patient-details').style.display = 'none';
                    document.getElementById('consultation-history-list').innerHTML = '';
                }
            });
        });