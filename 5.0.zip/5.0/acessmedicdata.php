<?php
session_start(); // Inicia a sessão PHP
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

// Variáveis para armazenar os dados do médico
$nome_medico = 'Dr(a). [Nome do Médico]'; // Valor padrão
$especialidade_medico = 'Especialidade Não Definida'; // Valor padrão
$crm_medico = '000000-UF'; // Valor padrão
$id_medico_logado = null;

// Exemplo de como você buscaria os dados do médico do banco de dados após o login:
// Assume que o ID do médico está armazenado na sessão após o login
if (isset($_SESSION['medico_logado']['id_medico'])) {
    $id_medico_logado = $_SESSION['medico_logado']['id_medico'];

    try {
        // Cria uma nova conexão PDO
        // CORREÇÃO AQUI: Usando as constantes definidas em conexao.php para o DSN, usuário e senha.
        $conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4", DB_USERNAME, DB_PASSWORD);
        // Define o modo de erro para lançar exceções em caso de erro
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepara a instrução SQL para buscar os dados do médico
        $stmt = $conn->prepare("SELECT nome, especialidade, crm FROM medicos WHERE id_medico = :id_medico");
        // Faz o binding do parâmetro
        $stmt->bindParam(':id_medico', $id_medico_logado, PDO::PARAM_INT);
        // Executa a consulta
        $stmt->execute();
        // Obtém os dados do médico
        $medico_data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($medico_data) {
            $nome_medico = htmlspecialchars($medico_data['nome']);
            $especialidade_medico = htmlspecialchars($medico_data['especialidade']);
            $crm_medico = htmlspecialchars($medico_data['crm']);
        } else {
            // Se o médico não for encontrado, pode-se redirecionar ou exibir uma mensagem de erro
            error_log("Médico com ID " . $id_medico_logado . " não encontrado no banco de dados.");
            // Redirecionar para a página de login se o médico não for encontrado ou não estiver logado
            header('Location: login.php');
            exit;
        }

    } catch (PDOException $e) {
        // Captura e exibe erros de conexão ou de consulta ao banco de dados
        error_log("Erro ao buscar dados do médico: " . $e->getMessage());
        // Em produção, você não deve exibir o erro diretamente ao usuário
        // echo "<div class='alert alert-danger'>Erro ao carregar dados do médico.</div>";
        header('Location: login.php'); // Redireciona em caso de erro grave no DB
        exit;
    } finally {
        // Garante que a conexão com o banco de dados seja fechada
        $conn = null;
    }
} else {
    // Se não houver médico logado, redireciona para a página de login
    header('Location: login.php');
    exit;
}

// --- PHP para requisições AJAX ---
// Este bloco será executado apenas se for uma requisição AJAX específica
if (isset($_GET['action'])) {
    try {
        // Cria uma nova conexão PDO para requisições AJAX
        // CORREÇÃO AQUI: Usando as constantes definidas em conexao.php para o DSN, usuário e senha.
        $conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4", DB_USERNAME, DB_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($_GET['action'] === 'search_patient') {
            $query = $_GET['query'] ?? '';
            $patients = [];

            if (!empty($query)) {
                // Busca por nome ou CPF
                $sql = "SELECT id_paciente, nome, cpf, data_nascimento, genero, telefone, endereco FROM pacientes WHERE nome LIKE :query OR cpf LIKE :query_cpf LIMIT 10";
                $stmt = $conn->prepare($sql);
                $searchTerm = '%' . $query . '%';
                $stmt->bindParam(':query', $searchTerm, PDO::PARAM_STR);
                $stmt->bindParam(':query_cpf', $searchTerm, PDO::PARAM_STR);
                $stmt->execute();
                $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Calcula a idade
                foreach ($patients as &$patient) {
                    if (!empty($patient['data_nascimento'])) {
                        $birthDate = new DateTime($patient['data_nascimento']);
                        $today = new DateTime('today');
                        $age = $birthDate->diff($today)->y;
                        $patient['idade'] = $age;
                    } else {
                        $patient['idade'] = null;
                    }
                }
                unset($patient); // Quebra a referência do último elemento

            }
            header('Content-Type: application/json');
            echo json_encode($patients);
            exit;

        } elseif ($_GET['action'] === 'get_patient_history') {
            $id_paciente = $_GET['id_paciente'] ?? null;
            $history = [];

            if ($id_paciente) {
                // Buscar histórico de consultas (assumindo que a tabela 'consultas' existe)
                $sql_consultas = "SELECT data_consulta, motivo_consulta, diagnostico, medicamentos_prescritos, observacoes FROM consultas WHERE id_paciente = :id_paciente ORDER BY data_consulta DESC";
                $stmt_consultas = $conn->prepare($sql_consultas);
                $stmt_consultas->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
                $stmt_consultas->execute();
                $consultas = $stmt_consultas->fetchAll(PDO::FETCH_ASSOC);

                foreach ($consultas as $consulta) {
                    $history[] = [
                        'type' => 'Consulta',
                        'date' => $consulta['data_consulta'],
                        'details' => [
                            'Motivo' => $consulta['motivo_consulta'],
                            'Diagnóstico' => $consulta['diagnostico'],
                            'Medicamentos' => $consulta['medicamentos_prescritos'],
                            'Observações' => $consulta['observacoes']
                        ]
                    ];
                }

                // Buscar histórico de atestados
                $sql_atestados = "SELECT data_emissao, data_inicio_afastamento, dias_afastamento, diagnostico, cid, observacoes FROM atestados_medicos WHERE id_paciente = :id_paciente ORDER BY data_emissao DESC";
                $stmt_atestados = $conn->prepare($sql_atestados);
                $stmt_atestados->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
                $stmt_atestados->execute();
                $atestados = $stmt_atestados->fetchAll(PDO::FETCH_ASSOC);

                foreach ($atestados as $atestado) {
                    $history[] = [
                        'type' => 'Atestado',
                        'date' => $atestado['data_emissao'],
                        'details' => [
                            'Início Afastamento' => $atestado['data_inicio_afastamento'],
                            'Dias Afastamento' => $atestado['dias_afastamento'],
                            'Diagnóstico' => $atestado['diagnostico'],
                            'CID' => $atestado['cid'],
                            'Observações' => $atestado['observacoes']
                        ]
                    ];
                }

                // Buscar histórico de exames
                $sql_exames = "SELECT tipo_exame, data_solicitacao, data_realizacao, data_resultado, resultado, status_exame, observacoes FROM exames WHERE id_paciente = :id_paciente ORDER BY data_solicitacao DESC";
                $stmt_exames = $conn->prepare($sql_exames);
                $stmt_exames->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
                $stmt_exames->execute();
                $exames = $stmt_exames->fetchAll(PDO::FETCH_ASSOC);

                foreach ($exames as $exame) {
                    $history[] = [
                        'type' => 'Exame',
                        'date' => $exame['data_solicitacao'],
                        'details' => [
                            'Tipo' => $exame['tipo_exame'],
                            'Status' => $exame['status_exame'],
                            'Data Realização' => $exame['data_realizacao'] ?? 'N/A',
                            'Data Resultado' => $exame['data_resultado'] ?? 'N/A',
                            'Resultado' => $exame['resultado'] ?? 'N/A',
                            'Observações' => $exame['observacoes'] ?? 'N/A'
                        ]
                    ];
                }

                // Ordenar o histórico por data (mais recente primeiro)
                usort($history, function($a, $b) {
                    return strtotime($b['date']) - strtotime($a['date']);
                });
            }
            header('Content-Type: application/json');
            echo json_encode($history);
            exit;
        }

    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Erro de banco de dados: ' . $e->getMessage()]);
        error_log("Erro no AJAX: " . $e->getMessage());
        exit;
    } finally {
        $conn = null;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso Medico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="stylemenu.css"> <!-- Seu arquivo CSS para o menu lateral -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js para os gráficos -->

    <style>
        /* Estilos adicionais para o painel */
        body {
            background-color: #f8f9fa;
        }
        #wrapper {
            display: flex; /* Garante que os elementos internos se alinhem lado a lado */
        }
        #sidebar-wrapper {
            min-height: 100vh;
            margin-left: 0; /* Define a margem esquerda para 0 para que a sidebar seja sempre visível */
            background-color: #343a40; /* Fundo escuro para a sidebar */
            color: #fff;
            width: 15rem; /* Largura fixa da sidebar */
        }
        #sidebar-wrapper .sidebar-heading {
            padding: 1.5rem 1.25rem;
            font-size: 1.2rem;
            color: #fff;
            border-bottom: 1px solid rgba(255,255,255,.1);
        }
        #sidebar-wrapper .list-group {
            width: 15rem;
        }
        #sidebar-wrapper .list-group-item {
            color: #adb5bd;
            background-color: #343a40;
            border: none;
            padding: 0.75rem 1.25rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #sidebar-wrapper .list-group-item:hover {
            background-color: #495057;
            color: #fff;
        }
        #sidebar-wrapper .list-group-item.active {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
        }
        #page-content-wrapper {
            flex-grow: 1; /* Permite que o conteúdo principal ocupe o espaço restante */
        }
        .content-section {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,.075);
            margin-bottom: 20px;
        }
        .dashboard-cards .card {
            border-radius: 8px;
            border: none;
        }
        .form-section {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            border: 1px solid #e9ecef;
        }
        .timer-display {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .btn-group-timer button {
            margin: 5px;
        }
        .chat-box {
            height: 300px;
            overflow-y: auto;
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 15px;
            background-color: #e9ecef;
        }
        .chat-message {
            background-color: #d1e7dd; /* Verde claro para mensagens */
            padding: 8px 12px;
            border-radius: 15px;
            margin-bottom: 10px;
            max-width: 80%;
            word-wrap: break-word;
        }
        .chat-message.system {
            background-color: #cce5ff; /* Azul claro para mensagens do sistema */
        }
        .chat-message small {
            display: block;
            font-size: 0.75em;
            color: #6c757d;
            margin-top: 5px;
        }
        .loading-spinner {
            display: none; /* Escondido por padrão */
            margin-left: 10px;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, .3);
            border-radius: 50%;
            border-top-color: #007bff;
            animation: spin 1s ease-in-out infinite;
            -webkit-animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { -webkit-transform: rotate(360deg); }
        }
        @-webkit-keyframes spin {
            to { -webkit-transform: rotate(360deg); }
        }
    </style>
</head>
<body>

    <div id="wrapper">
        <div id="sidebar-wrapper">
            <div class="sidebar-heading">
                <i class="fas fa-user-md"></i> Médico <br>
                <small class="d-block mt-1"><?php echo $nome_medico; ?></small>
                <small class="d-block"><?php echo $especialidade_medico; ?></small>
                <small class="d-block">CRM: <?php echo $crm_medico; ?></small>
            </div>
            <div class="list-group list-group-flush">
                <a href="#dashboard" class="list-group-item list-group-item-action active" id="menu-dashboard"><i class="fas fa-chart-line"></i> Painel</a>
                <a href="#new-consultation" class="list-group-item list-group-item-action" id="menu-new-consultation"><i class="fas fa-stethoscope"></i> Nova Consulta</a>
                <a href="#patient-history" class="list-group-item list-group-item-action" id="menu-patient-history"><i class="fas fa-notes-medical"></i> Pontuarios</a>
                <a href="#appointments" class="list-group-item list-group-item-action" id="menu-appointments"><i class="fas fa-calendar-alt"></i> Agendamentos</a>
                <a href="#medical-certificates" class="list-group-item list-group-item-action" id="menu-medical-certificates"><i class="fas fa-file-medical"></i> Atestados</a>
                <a href="#exams" class="list-group-item list-group-item-action" id="menu-exams"><i class="fas fa-x-ray"></i> Exames</a>
                <a href="#reports" class="list-group-item list-group-item-action" id="menu-reports"><i class="fas fa-chart-pie"></i> Relatórios</a>
                <a href="#charts-stats" class="list-group-item list-group-item-action" id="menu-charts-stats"><i class="fas fa-chart-bar"></i> Gráficos e Estatísticas</a>
                <a href="login.php" class="list-group-item list-group-item-action text-danger"><i class="fas fa-sign-out-alt"></i> Sair</a>
            </div>
        </div>
        <div id="page-content-wrapper">
            <div class="container-fluid">

                <div id="dashboard" class="content-section">
                    <h2><i class="fas fa-chart-line"></i> Visão Geral do Dia</h2>
                    <div class="row dashboard-cards">
                        <div class="col-md-4">
                            <div class="card text-white bg-primary mb-3">
                                <div class="card-header">Consultas de Hoje</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="consultasHoje">5</h5> <!-- Exemplo de dado -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-white bg-success mb-3">
                                <div class="card-header">Tempo Médio das Últimas 10 Consultas</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="tempoMedio">18 min</h5> <!-- Exemplo de dado -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-dark bg-warning mb-3">
                                <div class="card-header">Próximo Paciente</div>
                                <div class="card-body">
                                    <h5 class="card-title" id="proximoPacienteNome">João Silva</h5>
                                    <p id="proximoPacienteHorario">Horário: 10:00</p>
                                    <p id="proximoPacienteMotivo">Motivo: Retorno de Exames</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-4">
                        <div class="card-header"><i class="fas fa-history"></i> Últimas Consultas (Recentes)</div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush" id="recent-consultations-list">
                                <!-- Conteúdo preenchido dinamicamente via JS/AJAX -->
                                <li class="list-group-item">
                                    <strong>Maria Souza</strong> (45 anos) - Motivo: Dor de cabeça - <small>10/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>Carlos Alberto</strong> (28 anos) - Motivo: Resfriado - <small>09/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                                <li class="list-group-item">
                                    <strong>Ana Paula</strong> (60 anos) - Motivo: Checape Anual - <small>08/06/2025</small>
                                    <button class="btn btn-sm btn-outline-info ms-2">Ver Detalhes</button>
                                </li>
                            </ul>
                            <button class="btn btn-sm btn-outline-primary mt-3">Ver Todas as Consultas</button>
                        </div>
                    </div>
                </div>

                <div id="new-consultation" class="content-section" style="display: none;">
                    <h2><i class="fas fa-stethoscope"></i> Iniciar Nova Consulta</h2>
                    <div class="form-section">
                        <h4 class="mb-3">Começar consulta</h4>
                        <div class="timer-display" id="timer">00:00:00</div>
                        <div class="mb-3 btn-group-timer">
                            <button class="btn btn-success" id="startBtn"><i class="fas fa-play"></i> Iniciar</button>
                            <button class="btn btn-warning" id="pauseBtn"><i class="fas fa-pause"></i> Pausar</button>
                            <button class="btn btn-danger" id="resetBtn"><i class="fas fa-redo"></i> Resetar</button>
                        </div>
                        <p><strong>Status:</strong> <span id="consultationStatus">Primeira consulta</span></p>
                        <p><strong>CPF do paciente:</strong> <span id="patientCpf">CPF não informado</span></p>
                    </div>

                    <div class="form-section">
                        <h4 class="mb-3">Dados do Paciente</h4>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="patientName" class="form-label">Nome do Paciente</label>
                                <input type="text" class="form-control" id="patientName" placeholder="Nome Completo do Paciente" oninput="searchPatients(this.value, 'new-consultation')">
                                <div id="patient-name-suggestions-new-consultation" class="list-group position-absolute w-50 z-1000" style="display: none;"></div>
                            </div>
                            <div class="col-md-3">
                                <label for="patientAge" class="form-label">Idade</label>
                                <input type="number" class="form-control" id="patientAge" min="0" readonly>
                            </div>
                            <div class="col-md-3">
                                <label for="patientGender" class="form-label">Sexo</label>
                                <select class="form-select" id="patientGender" disabled>
                                    <option selected>Selecione</option>
                                    <option value="Masculino">Masculino</option>
                                    <option value="Feminino">Feminino</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="patientCpfInput" class="form-label">CPF do Paciente</label>
                            <input type="text" class="form-control" id="patientCpfInput" placeholder="000.000.000-00" readonly>
                            <input type="hidden" id="patientIdNewConsultation">
                        </div>
                        <div class="mb-3">
                            <label for="patientReason" class="form-label">Motivo da Consulta</label>
                            <textarea class="form-control" id="patientReason" rows="3" placeholder="Sintomas, queixas, etc."></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="patientDiagnosis" class="form-label">Diagnóstico (CID-10)</label>
                            <textarea class="form-control" id="patientDiagnosis" rows="2" placeholder="Ex: R51 - Cefaleia"></textarea>
                        </div>
                    </div>

                    <div class="form-section">
                        <h4 class="mb-3">Receita Médica</h4>
                        <div class="mb-3">
                            <label for="prescribedMedications" class="form-label">Medicamentos Prescritos</label>
                            <textarea class="form-control" id="prescribedMedications" rows="5" placeholder="Ex: Paracetamol 500mg, 2x ao dia por 5 dias"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="observations" class="form-label">Observações</label>
                            <textarea class="form-control" id="observations" rows="3" placeholder="Instruções adicionais, repouso, etc."></textarea>
                        </div>
                        <button class="btn btn-primary" id="generatePdfBtn"><i class="fas fa-file-pdf"></i> Gerar Receita em PDF</button>
                    </div>

                    <div class="form-section text-center">
                        <button class="btn btn-success btn-lg"><i class="fas fa-save"></i> Finalizar e Salvar Consulta</button>
                    </div>
                </div>

                <div id="patient-history" class="content-section" style="display: none;">
                    <h2><i class="fas fa-notes-medical"></i> Histórico do Paciente</h2>
                    <div class="form-section">
                        <div class="mb-3">
                            <label for="searchPatientInput" class="form-label">Buscar Paciente por Nome ou CPF</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="searchPatientInput" placeholder="Digite o nome ou CPF do paciente" oninput="searchPatients(this.value, 'patient-history')">
                                <button class="btn btn-outline-primary" type="button" id="searchPatientBtn"><i class="fas fa-search"></i> Buscar</button>
                            </div>
                            <div id="patient-name-suggestions-patient-history" class="list-group position-absolute w-50 z-1000" style="display: none;"></div>
                        </div>
                        <div id="patient-details" style="display: none;">
                            <h4>Detalhes do Paciente: <span id="displayPatientName"></span> (<span id="displayPatientCpf"></span>)</h4>
                            <p><strong>Idade:</strong> <span id="displayPatientAge"></span></p>
                            <p><strong>Sexo:</strong> <span id="displayPatientGender"></span></p>
                            <h5>Histórico de Consultas e Registros</h5>
                            <ul class="list-group" id="consultation-history-list">
                                <!-- Conteúdo preenchido dinamicamente via JS/AJAX -->
                            </ul>
                        </div>
                        <div id="no-patient-found" class="alert alert-warning mt-3" style="display: none;">
                            Nenhum paciente encontrado com o nome ou CPF informado.
                        </div>
                    </div>
                </div>

                <div id="appointments" class="content-section" style="display: none;">
                    <h2><i class="fas fa-calendar-alt"></i> Agendamentos</h2>
                    <div class="form-section">
                        <h4>Agendamentos do Dia</h4>
                        <ul class="list-group mb-3">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>09:00</strong> - Ana Pereira (40 anos) - Consulta de Rotina
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success me-2"><i class="fas fa-check"></i> Atender</button>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i> Cancelar</button>
                                </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>10:30</strong> - Roberto Costa (55 anos) - Retorno de Exames
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success me-2"><i class="fas fa-check"></i> Atender</button>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i> Cancelar</button>
                                </div>
                            </li>
                        </ul>
                        <button class="btn btn-primary"><i class="fas fa-plus"></i> Novo Agendamento</button>
                    </div>
                    <div class="form-section mt-3">
                        <h4>Calendário de Agendamentos</h4>
                        <div class="alert alert-info">
                            Funcionalidade de calendário seria implementada aqui (requer biblioteca JS).
                        </div>
                    </div>
                </div>

                <div id="medical-certificates" class="content-section" style="display: none;">
                    <h2><i class="fas fa-file-medical"></i> Gerar Atestado Médico</h2>
                    <div class="form-section">
                        <form id="attestForm">
                            <div class="mb-3">
                                <label for="attestPatientName" class="form-label">Nome do Paciente</label>
                                <input type="text" class="form-control" id="attestPatientName" name="attestPatientName" placeholder="Nome Completo do Paciente" required>
                            </div>
                            <div class="mb-3">
                                <label for="attestCpf" class="form-label">CPF do Paciente</label>
                                <input type="text" class="form-control" id="attestCpf" name="attestCpf" placeholder="000.000.000-00" required>
                            </div>
                            <div class="mb-3">
                                <label for="attestDate" class="form-label">Data do Atendimento</label>
                                <input type="date" class="form-control" id="attestDate" name="attestDate" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="attestDays" class="form-label">Número de Dias de Afastamento</label>
                                <input type="number" class="form-control" id="attestDays" name="attestDays" min="1" value="1" required>
                            </div>
                            <div class="mb-3">
                                <label for="symptomsInput" class="form-label">Sintomas/Condição para Sugestão de Motivo</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="symptomsInput" placeholder="Ex: Febre, tosse, dor de garganta">
                                    <button class="btn btn-outline-primary" type="button" id="suggestReasonBtn">Sugestão de Motivo ✨</button>
                                    <div class="spinner-border text-primary loading-spinner" role="status" id="attestLoadingSpinner">
                                        <span class="visually-hidden">Carregando...</span>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="attestReason" class="form-label">Motivo do Afastamento (Diagnóstico/CID)</label>
                                <textarea class="form-control" id="attestReason" name="attestReason" rows="3" placeholder="Ex: Repouso devido a gripe (CID J11.1)." required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="attestRelevantInfo" class="form-label">Informações Relevantes (Opcional)</label>
                                <textarea class="form-control" id="attestRelevantInfo" name="attestRelevantInfo" rows="3" placeholder="Qualquer informação adicional para o atestado."></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="attestLocal" class="form-label">Local de Emissão</label>
                                <input type="text" class="form-control" id="attestLocal" name="attestLocal" value="Franca-SP" placeholder="Cidade-UF">
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-file-pdf"></i> Gerar Atestado</button>
                        </form>
                        <div id="atestadoGerado" class="card p-4 mt-4 d-none">
                            <h5>Pré-visualização do Atestado:</h5>
                            <pre id="atestadoContent" class="bg-light p-3 rounded"></pre>
                            <button class="btn btn-secondary mt-3" onclick="printAttest()">Imprimir Atestado</button>
                        </div>
                    </div>
                </div>

                <div id="exams" class="content-section" style="display: none;">
                    <h2><i class="fas fa-x-ray"></i> Gerenciamento de Exames</h2>
                    <div class="row">
                        <div class="col-md-7">
                            <div class="form-section">
                                <h4>Enviar Resultados para o Médico</h4>
                                <form action="processa_envio.php" method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="nome_medico_envio" class="form-label">Nome do Médico</label>
                                        <input type="text" class="form-control" id="nome_medico_envio" placeholder="Nome Completo do Médico" name="nome_medico" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="email_medico_envio" class="form-label">Email do Médico</label>
                                        <input type="email" class="form-control" id="email_medico_envio" placeholder="email@exemplo.com" name="email_medico" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="crm_medico_envio" class="form-label">CRM do Médico</label>
                                        <input type="text" class="form-control" id="crm_medico_envio" placeholder="000000-UF" name="crm_medico">
                                    </div>
                                    <div class="mb-3">
                                        <label for="tipo_resultado_envio" class="form-label">Tipo de Resultado</label>
                                        <select class="form-select" id="tipo_resultado_envio" name="tipo_resultado" required>
                                            <option selected disabled value="">Selecione o Tipo</option>
                                            <option value="exame_laboratorial">Exame Laboratorial</option>
                                            <option value="imagem_diagnostica">Imagem Diagnóstica</option>
                                            <option value="relatorio_medico">Relatório Médico</option>
                                            <option value="outros">Outros</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="arquivo_resultado" class="form-label">Anexar Arquivo do Resultado</label>
                                        <input type="file" class="form-control" id="arquivo_resultado" name="arquivo_resultado" required>
                                    </div>
                                    <button type="submit" class="btn btn-success"><i class="fas fa-upload"></i> Enviar Resultado</button>
                                </form>
                            </div>

                            <div class="form-section mt-4">
                                <h4>Solicitar Novo Exame</h4>
                                <div class="mb-3">
                                    <label for="examPatientName" class="form-label">Nome do Paciente</label>
                                    <input type="text" class="form-control" id="examPatientName" placeholder="Nome Completo do Paciente">
                                </div>
                                <div class="mb-3">
                                    <label for="examType" class="form-label">Tipo de Exame</label>
                                    <input type="text" class="form-control" id="examType" placeholder="Ex: Hemograma Completo, Raio-X de Tórax">
                                </div>
                                <div class="mb-3">
                                    <label for="examObservations" class="form-label">Observações para o Exame</label>
                                    <textarea class="form-control" id="examObservations" rows="3" placeholder="Informações adicionais para o laboratório/técnico."></textarea>
                                </div>
                                <button class="btn btn-primary"><i class="fas fa-file-alt"></i> Gerar Pedido de Exame</button>
                            </div>
                        </div>

                        <div class="col-md-5">
                            <div class="form-section">
                                <h4>Notificações de Exames</h4>
                                <div class="chat-box" id="exam-notifications-chat">
                                    <!-- Mensagens de exemplo -->
                                    <div class="chat-message system">
                                        <strong>Sistema:</strong> Novo resultado disponível para Maria Souza (Hemograma Completo). <small>12/07/2025 20:00:00</small>
                                    </div>
                                    <div class="chat-message">
                                        <strong>Você:</strong> Ok, vou verificar. <small>12/07/2025 19:55:00</small>
                                    </div>
                                    <div class="chat-message system">
                                        <strong>Sistema:</strong> Exame de João Silva (Raio-X de Tórax) agendado para 15/07/2025. <small>12/07/2025 19:00:00</small>
                                    </div>
                                    <div class="chat-message system">
                                        <strong>Sistema:</strong> Lembrete: Exame de Ana Paula (Glicemia) pendente há 3 dias. <small>11/07/2025 20:00:00</small>
                                    </div>
                                    <!-- Mais mensagens podem ser adicionadas dinamicamente aqui -->
                                </div>
                                <div class="mt-3">
                                    <input type="text" class="form-control" id="chatInput" placeholder="Digite uma mensagem...">
                                    <button class="btn btn-outline-primary mt-2 w-100" id="sendChatBtn"><i class="fas fa-paper-plane"></i> Enviar</button>
                                </div>
                            </div>

                            <div class="form-section mt-4">
                                <h4>Exames Pendentes/Realizados</h4>
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>João Silva</strong> - Hemograma Completo (<small>Pedido em: 05/06/2025</small>)
                                        </div>
                                        <div>
                                            <span class="badge bg-warning text-dark me-2">Pendente</span>
                                            <button class="btn btn-sm btn-outline-info">Ver Pedido</button>
                                        </div>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong>Fernanda Lima</strong> - Raio-X de Tórax (<small>Realizado em: 01/06/2025</small>)
                                        </div>
                                        <div>
                                            <span class="badge bg-success">Concluído</span>
                                            <button class="btn btn-sm btn-outline-primary"><i class="fas fa-file-medical-alt"></i> Ver Resultado</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="reports" class="content-section" style="display: none;">
                    <h2><i class="fas fa-chart-pie"></i> Relatórios</h2>
                    <div class="form-section">
                        <h4>Relatórios Disponíveis</h4>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Relatório de Consultas por Período
                                <button class="btn btn-sm btn-outline-secondary">Gerar</button>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Relatório de Medicamentos Prescritos
                                <button class="btn btn-sm btn-outline-secondary">Gerar</button>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Relatório de Atendimentos por Faixa Etária
                                <button class="btn btn-sm btn-outline-secondary">Gerar</button>
                            </li>
                        </ul>
                        <div class="mt-3">
                            <label for="reportStartDate" class="form-label">Data Início</label>
                            <input type="date" class="form-control" id="reportStartDate">
                        </div>
                        <div class="mb-3">
                            <label for="reportEndDate" class="form-label">Data Fim</label>
                            <input type="date" class="form-control" id="reportEndDate">
                        </div>
                        <button class="btn btn-primary mt-2"><i class="fas fa-download"></i> Exportar Relatório Geral</button>
                    </div>
                </div>

                <div id="charts-stats" class="content-section" style="display: none;">
                    <h2><i class="fas fa-chart-bar"></i> Gráficos e Estatísticas</h2>
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="card p-3">
                                <h5 class="card-title">Atendimentos por Mês</h5>
                                <canvas id="atendimentosChart"></canvas>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card p-3">
                                <h5 class="card-title">Tempo Médio por Procedimento (min)</h5>
                                <canvas id="tempoMedioChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="settings" class="content-section" style="display: none;">
                    <h2><i class="fas fa-cogs"></i> Configurações</h2>
                    <div class="form-section">
                        <h4>Minhas Informações</h4>
                        <div class="mb-3">
                            <label for="docName" class="form-label">Nome Completo</label>
                            <input type="text" class="form-control" id="docName" value="<?php echo $nome_medico; ?>" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="docSpecialty" class="form-label">Especialidade</label>
                            <input type="text" class="form-control" id="docSpecialty" value="<?php echo $especialidade_medico; ?>" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="docCrm" class="form-label">CRM</label>
                            <input type="text" class="form-control" id="docCrm" value="<?php echo $crm_medico; ?>" disabled>
                        </div>
                        <button class="btn btn-secondary"><i class="fas fa-edit"></i> Editar Perfil</button>
                    </div>
                    <div class="form-section mt-3">
                        <h4>Configurações do Sistema</h4>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" id="darkModeSwitch">
                            <label class="form-check-label" for="darkModeSwitch">Modo Escuro</label>
                        </div>
                        <button class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Sair</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="funpainelmed.js"></script>
</body>
</html>
