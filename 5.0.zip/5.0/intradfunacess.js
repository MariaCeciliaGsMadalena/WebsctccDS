
        // Objeto de tradução
        const translations = {
            "pt-br": {
                "nav.home": "Início",
                "nav.login": "Login",
                "nav.scheduling": "Agendamento",
                "nav.rate_service": "Avaliar Serviço",
                "hero.title": "Cuidamos da sua saúde com tecnologia e carinho",
                "hero.subtitle": "Agende consultas, faça check-ups e tenha acesso a um painel completo de saúde.",
                "hero.learn_more": "Saiba Mais",
                "services.title": "Nossos Serviços",
                "services.consultations.title": "Consultas Especializadas",
                "services.consultations.description": "Agende com nossos especialistas em diversas áreas da medicina.",
                "services.checkup.title": "Check-up Completo",
                "services.checkup.description": "Avaliação completa da sua saúde com nossos pacotes personalizados.",
                "services.exam_scheduling.title": "Agendamento de Exames",
                "services.exam_scheduling.description": "Fila pra exame? Nunca mais. Agende agora seus exames!",
                "services.patient_panel.title": "Painel do Paciente",
                "services.patient_panel.description": "Acompanhe sua saúde com segurança: vacinas, consultas e carteirinha digital.",
                "partnerships.title": "Parceria com Prefeituras",
                "partnerships.subtitle": "Orgulhosamente colaboramos com prefeituras que compartilham nosso compromisso com a saúde pública e o bem-estar da população.",
                "partnerships.brodowski.title": "Prefeitura de Brodowski",
                "partnerships.brodowski.description": "A Prefeitura de Brodowski é uma das grandes aliadas do nosso projeto. Sua gestão moderna e humanizada tem sido essencial para expandir o acesso à saúde digital, promovendo qualidade de vida e agilidade no atendimento à população.",
                "partnerships.quote": "\"Juntos, levamos cuidado e tecnologia para mais perto de quem precisa.\"",
                "partnerships.joint_work.title": "Trabalho em Conjunto",
                "partnerships.joint_work.description": "A colaboração com prefeituras fortalece nossa missão. Com apoio institucional, conseguimos ampliar o alcance dos nossos serviços, beneficiando comunidades inteiras com atendimento eficiente e personalizado.",
                "testimonials.title": "O que nossos pacientes dizem",
                "testimonials.subtitle": "Depoimentos de quem já experimentou nossos serviços",
                "testimonials.patient1.name": "Ana Costa",
                "testimonials.patient1.comment": "Atendimento excelente! Os médicos são muito atenciosos e o agendamento pela internet é super prático.",
                "testimonials.patient2.name": "Carlos Souza",
                "testimonials.patient2.comment": "Fiz meu check-up anual e fiquei impressionado com a qualidade do serviço. Recomendo a todos!",
                "news.title": "Notícias & Dicas de Saúde",
                "news.subtitle": "Fique por dentro de novidades, dicas de bem-estar e informações importantes sobre sua saúde.",
                "news.card1.title": "Como manter a imunidade alta",
                "news.card1.description": "Dicas práticas para fortalecer seu sistema imunológico durante todo o ano.",
                "news.card2.title": "Check-up: quando fazer?",
                "news.card2.description": "Saiba a frequência ideal para check-ups e evite problemas futuros.",
                "news.card3.title": "Alimentação saudável no dia a dia",
                "news.card3.description": "Aprenda como pequenas mudanças na alimentação impactam muito sua saúde.",
                "news.read_more": "Leia mais",
                "newsletter.title": "Assine nossa Newsletter",
                "newsletter.subtitle": "Receba dicas de saúde, promoções e novidades diretamente no seu e-mail.",
                "newsletter.email_label": "Digite seu e-mail",
                "newsletter.subscribe_button": "Inscrever-se",
                "cta.title": "Pronto para cuidar da sua saúde?",
                "cta.subtitle": "Agende sua consulta agora mesmo e dê o primeiro passo para uma vida mais saudável",
                "cta.button": "Agendar Consulta",
                "footer.brand": "AgilixMedTech",
                "footer.description": "Cuidando da sua saúde com excelência e tecnologia.",
                "footer.quick_links.title": "Links Rápidos",
                "footer.quick_links.home": "Início",
                "footer.quick_links.scheduling": "Agendamento",
                "footer.quick_links.comments": "Comentários",
                "footer.quick_links.partner_municipality": "Seja nossa prefeitura parceira",
                "footer.contact.title": "Contato",
                "footer.contact.phone": "(16) 1234-5678",
                "footer.contact.email": "contato@suportehospital.com",
                "footer.social_media.title": "Redes Sociais",
                "footer.copyright": "&copy; 2025 Trabalho de conclusão de curso da turma de desenvolvimento de sistemas da ETEC Batatais, SP.",
                "accessibility.dark_mode": "Modo Escuro",
                "accessibility.increase_font": "Fonte +",
                "accessibility.decrease_font": "Fonte -",
                "accessibility.high_contrast": "Contraste",
                "accessibility.grayscale": "Tons de Cinza"
            },
            "es": {
                "nav.home": "Inicio",
                "nav.login": "Iniciar Sesión",
                "nav.scheduling": "Citas",
                "nav.rate_service": "Evaluar Servicio",
                "hero.title": "Cuidamos de su salud con tecnología y cariño",
                "hero.subtitle": "Programe citas, realice chequeos y acceda a un panel de salud completo.",
                "hero.learn_more": "Saber Más",
                "services.title": "Nuestros Servicios",
                "services.consultations.title": "Consultas Especializadas",
                "services.consultations.description": "Programe con nuestros especialistas en diversas áreas de la medicina.",
                "services.checkup.title": "Chequeo Completo",
                "services.checkup.description": "Evaluación completa de su salud con nuestros paquetes personalizados.",
                "services.exam_scheduling.title": "Programación de Exámenes",
                "services.exam_scheduling.description": "¿Fila para examen? Nunca más. ¡Programe sus exámenes ahora!",
                "services.patient_panel.title": "Panel del Paciente",
                "services.patient_panel.description": "Monitore su salud de forma segura: vacunas, citas y tarjeta digital.",
                "partnerships.title": "Asociación con Ayuntamientos",
                "partnerships.subtitle": "Orgullosamente colaboramos con ayuntamientos que comparten nuestro compromiso con la salud pública y el bienestar de la población.",
                "partnerships.brodowski.title": "Ayuntamiento de Brodowski",
                "partnerships.brodowski.description": "El Ayuntamiento de Brodowski es uno de los grandes aliados de nuestro proyecto. Su gestión moderna y humanizada ha sido esencial para expandir el acceso a la salud digital, promoviendo calidad de vida y agilidad en la atención a la población.",
                "partnerships.quote": "\"Juntos, llevamos cuidado y tecnología más cerca de quien lo necesita.\"",
                "partnerships.joint_work.title": "Trabajo Conjunto",
                "partnerships.joint_work.description": "La colaboración con los ayuntamientos fortalece nuestra misión. Con apoyo institucional, logramos ampliar el alcance de nuestros servicios, beneficiando a comunidades enteras con atención eficiente y personalizada.",
                "testimonials.title": "Lo que dicen nuestros pacientes",
                "testimonials.subtitle": "Testimonios de quienes ya han experimentado nuestros servicios",
                "testimonials.patient1.name": "Ana Costa",
                "testimonials.patient1.comment": "¡Excelente atención! Los médicos son muy atentos y la programación online es súper práctica.",
                "testimonials.patient2.name": "Carlos Souza",
                "testimonials.patient2.comment": "Hice mi chequeo anual y quedé impresionado con la calidad del servicio. ¡Lo recomiendo a todos!",
                "news.title": "Noticias y Consejos de Salud",
                "news.subtitle": "Manténgase al tanto de las noticias, consejos de bienestar e información importante sobre su salud.",
                "news.card1.title": "¿Cómo mantener alta la inmunidad?",
                "news.card1.description": "Consejos prácticos para fortalecer su sistema inmunológico durante todo el año.",
                "news.card2.title": "Chequeo: ¿cuándo hacerlo?",
                "news.card2.description": "Conozca la frecuencia ideal para los chequeos y evite problemas futuros.",
                "news.card3.title": "Alimentación saludable en el día a día",
                "news.card3.description": "Aprenda cómo pequeños cambios en la dieta impactan mucho en su salud.",
                "news.read_more": "Leer más",
                "newsletter.title": "Suscríbase a nuestro Newsletter",
                "newsletter.subtitle": "Reciba consejos de salud, promociones y novedades directamente en su correo electrónico.",
                "newsletter.email_label": "Ingrese su correo electrónico",
                "newsletter.subscribe_button": "Suscribirse",
                "cta.title": "¿Listo para cuidar su salud?",
                "cta.subtitle": "Programe su cita ahora mismo y dé el primer paso hacia una vida más saludable",
                "cta.button": "Programar Cita",
                "footer.brand": "AgilixMedTech",
                "footer.description": "Cuidando de su salud con excelencia y tecnología.",
                "footer.quick_links.title": "Enlaces Rápidos",
                "footer.quick_links.home": "Inicio",
                "footer.quick_links.scheduling": "Citas",
                "footer.quick_links.comments": "Comentarios",
                "footer.quick_links.partner_municipality": "Sea nuestro ayuntamiento asociado",
                "footer.contact.title": "Contacto",
                "footer.contact.phone": "(16) 1234-5678",
                "footer.contact.email": "contacto@suportehospital.com",
                "footer.social_media.title": "Redes Sociales",
                "footer.copyright": "&copy; 2025 Trabajo de fin de carrera del curso de desarrollo de sistemas de ETEC Batatais, SP.",
                "accessibility.dark_mode": "Modo Oscuro",
                "accessibility.increase_font": "Fuente +",
                "accessibility.decrease_font": "Fuente -",
                "accessibility.high_contrast": "Contraste",
                "accessibility.grayscale": "Escala de Grises"
            },
            "en": {
                "nav.home": "Home",
                "nav.login": "Login",
                "nav.scheduling": "Scheduling",
                "nav.rate_service": "Rate Service",
                "hero.title": "We care for your health with technology and care",
                "hero.subtitle": "Book appointments, get check-ups, and access a complete health dashboard.",
                "hero.learn_more": "Learn More",
                "services.title": "Our Services",
                "services.consultations.title": "Specialized Consultations",
                "services.consultations.description": "Book appointments with our specialists in various areas of medicine.",
                "services.checkup.title": "Complete Check-up",
                "services.checkup.description": "Full health assessment with our personalized packages.",
                "services.exam_scheduling.title": "Exam Scheduling",
                "services.exam_scheduling.description": "Waiting for exams? No more. Schedule your exams now!",
                "services.patient_panel.title": "Patient Dashboard",
                "services.patient_panel.description": "Monitor your health securely: vaccines, appointments, and digital health card.",
                "partnerships.title": "Partnership with Municipalities",
                "partnerships.subtitle": "We proudly collaborate with municipalities that share our commitment to public health and the well-being of the population.",
                "partnerships.brodowski.title": "Brodowski Municipality",
                "partnerships.brodowski.description": "Brodowski Municipality is a major ally of our project. Its modern and humanized management has been essential to expand access to digital health, promoting quality of life and agility in public service.",
                "partnerships.quote": "\"Together, we bring care and technology closer to those who need it.\"",
                "partnerships.joint_work.title": "Joint Work",
                "partnerships.joint_work.description": "Collaboration with municipalities strengthens our mission. With institutional support, we can expand the reach of our services, benefiting entire communities with efficient and personalized care.",
                "testimonials.title": "What our patients say",
                "testimonials.subtitle": "Testimonials from those who have experienced our services",
                "testimonials.patient1.name": "Ana Costa",
                "testimonials.patient1.comment": "Excellent service! The doctors are very attentive and online scheduling is super practical.",
                "testimonials.patient2.name": "Carlos Souza",
                "testimonials.patient2.comment": "I had my annual check-up and was impressed with the quality of service. I recommend it to everyone!",
                "news.title": "News & Health Tips",
                "news.subtitle": "Stay up-to-date with news, wellness tips, and important health information.",
                "news.card1.title": "How to boost your immunity",
                "news.card1.description": "Practical tips to strengthen your immune system throughout the year.",
                "news.card2.title": "Check-up: when to do it?",
                "news.card2.description": "Learn the ideal frequency for check-ups and avoid future problems.",
                "news.card3.title": "Healthy eating in daily life",
                "news.card3.description": "Learn how small dietary changes greatly impact your health.",
                "news.read_more": "Read more",
                "newsletter.title": "Subscribe to our Newsletter",
                "newsletter.subtitle": "Receive health tips, promotions, and news directly to your email.",
                "newsletter.email_label": "Enter your email",
                "newsletter.subscribe_button": "Subscribe",
                "cta.title": "Ready to take care of your health?",
                "cta.subtitle": "Schedule your appointment right now and take the first step towards a healthier life",
                "cta.button": "Schedule Appointment",
                "footer.brand": "AgilixMedTech",
                "footer.description": "Caring for your health with excellence and technology.",
                "footer.quick_links.title": "Quick Links",
                "footer.quick_links.home": "Home",
                "footer.quick_links.scheduling": "Scheduling",
                "footer.quick_links.comments": "Comments",
                "footer.quick_links.partner_municipality": "Become our partner municipality",
                "footer.contact.title": "Contact",
                "footer.contact.phone": "(16) 1234-5678",
                "footer.contact.email": "contact@hospitalsupport.com",
                "footer.social_media.title": "Social Media",
                "footer.copyright": "&copy; 2025 Final project of the systems development class at ETEC Batatais, SP." ,
                "accessibility.dark_mode": "Dark Mode",
                "accessibility.increase_font": "Font Size +",
                "accessibility.decrease_font": "Font Size -",
                "accessibility.high_contrast": "High Contrast",
                "accessibility.grayscale": "Grayscale"
            }
        };

        // Função para aplicar as traduções
        function applyTranslations(lang) {
            document.documentElement.lang = lang; // Define o atributo lang do HTML
            const elements = document.querySelectorAll('[data-i18n]');
            elements.forEach(element => {
                const key = element.getAttribute('data-i18n');
                if (translations[lang] && translations[lang][key]) {
                    element.textContent = translations[lang][key];
                }
            });
            // Atualizar placeholders de input
            const emailInput = document.getElementById('newsletter-email');
            if (emailInput) {
                emailInput.placeholder = translations[lang]["newsletter.email_label"];
            }
            // Atualizar títulos de botões de acessibilidade
            document.getElementById('toggle-dark-mode').title = translations[lang]["accessibility.dark_mode"];
            document.getElementById('increase-font').title = translations[lang]["accessibility.increase_font"];
            document.getElementById('decrease-font').title = translations[lang]["accessibility.decrease_font"];
            document.getElementById('toggle-contrast').title = translations[lang]["accessibility.high_contrast"];
            document.getElementById('toggle-grayscale').title = translations[lang]["accessibility.grayscale"];
        }

        // Função para definir o idioma
        function setLanguage(lang) {
            localStorage.setItem('selectedLanguage', lang); // Salva a preferência
            applyTranslations(lang);
        }

        // Acessibilidade: Modo Escuro
        const toggleDarkModeBtn = document.getElementById('toggle-dark-mode');
        const toggleDarkModeMobileBtn = document.getElementById('toggle-dark-mode-mobile');

        function toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
            localStorage.setItem('darkMode', document.documentElement.classList.contains('dark'));
        }
        toggleDarkModeBtn.addEventListener('click', toggleDarkMode);
        toggleDarkModeMobileBtn.addEventListener('click', toggleDarkMode);

        // Acessibilidade: Tamanho da Fonte
        const body = document.body;
        const increaseFontBtn = document.getElementById('increase-font');
        const decreaseFontBtn = document.getElementById('decrease-font');
        const increaseFontMobileBtn = document.getElementById('increase-font-mobile');
        const decreaseFontMobileBtn = document.getElementById('decrease-font-mobile');

        let currentFontSize = 1; // 1 = normal, 1.1 = large, 1.25 = x-large

        function setFontSize(size) {
            body.classList.remove('large-font', 'x-large-font');
            if (size === 1.1) {
                body.classList.add('large-font');
            } else if (size === 1.25) {
                body.classList.add('x-large-font');
            }
            currentFontSize = size;
            localStorage.setItem('fontSize', size);
        }

        increaseFontBtn.addEventListener('click', () => {
            if (currentFontSize === 1) setFontSize(1.1);
            else if (currentFontSize === 1.1) setFontSize(1.25);
        });
        decreaseFontBtn.addEventListener('click', () => {
            if (currentFontSize === 1.25) setFontSize(1.1);
            else if (currentFontSize === 1.1) setFontSize(1);
        });

        increaseFontMobileBtn.addEventListener('click', () => {
            if (currentFontSize === 1) setFontSize(1.1);
            else if (currentFontSize === 1.1) setFontSize(1.25);
        });
        decreaseFontMobileBtn.addEventListener('click', () => {
            if (currentFontSize === 1.25) setFontSize(1.1);
            else if (currentFontSize === 1.1) setFontSize(1);
        });

        // Acessibilidade: Alto Contraste
        const toggleContrastBtn = document.getElementById('toggle-contrast');
        const toggleContrastMobileBtn = document.getElementById('toggle-contrast-mobile');
        function toggleContrast() {
            body.classList.toggle('contrast-mode');
            localStorage.setItem('highContrast', body.classList.contains('contrast-mode'));
        }
        toggleContrastBtn.addEventListener('click', toggleContrast);
        toggleContrastMobileBtn.addEventListener('click', toggleContrast);

        // Acessibilidade: Tons de Cinza (Daltonismo)
        const toggleGrayscaleBtn = document.getElementById('toggle-grayscale');
        const toggleGrayscaleMobileBtn = document.getElementById('toggle-grayscale-mobile');
        function toggleGrayscale() {
            body.classList.toggle('desaturate-mode');
            localStorage.setItem('grayscaleMode', body.classList.contains('desaturate-mode'));
        }
        toggleGrayscaleBtn.addEventListener('click', toggleGrayscale);
        toggleGrayscaleMobileBtn.addEventListener('click', toggleGrayscale);

        // Lógica para o menu móvel
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
            this.setAttribute('aria-expanded', menu.classList.contains('hidden') ? 'false' : 'true');
        });

        // Carregar preferências do usuário ao carregar a página
        document.addEventListener('DOMContentLoaded', () => {
            // Idioma
            const savedLanguage = localStorage.getItem('selectedLanguage') || 'pt-br';
            document.getElementById('language-selector').value = savedLanguage;
            applyTranslations(savedLanguage);

            // Modo Escuro
            const savedDarkMode = localStorage.getItem('darkMode') === 'true';
            if (savedDarkMode) {
                document.documentElement.classList.add('dark');
            }

            // Tamanho da Fonte
            const savedFontSize = parseFloat(localStorage.getItem('fontSize') || '1');
            setFontSize(savedFontSize);

            // Alto Contraste
            const savedHighContrast = localStorage.getItem('highContrast') === 'true';
            if (savedHighContrast) {
                body.classList.add('contrast-mode');
            }

            // Tons de Cinza
            const savedGrayscaleMode = localStorage.getItem('grayscaleMode') === 'true';
            if (savedGrayscaleMode) {
                body.classList.add('desaturate-mode');
            }
        });