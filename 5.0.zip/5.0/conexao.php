<?php
// Arquivo: conexao.php

// Definições de conexão com o banco de dados
define('DB_SERVER', 'localhost'); // Geralmente 'localhost' para USBWebserver
define('DB_DATABASE', 'agilixmdtechbd');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'usbw'); // Senha do seu USBWebserver

// Bloco try-catch para testar a conexão (opcional, pode ser removido em produção)
try {
    // Cria uma nova conexão PDO usando as constantes definidas
    $conn = new PDO(
        "mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4",
        DB_USERNAME,
        DB_PASSWORD
    );

    // Ativar erros PDO como exceções
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Alerta de conexão bem-sucedida (apenas para teste, remova em produção)
    // Nota: Evite usar alert() em aplicações web reais, pois bloqueia a interface.
    // Use mensagens na tela ou logs para depuração.
    echo "<script>console.log('Conexão PDO bem-sucedida!');</script>";
} catch (PDOException $e) {
    // Alerta de erro na conexão (apenas para teste, remova em produção)
    echo "<script>console.error('Erro ao conectar via PDO: " . addslashes($e->getMessage()) . "');</script>";
    // Em um ambiente de produção, você pode querer registrar o erro e exibir uma mensagem genérica ao usuário.
    // error_log("Erro de conexão com o banco de dados: " . $e->getMessage());
    // die("Ocorreu um erro ao conectar ao banco de dados. Por favor, tente novamente mais tarde.");
}

// A variável $conn estará disponível para ser usada em outros arquivos PHP que incluírem 'conexao.php'
?>
