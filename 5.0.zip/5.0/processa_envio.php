<?php
// Define o charset para evitar problemas de codificação
header('Content-Type: text/html; charset=UTF-8');

// Configurações do Banco de Dados
// ATENÇÃO: Substitua 'localhost', 'seu_usuario', 'sua_senha' e 'seu_banco_de_dados'
// pelas suas credenciais reais do banco de dados.
$servername = "localhost"; // Geralmente 'localhost'
$username = "seu_usuario"; // Seu nome de usuário do banco de dados
$password = "sua_senha"; // Sua senha do banco de dados
$dbname = "seu_banco_de_dados"; // Nome do seu banco de dados

// Diretório para upload dos arquivos
// Certifique-se de que este diretório exista e tenha permissões de escrita adequadas (ex: 0755)
$target_dir = "uploads/";

// Cria o diretório 'uploads' se ele não existir
if (!is_dir($target_dir)) {
    // Tenta criar o diretório recursivamente com permissões 0777 (para desenvolvimento, ajustar para 0755 em produção)
    if (!mkdir($target_dir, 0777, true)) {
        die("<div class='alert alert-danger' role='alert'>Erro: Não foi possível criar o diretório de uploads. Verifique as permissões.</div>");
    }
}

// Verifica se o formulário foi enviado via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera os dados do formulário
    $nome_medico = $_POST['nome_medico'] ?? '';
    $email_medico = $_POST['email_medico'] ?? '';
    $crm_medico = $_POST['crm_medico'] ?? NULL; // Novo campo CRM, pode ser NULL se não for obrigatório
    $tipo_resultado = $_POST['tipo_resultado'] ?? '';

    // Validação básica dos campos obrigatórios
    if (empty($nome_medico) || empty($email_medico) || empty($tipo_resultado) || !isset($_FILES["arquivo_resultado"])) {
        echo "<div class='alert alert-danger' role='alert'>Por favor, preencha todos os campos obrigatórios e selecione um arquivo.</div>";
        // Inclui o script Bootstrap para estilizar o alerta
        echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" xintegrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">';
        echo '<div class="mt-3 text-center"><a href="index.html" class="btn btn-primary">Voltar</a></div>';
        exit(); // Interrompe a execução do script
    }

    // Lidar com o upload do arquivo
    $uploadOk = 1;
    $file_name = basename($_FILES["arquivo_resultado"]["name"]);
    $target_file = $target_dir . $file_name;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Gera um nome de arquivo único para evitar colisões e problemas de segurança
    $unique_file_name = uniqid() . "." . $fileType;
    $target_file_unique = $target_dir . $unique_file_name;

    // Verifica se o arquivo é um tipo permitido
    $allowed_types = array("pdf", "doc", "docx", "jpg", "jpeg", "png");
    if (!in_array($fileType, $allowed_types)) {
        echo "<div class='alert alert-danger' role='alert'>Desculpe, apenas arquivos PDF, DOC, DOCX, JPG, JPEG e PNG são permitidos.</div>";
        $uploadOk = 0;
    }

    // Verifica o tamanho do arquivo (ex: 5MB máximo)
    if ($_FILES["arquivo_resultado"]["size"] > 5000000) { // 5MB
        echo "<div class='alert alert-danger' role='alert'>Desculpe, seu arquivo é muito grande. O tamanho máximo permitido é 5MB.</div>";
        $uploadOk = 0;
    }

    // Verifica se houve algum erro no upload do arquivo temporário
    if ($_FILES["arquivo_resultado"]["error"] != UPLOAD_ERR_OK) {
        echo "<div class='alert alert-danger' role='alert'>Erro no upload do arquivo: " . $_FILES["arquivo_resultado"]["error"] . "</div>";
        $uploadOk = 0;
    }

    // Se o upload estiver ok, tenta mover o arquivo para o diretório de destino
    if ($uploadOk == 0) {
        echo "<div class='alert alert-danger' role='alert'>Seu arquivo não foi enviado.</div>";
    } else {
        if (move_uploaded_file($_FILES["arquivo_resultado"]["tmp_name"], $target_file_unique)) {
            echo "<div class='alert alert-success' role='alert'>O arquivo " . htmlspecialchars($file_name) . " foi enviado com sucesso.</div>";

            // Inserir dados no banco de dados
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
                // Define o modo de erro para lançar exceções em caso de erro
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                // Prepara a instrução SQL para inserção, incluindo o novo campo crm_medico
                $stmt = $conn->prepare("INSERT INTO resultados_medicos (nome_medico, email_medico, crm_medico, tipo_resultado, caminho_arquivo) VALUES (:nome_medico, :email_medico, :crm_medico, :tipo_resultado, :caminho_arquivo)");

                // Faz o binding dos parâmetros para evitar SQL Injection
                $stmt->bindParam(':nome_medico', $nome_medico);
                $stmt->bindParam(':email_medico', $email_medico);
                $stmt->bindParam(':crm_medico', $crm_medico); // Binding do novo campo CRM
                $stmt->bindParam(':tipo_resultado', $tipo_resultado);
                $stmt->bindParam(':caminho_arquivo', $target_file_unique); // Salva o caminho único do arquivo no BD

                // Executa a instrução preparada
                $stmt->execute();

                echo "<div class='alert alert-success' role='alert'>Dados salvos no banco de dados com sucesso!</div>";
            } catch (PDOException $e) {
                // Captura e exibe erros de conexão ou de consulta ao banco de dados
                echo "<div class='alert alert-danger' role='alert'>Erro ao salvar dados no banco de dados: " . $e->getMessage() . "</div>";
            } finally {
                // Garante que a conexão com o banco de dados seja fechada
                $conn = null;
            }
        } else {
            echo "<div class='alert alert-danger' role='alert'>Desculpe, houve um erro ao mover seu arquivo.</div>";
        }
    }
} else {
    // Mensagem exibida se o script for acessado diretamente sem um POST
    echo "<div class='alert alert-warning' role='alert'>Acesso inválido ao script. Por favor, envie o formulário.</div>";
}
?>

<!-- Adiciona o CSS do Bootstrap para estilizar as mensagens de alerta -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" xintegrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<!-- Botão para voltar à página principal -->
<div class="mt-3 text-center">
    <a href="index.html" class="btn btn-primary">Voltar</a>
</div>
