-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 14-Jun-2025 às 22:33
-- Versão do servidor: 5.7.36
-- versão do PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agilixbd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicos`
--

CREATE TABLE `medicos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `crm` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `especialidade` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unidade_saude` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo` tinyint(1) DEFAULT '1',
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `Senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `medicos`
--

INSERT INTO `medicos` (`id`, `nome`, `crm`, `especialidade`, `email`, `telefone`, `unidade_saude`, `ativo`, `data_criacao`, `Senha`) VALUES
(1, 'Dr. João SUS', '123456-SP', 'Clínico Geral', 'joao.sus@prefeitura.gov.br', '(11) 98765-4321', 'UBS Central São Paulo', 1, '2025-06-07 22:10:51', 'Joao@123'),
(3, 'Nakara', 'CRM/SP 123456', 'Urologista', 'nakara.urologista@prefeitura.gov.br', '(11) 98765-4321', 'Hospital Municipal Central', 1, '2025-06-08 01:06:48', 'Senha123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pacientes`
--

CREATE TABLE `pacientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `sobrenome` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `data_nascimento` date NOT NULL,
  `idade` int(11) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pacientes`
--

INSERT INTO `pacientes` (`id`, `nome`, `sobrenome`, `email`, `senha`, `cpf`, `data_nascimento`, `idade`, `telefone`, `endereco`, `sexo`, `data_cadastro`) VALUES
(1, 'João', 'Silva', 'joao.silva@example.com', 'senha123', '111.222.333-44', '1990-05-15', 35, '(16) 98765-4321', 'Rua das Flores, 123, Centro, Brodowski', 'M', '2025-06-14 22:02:30'),
(2, 'Maria', 'Santos', 'maria.santos@example.com', 'minhasenha', '555.666.777-88', '1985-11-20', 39, '(16) 99876-5432', 'Avenida Principal, 456, Boa Vista, Franca', 'F', '2025-06-14 22:02:30'),
(3, 'Pedro', 'Almeida', 'pedro.almeida@example.com', 'abcde123', '999.000.111-22', '2000-01-01', 25, '(16) 97777-8888', 'Travessa dos Sonhos, 789, Jardim Eldorado, Batatais', 'M', '2025-06-14 22:02:30'),
(4, 'Ana', 'Oliveira', 'ana.oliveira@example.com', 'securepass', '123.456.789-00', '1978-07-22', 46, '(16) 96666-1111', 'Alameda das Palmeiras, 10, Vila Nova, Jardinópolis', 'F', '2025-06-14 22:02:30'),
(5, 'Carlos', 'Ferreira', 'carlos.ferreira@example.com', 'qwerty098', '000.111.222-33', '1995-03-10', 30, '(16) 95555-2222', 'Praça da Liberdade, 5, Centro, Altinópolis', 'M', '2025-06-14 22:02:30');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `crm` (`crm`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `medicos`
--
ALTER TABLE `medicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
