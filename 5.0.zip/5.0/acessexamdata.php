<?php
session_start();
include_once 'conexao.php'; // Inclui o arquivo de conexão com o banco de dados

// Lógica para processar o envio do formulário de resultados (EXISTENTE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_resultado'])) {
    $nome_medico = $_POST['nome_medico'] ?? '';
    $email_medico = $_POST['email_medico'] ?? '';
    $crm_medico = $_POST['crm_medico'] ?? NULL;
    $tipo_resultado = $_POST['tipo_resultado'] ?? '';
    $id_paciente_resultado = $_POST['id_paciente_resultado'] ?? NULL; // ID do paciente para o resultado

    $arquivo_resultado = NULL;
    if (isset($_FILES['arquivo_resultado']) && $_FILES['arquivo_resultado']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/'; // Crie esta pasta no seu servidor
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_name = uniqid() . '_' . basename($_FILES['arquivo_resultado']['name']);
        $target_file = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES['arquivo_resultado']['tmp_name'], $target_file)) {
            $arquivo_resultado = $target_file;
        } else {
            echo "<script>alert('Erro ao fazer upload do arquivo.');</script>";
        }
    }

    try {
        $conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4", DB_USERNAME, DB_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $conn->prepare("INSERT INTO exames (id_paciente, nome_medico, email_medico, crm_medico, tipo_exame, arquivo_resultado, status_exame) VALUES (:id_paciente, :nome_medico, :email_medico, :crm_medico, :tipo_exame, :arquivo_resultado, 'Concluído')");
        $stmt->bindParam(':id_paciente', $id_paciente_resultado, PDO::PARAM_INT);
        $stmt->bindParam(':nome_medico', $nome_medico, PDO::PARAM_STR);
        $stmt->bindParam(':email_medico', $email_medico, PDO::PARAM_STR);
        $stmt->bindParam(':crm_medico', $crm_medico, PDO::PARAM_STR);
        $stmt->bindParam(':tipo_exame', $tipo_resultado, PDO::PARAM_STR);
        $stmt->bindParam(':arquivo_resultado', $arquivo_resultado, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "<script>alert('Resultado enviado com sucesso!');</script>";
        } else {
            echo "<script>alert('Erro ao salvar o resultado no banco de dados.');</script>";
        }

    } catch (PDOException $e) {
        echo "<script>alert('Erro de banco de dados: " . addslashes($e->getMessage()) . "');</script>";
    } finally {
        $conn = null;
    }
}

// Lógica para requisições AJAX (buscar pacientes, buscar exames de paciente)
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    try {
        $conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE . ";charset=utf8mb4", DB_USERNAME, DB_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($_GET['action'] === 'search_patients') {
            $query = $_GET['query'] ?? '';
            $patients = [];
            if (!empty($query)) {
                $sql = "SELECT id_paciente, nome, cpf, data_nascimento, genero, ultima_visita FROM pacientes WHERE nome LIKE :query OR cpf LIKE :query_cpf LIMIT 10";
                $stmt = $conn->prepare($sql);
                $searchTerm = '%' . $query . '%';
                $stmt->bindParam(':query', $searchTerm, PDO::PARAM_STR);
                $stmt->bindParam(':query_cpf', $searchTerm, PDO::PARAM_STR);
                $stmt->execute();
                $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($patients as &$patient) {
                    if (!empty($patient['data_nascimento'])) {
                        $birthDate = new DateTime($patient['data_nascimento']);
                        $today = new DateTime('today');
                        $age = $birthDate->diff($today)->y;
                        $patient['idade'] = $age;
                    } else {
                        $patient['idade'] = null;
                    }
                }
                unset($patient);
            }
            echo json_encode($patients);
            exit;

        } elseif ($_GET['action'] === 'get_patient_exams') {
            $id_paciente = $_GET['id_paciente'] ?? null;
            $exams = [];
            if ($id_paciente) {
                $sql = "SELECT id_exame, tipo_exame, data_solicitacao, data_realizacao, data_resultado, status_exame, arquivo_resultado, observacoes FROM exames WHERE id_paciente = :id_paciente ORDER BY data_solicitacao DESC";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':id_paciente', $id_paciente, PDO::PARAM_INT);
                $stmt->execute();
                $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            echo json_encode($exams);
            exit;
        }

    } catch (PDOException $e) {
        echo json_encode(['error' => 'Erro de banco de dados: ' . $e->getMessage()]);
        exit;
    } finally {
        $conn = null;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Acesso Exames</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      xintegrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <!-- Google Fonts (mantido do original) -->
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter%3Awght%40400%3B500%3B700%3B900&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
      body {
        font-family: "Inter", "Noto Sans", sans-serif;
        background-color: #f8f9fa; /* bg-gray-50 */
      }
      .sidebar {
        background-color: #f8f9fa; /* bg-gray-50 */
        min-height: 700px;
      }
      .sidebar .nav-link {
        color: #101418; /* text-[#101418] */
        padding: 0.75rem 1rem;
        border-radius: 0.75rem; /* rounded-xl */
        display: flex;
        align-items: center;
        gap: 0.75rem; /* gap-3 */
      }
      .sidebar .nav-link.active {
        background-color: #eaedf1; /* bg-[#eaedf1] */
        font-weight: 500; /* font-medium */
      }
      .search-input-group .form-control {
        background-color: #eaedf1; /* bg-[#eaedf1] */
        border: none;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .search-input-group .input-group-text {
        background-color: #eaedf1; /* bg-[#eaedf1] */
        border: none;
        color: #5c728a; /* text-[#5c728a] */
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
      .filter-button {
        background-color: #eaedf1; /* bg-[#eaedf1] */
        color: #101418; /* text-[#101418] */
        border: none;
        border-radius: 0.75rem; /* rounded-xl */
        padding: 0.5rem 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem; /* gap-x-2 */
        font-weight: 500; /* font-medium */
      }
      .table-responsive .table {
        border-radius: 0.75rem; /* rounded-xl */
        border: 1px solid #d4dbe2; /* border border-[#d4dbe2] */
        background-color: #f8f9fa; /* bg-gray-50 */
      }
      .table thead th {
        color: #101418; /* text-[#101418] */
        font-weight: 500; /* font-medium */
      }
      .table tbody td {
        color: #101418; /* text-[#101418] */
        font-weight: 400; /* font-normal */
      }
      .table tbody tr:not(:first-child) {
        border-top: 1px solid #d4dbe2; /* border-t border-t-[#d4dbe2] */
      }
      .form-control-custom {
        height: 3.5rem; /* h-14 */
        padding: 0.9375rem; /* p-[15px] */
        border-radius: 0.75rem; /* rounded-xl */
        border: 1px solid #d4dbe2; /* border border-[#d4dbe2] */
        background-color: #f8f9fa; /* bg-gray-50 */
        color: #101418;
      }
      .form-control-custom::placeholder {
        color: #5c728a; /* placeholder:text-[#5c728a] */
      }
      .form-select-custom {
        height: 3.5rem; /* h-14 */
        padding: 0.9375rem; /* p-[15px] */
        border-radius: 0.75rem; /* rounded-xl */
        border: 1px solid #d4dbe2; /* border border-[#d4dbe2] */
        background-color: #f8f9fa; /* bg-gray-50 */
        color: #101418;
        background-image: var(--select-button-svg); /* mantém o SVG do original */
        background-repeat: no-repeat;
        background-position: right 0.75rem center;
        background-size: 16px 12px;
      }
      .send-button {
        background-color: #b2cbe5; /* bg-[#b2cbe5] */
        color: #101418; /* text-[#101418] */
        font-weight: bold; /* font-bold */
        letter-spacing: 0.015em; /* tracking-[0.015em] */
        height: 2.5rem; /* h-10 */
        padding: 0 1rem; /* px-4 */
        border-radius: 0.75rem; /* rounded-xl */
        border: none;
      }
      /* Estilos para a lista de sugestões de pacientes */
      .patient-suggestions {
          position: absolute;
          z-index: 1000;
          width: calc(100% - 2rem); /* Ajuste conforme o padding do container */
          max-height: 200px;
          overflow-y: auto;
          background-color: #fff;
          border: 1px solid #d4dbe2;
          border-radius: 0.75rem;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      }
      .patient-suggestions .list-group-item {
          cursor: pointer;
      }
      .patient-suggestions .list-group-item:hover {
          background-color: #f0f0f0;
      }
      .exam-input-group .form-control {
        border-top-left-radius: 0.75rem;
        border-bottom-left-radius: 0.75rem;
      }
      .exam-input-group .input-group-text {
        background-color: #e9ecef;
        border: 1px solid #d4dbe2;
        border-left: none;
        border-top-right-radius: 0.75rem;
        border-bottom-right-radius: 0.75rem;
        color: #5c728a;
      }
    </style>
  </head>
  <body>
    <div
      class="container-fluid d-flex flex-column min-vh-100 p-0"
      style="
        --select-button-svg: url('data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724px%27 height=%2724px%27 fill=%27rgb(92,114,138)%27 viewBox=%270 0 256 256%27%3e%3cpath d=%27M181.66,170.34a8,8,0,0,1,0,11.32l-48,48a8,8,0,0,1-11.32,0l-48-48a8,8,0,0,1,11.32-11.32L128,212.69l42.34-42.35A8,8,0,0,1,181.66,170.34Zm-96-84.68L128,43.31l42.34,42.35a8,8,0,0,0,11.32-11.32l-48-48a8,8,0,0,0-11.32,0l-48,48A8,8,0,0,0,85.66,85.66Z%27%3e%3c/path%3e%3c/svg%3e');
      "
    >
      <div class="row flex-grow-1">
        <!-- Slider Bar (Sidebar) -->
        <div class="col-md-3 col-lg-2 p-4 sidebar">
          <div class="d-flex flex-column gap-4">
            <div class="d-flex flex-column">
              <h1 class="fs-5 fw-medium text-dark">Acesso Exame</h1>
              <p class="text-secondary fs-6">Admin</p>
            </div>
            <div class="d-flex flex-column gap-2">
              <a href="#" class="nav-link active" id="nav-pacientes">
                <div class="text-dark">
                  <i class="fas fa-users"></i> <!-- Ícone de pacientes -->
                </div>
                <p class="mb-0 fs-6">Pacientes</p>
              </a>
              <a href="#" class="nav-link" id="nav-registros">
                <div class="text-dark">
                  <i class="fas fa-notes-medical"></i> <!-- Ícone de registros médicos -->
                </div>
                <p class="mb-0 fs-6">Registros Médicos</p>
              </a>
              <a href="#" class="nav-link" id="nav-relatorios">
                <div class="text-dark">
                  <i class="fas fa-chart-pie"></i> <!-- Ícone de relatórios -->
                </div>
                <p class="mb-0 fs-6">Relatórios</p>
              </a>
              <a href="#" class="nav-link" id="nav-configuracoes">
                <div class="text-dark">
                  <i class="fas fa-cog"></i> <!-- Ícone de configurações -->
                </div>
                <p class="mb-0 fs-6">Configurações</p>
              </a>
            </div>
          </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10 p-4">
          <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fs-2 fw-bold text-dark">Gerenciamento de Pacientes</h2>
          </div>

          <!-- Search Bar -->
          <div class="mb-3">
            <div class="input-group search-input-group rounded-xl">
              <span class="input-group-text">
                <i class="fas fa-search"></i> <!-- Ícone de lupa -->
              </span>
              <input
                type="text"
                class="form-control form-control-lg"
                placeholder="Pesquisar pacientes por nome ou CPF"
                id="searchPatientInput"
                oninput="searchPatients(this.value)"
              />
            </div>
            <div id="patient-search-suggestions" class="list-group patient-suggestions" style="display: none;"></div>
          </div>


          <!-- Patients Table -->
          <div class="table-responsive mb-4">
            <table class="table table-borderless">
              <thead>
                <tr>
                  <th scope="col">Nome</th>
                  <th scope="col">Idade</th>
                  <th scope="col">Gênero</th>
                  <th scope="col">Última Visita</th>
                  <th scope="col">Ações</th>
                </tr>
              </thead>
              <tbody id="patientsTableBody">
                <!-- Dados dos pacientes serão carregados aqui via JavaScript -->
                <tr>
                  <td colspan="5" class="text-center">Carregando pacientes...</td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Patient Exams Section (Initially hidden) -->
          <div id="patientExamsSection" style="display: none;">
            <h2 class="fs-4 fw-bold text-dark mt-5 mb-3">
              Exames de <span id="selectedPatientName"></span>
            </h2>
            <div class="table-responsive mb-4">
              <table class="table table-borderless">
                <thead>
                  <tr>
                    <th scope="col">Tipo de Exame</th>
                    <th scope="col">Data Solicitação</th>
                    <th scope="col">Data Realização</th>
                    <th scope="col">Data Resultado</th>
                    <th scope="col">Status</th>
                    <th scope="col">Ações</th>
                  </tr>
                </thead>
                <tbody id="patientExamsTableBody">
                  <!-- Exames do paciente serão carregados aqui via JavaScript -->
                  <tr>
                    <td colspan="6" class="text-center">Nenhum exame encontrado para este paciente.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>


          <!-- Send Results Section -->
          <h2 class="fs-4 fw-bold text-dark mt-5 mb-3">
            Enviar Resultados para o Médico
          </h2>
          <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" id="id_paciente_resultado" name="id_paciente_resultado">
            <div class="row g-3 mb-3">
              <div class="col-md-6 col-lg-4">
                <input
                  type="text"
                  class="form-control form-control-custom"
                  placeholder="Nome do Médico"
                  name="nome_medico"
                  required
                />
              </div>
              <div class="col-md-6 col-lg-4">
                <input
                  type="email"
                  class="form-control form-control-custom"
                  placeholder="Email do Médico"
                  name="email_medico"
                  required
                />
              </div>
              <div class="col-md-6 col-lg-4">
                <input
                  type="text"
                  class="form-control form-control-custom"
                  placeholder="CRM do Médico"
                  name="crm_medico"
                />
              </div>
              <div class="col-md-6 col-lg-4">
                <select class="form-select form-select-custom" name="tipo_resultado" required>
                  <option selected disabled value="">Tipo de Resultado</option>
                  <option value="exame_laboratorial">Exame Laboratorial</option>
                  <option value="imagem_diagnostica">Imagem Diagnóstica</option>
                  <option value="relatorio_medico">Relatório Médico</option>
                  <option value="outros">Outros</option>
                </select>
              </div>
              <div class="col-md-6 col-lg-4">
                <label for="arquivo_resultado" class="form-label visually-hidden">Anexar Resultado</label>
                <input
                  type="file"
                  class="form-control form-control-custom"
                  id="arquivo_resultado"
                  name="arquivo_resultado"
                  required
                />
              </div>
            </div>
            <div class="d-flex justify-content-end mb-4">
              <button type="submit" name="submit_resultado" class="btn send-button">Enviar</button>
            </div>
          </form>

          <hr class="my-5">

          <!-- NEW: Enter Exam Results Section for Biomedic -->
          <h2 class="fs-4 fw-bold text-dark mt-5 mb-3">
            Lançar Resultados de Exames de Sangue
          </h2>
          <form action="gerar_resultado_exame_pdf.php" method="POST" target="_blank">
            <div class="mb-3">
                <label for="biomedicPatientSearchInput" class="form-label">Buscar Paciente para Lançar Resultados</label>
                <div class="input-group search-input-group rounded-xl">
                    <span class="input-group-text">
                        <i class="fas fa-search"></i>
                    </span>
                    <input
                        type="text"
                        class="form-control form-control-lg"
                        placeholder="Nome ou CPF do paciente"
                        id="biomedicPatientSearchInput"
                        oninput="searchPatientsForBiomedic(this.value)"
                    />
                </div>
                <div id="biomedic-patient-suggestions" class="list-group patient-suggestions" style="display: none;"></div>
                <input type="hidden" id="id_paciente_biomedico" name="id_paciente_biomedico" required>
                <small class="form-text text-muted" id="selectedBiomedicPatientInfo">Nenhum paciente selecionado.</small>
            </div>

            <div class="mb-4">
                <h5 class="mb-3">Resultados do Hemograma Completo</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="hemacias" class="form-label">Hemácias ($10^6/\mu L$)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="hemacias" name="hemacias" placeholder="Ex: 5.70">
                            <span class="input-group-text">Ref: 4.00-6.10</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="hemoglobina" class="form-label">Hemoglobina (g/dL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="hemoglobina" name="hemoglobina" placeholder="Ex: 16.8">
                            <span class="input-group-text">Ref: 13.0-18.0</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="hematocrito" class="form-label">Hematócrito (%)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="hematocrito" name="hematocrito" placeholder="Ex: 49.1">
                            <span class="input-group-text">Ref: 39.0-54.0</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="vcm" class="form-label">VCM (fL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="vcm" name="vcm" placeholder="Ex: 86.1">
                            <span class="input-group-text">Ref: 80.0-98.0</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="hcm" class="form-label">HCM (pg)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="hcm" name="hcm" placeholder="Ex: 29.2">
                            <span class="input-group-text">Ref: 27.0-32.0</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="chcm" class="form-label">CHCM (g/dL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="chcm" name="chcm" placeholder="Ex: 34.2">
                            <span class="input-group-text">Ref: 30.0-36.0</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="rdw" class="form-label">RDW (%)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="rdw" name="rdw" placeholder="Ex: 13.6">
                            <span class="input-group-text">Ref: 11.0-16.0</span>
                        </div>
                    </div>
                </div>

                <h5 class="mt-4 mb-3">Resultados do Leucograma</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="leucocitos" class="form-label">Leucócitos ($/mm^3$)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="leucocitos" name="leucocitos" placeholder="Ex: 8.000">
                            <span class="input-group-text">Ref: 4.000-11.000</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="bastonetes" class="form-label">Bastonetes (%)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="bastonetes" name="bastonetes" placeholder="Ex: 0">
                            <span class="input-group-text">Ref: 0-5</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="segmentados" class="form-label">Segmentados (%)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="segmentados" name="segmentados" placeholder="Ex: 55">
                            <span class="input-group-text">Ref: 40-70</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="eosinofilos" class="form-label">Eosinófilos (%)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="eosinofilos" name="eosinofilos" placeholder="Ex: 2">
                            <span class="input-group-text">Ref: 1-5</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="monocitos" class="form-label">Monócitos (%)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="monocitos" name="monocitos" placeholder="Ex: 7">
                            <span class="input-group-text">Ref: 3-10</span>
                        </div>
                    </div>
                </div>

                <h5 class="mt-4 mb-3">Resultados da Série Plaquetária</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="plaquetas" class="form-label">Plaquetas ($10^3/\mu L$)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="plaquetas" name="plaquetas" placeholder="Ex: 167">
                            <span class="input-group-text">Ref: 130-450</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="vmp" class="form-label">VMP (fL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="vmp" name="vmp" placeholder="Ex: 11.8">
                            <span class="input-group-text">Ref: 6.8-12.6</span>
                        </div>
                    </div>
                </div>

                <h5 class="mt-4 mb-3">Outros Exames</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="fsh" class="form-label">FSH (mUI/mL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="fsh" name="fsh" placeholder="Ex: 7.2">
                            <span class="input-group-text">Ref: Variável</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="t4_livre" class="form-label">T4 Livre (ng/dL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="t4_livre" name="t4_livre" placeholder="Ex: 1.2">
                            <span class="input-group-text">Ref: 0.8-1.8</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="glicemia" class="form-label">Glicemia (mg/dL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="glicemia" name="glicemia" placeholder="Ex: 95">
                            <span class="input-group-text">Ref: 70-99</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="prolactina" class="form-label">Prolactina (ng/mL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="prolactina" name="prolactina" placeholder="Ex: 15.0">
                            <span class="input-group-text">Ref: Variável</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="estradiol" class="form-label">Estradiol (pg/mL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="estradiol" name="estradiol" placeholder="Ex: 50.0">
                            <span class="input-group-text">Ref: Variável</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="ck_mb" class="form-label">CK-MB (ng/mL)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="ck_mb" name="ck_mb" placeholder="Ex: 5.0">
                            <span class="input-group-text">Ref: < 25</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="ast" class="form-label">AST (U/L)</label>
                        <div class="input-group exam-input-group">
                            <input type="number" step="0.01" class="form-control" id="ast" name="ast" placeholder="Ex: 20">
                            <span class="input-group-text">Ref: < 35</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="urina" class="form-label">Exame de Urina (Observações)</label>
                        <input type="text" class="form-control" id="urina" name="urina" placeholder="Ex: Leucócitos 5-10/campo">
                    </div>
                    <div class="col-md-4">
                        <label for="diabetes_obs" class="form-label">Curva Glicêmica (Observações)</label>
                        <input type="text" class="form-control" id="diabetes_obs" name="diabetes_obs" placeholder="Ex: 90 mg/dL (jejum), 140 mg/dL (1h)">
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="observacoes_gerais_exame" class="form-label">Observações Gerais do Exame</label>
                <textarea class="form-control form-control-custom" id="observacoes_gerais_exame" name="observacoes_gerais_exame" rows="3" placeholder="Informações adicionais relevantes para o exame."></textarea>
            </div>

            <div class="d-flex justify-content-end mb-4">
              <button type="submit" name="submit_resultados_biomedico" class="btn send-button">Gerar PDF do Resultado</button>
            </div>
          </form>

        </div>
      </div>

      <!-- Footer -->
      <footer class="text-center py-4 bg-light mt-auto">
        <p class="mb-0 text-secondary">AgilixMedtech</p>
      </footer>
    </div>

    <!-- Bootstrap JS -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      xintegrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>

    <script>
        let currentSearchTimeout = null;
        let currentSearchController = null;

        document.addEventListener('DOMContentLoaded', function() {
            // Função para buscar pacientes e preencher a tabela principal
            async function fetchAndDisplayPatients(query = '') {
                const patientsTableBody = document.getElementById('patientsTableBody');
                patientsTableBody.innerHTML = '<tr><td colspan="5" class="text-center">Carregando pacientes...</td></tr>';

                try {
                    const response = await fetch(`acessexamdata.php?action=search_patients&query=${encodeURIComponent(query)}`);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const patients = await response.json();

                    patientsTableBody.innerHTML = ''; // Limpa a tabela
                    if (patients.length > 0) {
                        patients.forEach(patient => {
                            const row = patientsTableBody.insertRow();
                            row.innerHTML = `
                                <td>${patient.nome}</td>
                                <td class="text-secondary">${patient.idade ?? 'N/A'}</td>
                                <td class="text-secondary">${patient.genero}</td>
                                <td class="text-secondary">${patient.ultima_visita ?? 'N/A'}</td>
                                <td class="fw-bold text-secondary">
                                    <button class="btn btn-sm btn-outline-primary" onclick="viewPatientExams(${patient.id_paciente}, '${patient.nome}')">Visualizar Exames</button>
                                </td>
                            `;
                        });
                    } else {
                        patientsTableBody.innerHTML = '<tr><td colspan="5" class="text-center">Nenhum paciente encontrado.</td></tr>';
                    }
                } catch (error) {
                    console.error('Erro ao buscar pacientes:', error);
                    patientsTableBody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Erro ao carregar pacientes.</td></tr>';
                }
            }

            // Função para buscar pacientes para a barra de pesquisa principal com sugestões
            window.searchPatients = async function(query) {
                const suggestionsBox = document.getElementById('patient-search-suggestions');
                
                if (currentSearchTimeout) {
                    clearTimeout(currentSearchTimeout);
                }
                if (currentSearchController) {
                    currentSearchController.abort(); // Cancela a requisição anterior
                }

                if (query.length < 3) {
                    suggestionsBox.style.display = 'none';
                    suggestionsBox.innerHTML = '';
                    fetchAndDisplayPatients(); // Recarrega a tabela completa se a busca for limpa
                    return;
                }

                currentSearchTimeout = setTimeout(async () => {
                    currentSearchController = new AbortController();
                    const signal = currentSearchController.signal;

                    try {
                        const response = await fetch(`acessexamdata.php?action=search_patients&query=${encodeURIComponent(query)}`, { signal });
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        const patients = await response.json();

                        suggestionsBox.innerHTML = '';
                        if (patients.length > 0) {
                            patients.forEach(patient => {
                                const item = document.createElement('a');
                                item.href = '#';
                                item.classList.add('list-group-item', 'list-group-item-action');
                                item.textContent = `${patient.nome} (CPF: ${patient.cpf})`;
                                item.addEventListener('click', (e) => {
                                    e.preventDefault();
                                    document.getElementById('searchPatientInput').value = patient.nome; // Preenche a barra de pesquisa
                                    suggestionsBox.style.display = 'none';
                                    fetchAndDisplayPatients(patient.nome); // Filtra a tabela com o paciente selecionado
                                    document.getElementById('id_paciente_resultado').value = patient.id_paciente; // Preenche o campo oculto no formulário de envio de resultados
                                });
                                suggestionsBox.appendChild(item);
                            });
                            suggestionsBox.style.display = 'block';
                        } else {
                            suggestionsBox.style.display = 'none';
                        }
                    } catch (error) {
                        if (error.name === 'AbortError') {
                            console.log('Fetch de sugestões abortado');
                        } else {
                            console.error('Erro ao buscar pacientes para sugestões:', error);
                            suggestionsBox.style.display = 'none';
                        }
                    } finally {
                        currentSearchController = null;
                    }
                }, 300);
            };

            // Função para buscar pacientes para a seção de "Lançar Resultados de Exames de Sangue" (para o biomédico)
            window.searchPatientsForBiomedic = async function(query) {
                const suggestionsBox = document.getElementById('biomedic-patient-suggestions');
                const selectedPatientInfo = document.getElementById('selectedBiomedicPatientInfo');
                const idPacienteBiomedico = document.getElementById('id_paciente_biomedico');

                if (currentSearchTimeout) {
                    clearTimeout(currentSearchTimeout);
                }
                if (currentSearchController) {
                    currentSearchController.abort();
                }

                if (query.length < 3) {
                    suggestionsBox.style.display = 'none';
                    suggestionsBox.innerHTML = '';
                    selectedPatientInfo.textContent = 'Nenhum paciente selecionado.';
                    idPacienteBiomedico.value = '';
                    return;
                }

                currentSearchTimeout = setTimeout(async () => {
                    currentSearchController = new AbortController();
                    const signal = currentSearchController.signal;

                    try {
                        const response = await fetch(`acessexamdata.php?action=search_patients&query=${encodeURIComponent(query)}`, { signal });
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        const patients = await response.json();

                        suggestionsBox.innerHTML = '';
                        if (patients.length > 0) {
                            patients.forEach(patient => {
                                const item = document.createElement('a');
                                item.href = '#';
                                item.classList.add('list-group-item', 'list-group-item-action');
                                item.textContent = `${patient.nome} (CPF: ${patient.cpf})`;
                                item.addEventListener('click', (e) => {
                                    e.preventDefault();
                                    document.getElementById('biomedicPatientSearchInput').value = patient.nome;
                                    selectedPatientInfo.textContent = `Paciente selecionado: ${patient.nome} (CPF: ${patient.cpf})`;
                                    idPacienteBiomedico.value = patient.id_paciente;
                                    suggestionsBox.style.display = 'none';
                                });
                                suggestionsBox.appendChild(item);
                            });
                            suggestionsBox.style.display = 'block';
                        } else {
                            suggestionsBox.style.display = 'none';
                            selectedPatientInfo.textContent = 'Nenhum paciente encontrado.';
                            idPacienteBiomedico.value = '';
                        }
                    } catch (error) {
                        if (error.name === 'AbortError') {
                            console.log('Fetch de sugestões de biomédico abortado');
                        } else {
                            console.error('Erro ao buscar pacientes para biomédico:', error);
                            suggestionsBox.style.display = 'none';
                            selectedPatientInfo.textContent = 'Erro ao buscar pacientes.';
                            idPacienteBiomedico.value = '';
                        }
                    } finally {
                        currentSearchController = null;
                    }
                }, 300);
            };


            // Função para visualizar exames de um paciente
            window.viewPatientExams = async function(patientId, patientName) {
                const patientExamsSection = document.getElementById('patientExamsSection');
                const selectedPatientName = document.getElementById('selectedPatientName');
                const patientExamsTableBody = document.getElementById('patientExamsTableBody');

                selectedPatientName.textContent = patientName;
                patientExamsSection.style.display = 'block';
                patientExamsTableBody.innerHTML = '<tr><td colspan="6" class="text-center">Carregando exames...</td></tr>';

                try {
                    const response = await fetch(`acessexamdata.php?action=get_patient_exams&id_paciente=${patientId}`);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const exams = await response.json();

                    patientExamsTableBody.innerHTML = '';
                    if (exams.length > 0) {
                        exams.forEach(exam => {
                            const row = patientExamsTableBody.insertRow();
                            row.innerHTML = `
                                <td>${exam.tipo_exame}</td>
                                <td>${exam.data_solicitacao ?? 'N/A'}</td>
                                <td>${exam.data_realizacao ?? 'N/A'}</td>
                                <td>${exam.data_resultado ?? 'N/A'}</td>
                                <td><span class="badge bg-${exam.status_exame === 'Concluído' ? 'success' : (exam.status_exame === 'Solicitado' ? 'info' : 'warning')}">${exam.status_exame}</span></td>
                                <td>
                                    ${exam.arquivo_resultado ? `<a href="${exam.arquivo_resultado}" target="_blank" class="btn btn-sm btn-info me-2">Ver Arquivo</a>` : ''}
                                    ${exam.resultado ? `<button class="btn btn-sm btn-secondary" onclick="alert('Resultado: ${exam.resultado}')">Ver Resultado</button>` : ''}
                                </td>
                            `;
                        });
                    } else {
                        patientExamsTableBody.innerHTML = '<tr><td colspan="6" class="text-center">Nenhum exame encontrado para este paciente.</td></tr>';
                    }
                } catch (error) {
                    console.error('Erro ao buscar exames do paciente:', error);
                    patientExamsTableBody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Erro ao carregar exames.</td></tr>';
                }
            };

            // Carregar todos os pacientes ao iniciar a página
            fetchAndDisplayPatients();
        });
    </script>
  </body>
</html>
