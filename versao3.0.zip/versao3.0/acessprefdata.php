<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Painel Unificado</title>
  <!-- Estilos e bibliotecas necessárias -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #e0eafc, #cfdef3);
    }
    .hidden {
      display: none;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .btn {
      transition: background-color 0.3s, transform 0.3s;
    }
    .btn:hover {
      background-color: #4caf50;
      transform: scale(1.05);
    }
  </style>
</head>
<body>

  <!-- Painel da Prefeitura -->
  <div id="painel-prefeitura">
    <header class="sticky top-0 z-50 shadow-md">
      <nav class="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
          <div class="flex items-center gap-2">
            <i class="fas fa-hospital text-2xl"></i>
            <a href="#" class="text-xl font-bold">Prefeitura</a>
          </div>
        </div>
      </nav>
    </header>

    <section class="w-full mt-10 p-6 bg-white rounded-lg shadow-lg">
      <div class="flex flex-col items-start">
        <h2 class="text-2xl font-semibold mt-3">Painel da Prefeitura</h2>
        <table>
          <th>
 <p class="mt-2">Gerencie os acessos dos médicos abaixo:</p>
        <ul class="list-disc list-inside text-blue-600 space-y-1 mt-4">
          <li><button onclick="mostrarPainelMedico()" class="text-blue-600 hover:underline">Médico A - 01/01/2023</button></li>
          <li>Médico B - 01/06/2023</li>
          <li>Médico C - 01/12/2023</li>
        </ul>
      </div>
     <div class="mt-6">
        <h3 class="text-xl font-semibold">Adicionar Novo Médico</h3>
        <form class="mt-4" onsubmit="adicionarMedico(event)">
          <div class="mb-3">
            <label for="nome-medico" class="form-label">Nome do Médico</label>
            <input type="text" class="form-control" id="nome-medico" placeholder="Digite o nome do médico" required>
          </div>
          <button type="submit" class="btn btn-primary">Adicionar Médico</button>
        </form>
      </div> 

          </th>
          <th>
        <div class="bg-gray-50 p-5 rounded-lg shadow">
        <h3 class="text-lg font-bold text-gray-800 mb-2 flex items-center">
          <i class="fas fa-toolbox text-primary mr-2"></i> Serviços
        </h3>
        <ul class="space-y-2">
          <li><a href="agendamento.html" class="text-blue-600 hover:underline">Gerar relatorio de controle de horarios</a></li>
          <button onclick="toggleExames()" class="text-blue-600 hover:underline flex items-center">
            <i class="fas fa-flask-vial mr-2"></i> Receitas emitadas pelo medicos
          </button>
          <button onclick="toggleReceitas()" class="text-blue-600 hover:underline flex items-center">
            <i class="fas fa-flask-vial mr-2"></i> Quantidade de consultas
          </button>
        </ul></th>
        <td> 
       <!-- Gerador de Email para Médico -->
<div class="bg-white p-5 rounded-lg shadow mt-6">
  <h3 class="text-lg font-bold text-gray-800 mb-2 flex items-center">
    <i class="fas fa-envelope text-primary mr-2"></i> Gerador de Email do Médico
  </h3>
  <div class="flex flex-col md:flex-row md:items-center gap-4">
    <input
      id="nomeMedico"
      type="text"
      placeholder="Digite o nome do médico"
      class="w-full md:w-1/2 border border-gray-300 rounded px-4 py-2"
    />
    <button
      onclick="gerarEmail()"
      class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition"
    >
      Gerar Email
    </button>
  </div>
  <div id="resultadoEmail" class="mt-4 text-gray-700 font-mono"></div>
</div>
</td>
        </table>
    </section>
  </div>

  

</body>
</html>
