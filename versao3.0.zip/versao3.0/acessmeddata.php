<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Painel do Medico</title>
  <link rel="icon" href="favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"> <!-- Adicionando Bootstrap -->
  <script src="https://cdn.tailwindcss.com"></script>

  
</head>
<body class="font-sans bg-gray-100">

  <!-- Loader -->
  

  <!-- Conteúdo do Paciente -->
  <div id="conteudo-paciente" class="hidden">
    <header class="sticky top-0 z-50 shadow-md">
      <nav class="bg-gradient-to-r from-primary to-secondary text-white">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
          <div class="flex items-center gap-2">
            <i class="fas fa-hospital text-2xl"></i>
            <a href="index.html" class="text-xl font-bold">Prefeitura</a>
          </div>
        </div>
      </nav>
    </header>

    
       <!-- Área do Médico -->
  <div class="container mt-5" id="medico">
    <h2 class="text-center mb-4 text-primary">Painel do Médico</h2>
    <div class="row">
      <!-- Selecionar horários disponíveis -->
      <div class="col-md-6">
        <div class="card p-4 mb-4">
          <h5>Definir Horários Disponíveis</h5>
          <form>
            <div class="mb-3">
              <label for="data-medico" class="form-label">Data</label>
              <input type="date" class="form-control" id="data-medico">
            </div>
            <div class="mb-3">
              <label for="horarios-medico" class="form-label">Horários Disponíveis</label>
              <select multiple class="form-select" id="horarios-medico">
                <option>08:00</option>
                <option>09:00</option>
                <option>10:00</option>
                <option>11:00</option>
                <option>13:00</option>
                <option>14:00</option>
              </select>
              <small class="text-muted">Segure Ctrl (ou Command) para selecionar vários horários</small>
            </div>
            <button type="submit" class="btn btn-success w-100">Salvar Disponibilidade</button>
          </form>
        </div>
      </div>

      <!-- Agendamentos recebidos -->
      <div class="col-md-6">
        <div class="card p-4 mb-4">
          <h5>Agendamentos Recebidos</h5>
          <ul class="list-group" id="lista-agendamentos">
            <!-- Agendamento 1 -->
            <li class="list-group-item">
              <strong>João Silva</strong> - Cardiologia - 20/05/2025 às 08:00
              <div class="mt-2">
                <button class="btn btn-sm btn-success me-2">Aceitar</button>
                <button class="btn btn-sm btn-warning" onclick="mostrarReagendar(this)">Reagendar</button>
              </div>
              <div class="reagendar-form mt-2 d-none">
                <input type="date" class="form-control mb-2">
                <select class="form-select mb-2">
                  <option>08:00</option>
                  <option>09:00</option>
                  <option>10:00</option>
                  <option>11:00</option>
                  <option>13:00</option>
                  <option>14:00</option>
                </select>
                <button class="btn btn-sm btn-primary">Confirmar novo horário</button>
              </div>
            </li>

            <!-- Agendamento 2 -->
            <li class="list-group-item">
              <strong>Maria Costa</strong> - Ginecologia - 20/05/2025 às 09:00
              <div class="mt-2">
                <button class="btn btn-sm btn-success me-2">Aceitar</button>
                <button class="btn btn-sm btn-warning" onclick="mostrarReagendar(this)">Reagendar</button>
              </div>
              <div class="reagendar-form mt-2 d-none">
                <input type="date" class="form-control mb-2">
                <select class="form-select mb-2">
                  <option>08:00</option>
                  <option>09:00</option>
                  <option>10:00</option>
                  <option>11:00</option>
                  <option>13:00</option>
                  <option>14:00</option>
                </select>
                <button class="btn btn-sm btn-primary">Confirmar novo horário</button>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: '#3b82f6',
            secondary: '#8b5cf6',
          },
          fontFamily: {
            sans: ['Poppins', 'sans-serif'],
          }
        }
      }
    };
    // Função para mostrar o conteúdo após 5 segundos
    setTimeout(() => {
      document.getElementById('loader').style.display = 'none';
      document.getElementById('conteudo-paciente').classList.remove('hidden');
    }, 5000); // 5000 milissegundos = 5 segundos

    const toggleExames = () => document.getElementById('exames-section').classList.toggle('hidden');
    const toggleReceitas = () => document.getElementById('receitas-section').classList.toggle('hidden');

    function addIcon() {
      const input = document.getElementById('iconInput');
      const display = document.getElementById('iconDisplay');
      if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
          const img = document.createElement('img');
          img.src = e.target.result;
          img.classList.add('w-24', 'h-24', 'rounded-full', 'object-cover'); // Ajuste para 96x96
          display.innerHTML = ''; // Limpa o conteúdo anterior
          display.appendChild(img); // Adiciona a nova imagem
        }
        reader.readAsDataURL(input.files[0]);
      }
    }
    function mostrarReagendar(botao) {
      const item = botao.closest("li");
      const form = item.querySelector(".reagendar-form");
      form.classList.toggle("d-none");
  </script>
</body>
</html>