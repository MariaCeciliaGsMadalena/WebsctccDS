<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Painel do Paciente</title>
  <link rel="icon" href="favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"> <!-- Adicionando Bootstrap -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    .loading svg polyline {
      fill: none;
      stroke-width: 3;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .loading svg polyline#back {
      stroke: #ff4d5033;
    }

    .loading svg polyline#front {
      stroke: #ff4d4f;
      stroke-dasharray: 48, 144;
      stroke-dashoffset: 192;
      animation: dash_682 1.4s linear infinite;
    }

    @keyframes dash_682 {
      72.5% {
        opacity: 0;
      }
      to {
        stroke-dashoffset: 0;
      }
    }
  </style>
</head>
<body class="font-sans bg-gray-100">

  <!-- Loader -->
  <div id="loader" class="flex items-center justify-center h-screen bg-white">
    <div class="loading">
      <svg width="64px" height="48px">
        <polyline id="back" points="0.5,20.5 20.5,20.5 23.5,17.5 40.5,17.5 43.5,20.5 63.5,20.5 "></polyline>
        <polyline id="front" points="0.5,20.5 20.5,20.5 23.5,17.5 40.5,17.5 43.5,20.5 63.5,20.5 "></polyline>
      </svg>
    </div>
  </div>

  <!-- Conteúdo do Paciente -->
  <div id="conteudo-paciente" class="hidden">
    <header class="sticky top-0 z-50 shadow-md">
      <nav class="bg-gradient-to-r from-primary to-secondary text-white">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
          <div class="flex items-center gap-2">
            <i class="fas fa-hospital text-2xl"></i>
            <a href="index.html" class="text-xl font-bold">Hospital Online</a>
          </div>
        </div>
      </nav>
    </header>

    <!-- Info Paciente -->
    <section class="w-full mt-10 p-6 bg-white rounded-lg shadow-lg">
        <div class="flex flex-col items-start">
          
          <!-- Botão e Input de Ícone -->
          <div class="mb-4 w-full">
            <div class="flex items-center">
              <input type="file" id="iconInput" accept="image/*" class="hidden" onchange="addIcon()" />
              <button onclick="document.getElementById('iconInput').click();" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition">
                <i class="fas fa-pencil-alt"></i>
              </button>
            </div>
          </div>
      
          <div id="iconDisplay" class="mt-4"></div>
      
          <!-- Informações do Paciente -->
          <h2 class="text-2xl font-semibold mt-3">Teste Pessoa</h2>
          <p>Idade: 18</p>
          <p>Peso: 83 Kg</p>
          <p>Altura: 178 Cm</p>
          <p>Sangue: O+</p>
        </div>
      </section>
      

    <!-- Seções: Vacinas e Serviços -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="bg-gray-50 p-5 rounded-lg shadow">
        <h3 class="text-lg font-bold flex items-center text-gray-800 mb-2">
          <i class="fas fa-syringe text-primary mr-2"></i>
          Carteirinha de Vacina
        </h3>
        <p class="text-gray-700 mb-3">Aqui você pode acompanhar suas vacinas</p>
        <ul class="list-disc list-inside text-blue-600 space-y-1">
          <li>Vacina A - 01/01/2023</li>
          <li>Vacina B - 01/06/2023</li>
          <li>Vacina C - 01/12/2023</li>
        </ul>
        <button class="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition">
          Ver Mais
        </button>
      </div>

      <div class="bg-gray-50 p-5 rounded-lg shadow">
        <h3 class="text-lg font-bold text-gray-800 mb-2 flex items-center">
          <i class="fas fa-toolbox text-primary mr-2"></i> Serviços
        </h3>
        <ul class="space-y-2">
          <li><a href="agendamento.html" class="text-blue-600 hover:underline">Agendar</a></li>
          <button onclick="toggleExames()" class="text-blue-600 hover:underline flex items-center">
            <i class="fas fa-flask-vial mr-2"></i> Meus Exames
          </button>
          <button onclick="toggleReceitas()" class="text-blue-600 hover:underline flex items-center">
            <i class="fas fa-flask-vial mr-2"></i> Minhas Receitas
          </button>
        </ul>

        <!-- Seção Oculta dos Exames -->
        <div id="exames-section" class="mt-4 hidden">
          <h4 class="text-md font-semibold mb-2 flex items-center text-gray-700">
            <i class="fas fa-file-medical-alt mr-2 text-secondary"></i> Resultados Recentes
          </h4>
          <ul class="list-disc list-inside text-sm text-gray-800 space-y-1">
            <li>Hemograma completo - 12/03/2025</li>
            <li>Raio-X do Ku - 08/02/2025</li>
            <li>Ultrassonografia - 20/01/2025</li>
          </ul>
          <button class="mt-3 bg-secondary text-white px-4 py-2 rounded hover:bg-purple-700 transition">
            <i class="fas fa-download mr-1"></i> Baixar PDF
          </button>
        </div>
      </div>

      <!-- Seção Oculta das Receitas-->
      <div id="receitas-section" class="mt-4 hidden">
        <h4 class="text-md font-semibold mb-2 flex items-center text-gray-700">
          <i class="fas fa-file-medical-alt mr-2 text-secondary"></i> Minhas receitas
        </h4>
        <ul class="list-disc list-inside text-sm text-gray-800 space-y-1">
          <li>Litio-Dra Ana Silva - 10/01/2025</li>
          <li>Sufeto de Morfina-Dr Eduardo Fereira - 20/01/2025</li>
          <li>Metilfenidato-Dra Ana Silva- 10/01/2025</li>
        </ul>
        <button class="mt-3 bg-secondary text-white px-4 py-2 rounded hover:bg-purple-700 transition">
          <i class="fas fa-download mr-1"></i> Baixar PDF
        </button>
      </div>
    </div>

    <!-- Consultas -->
    <div class="mt-8 grid md:grid-cols-2 gap-6">
      <div>
        <h3 class="text-lg font-bold mb-2">Consultas Agendadas</h3>
        <div class="bg-gray-200 p-4 rounded-lg">
          <p><strong>Data :</strong> 26-07-2025 | <strong>Hora:</strong> 10:30 AM</p>
          <p><strong>Endereco:</strong> Teste</p>
          <p><strong>Médico:</ <strong>Dra. Roberta Silva</strong></p>
        </div>
      </div>

      <div>
        <h3 class="text-lg font-bold mb-2">Consultas Anteriores</h3>
        <div class="bg-gray-200 p-4 rounded-lg">
          <p><strong>18 Ago '24:</strong> Urologista | <strong>Dr. Tanaba noKu</strong></p>
          <p><strong>30 Jan 24:</strong> Nefrologista | <strong>Dr. Andre Silva</strong></p>
        </div>
      </div>
    </div>
  </section>

  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: '#3b82f6',
            secondary: '#8b5cf6',
          },
          fontFamily: {
            sans: ['Poppins', 'sans-serif'],
          }
        }
      }
    };
    // Função para mostrar o conteúdo após 5 segundos
    setTimeout(() => {
      document.getElementById('loader').style.display = 'none';
      document.getElementById('conteudo-paciente').classList.remove('hidden');
    }, 5000); // 5000 milissegundos = 5 segundos

    const toggleExames = () => document.getElementById('exames-section').classList.toggle('hidden');
    const toggleReceitas = () => document.getElementById('receitas-section').classList.toggle('hidden');

    function addIcon() {
      const input = document.getElementById('iconInput');
      const display = document.getElementById('iconDisplay');
      if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
          const img = document.createElement('img');
          img.src = e.target.result;
          img.classList.add('w-24', 'h-24', 'rounded-full', 'object-cover'); // Ajuste para 96x96
          display.innerHTML = ''; // Limpa o conteúdo anterior
          display.appendChild(img); // Adiciona a nova imagem
        }
        reader.readAsDataURL(input.files[0]);
      }
    }
  </script>
</body>
</html>