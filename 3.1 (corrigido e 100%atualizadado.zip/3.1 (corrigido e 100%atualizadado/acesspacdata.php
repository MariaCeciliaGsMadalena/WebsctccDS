<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel do Paciente</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: { primary: '#3b82f6', secondary: '#8b5cf6' },
          fontFamily: { sans: ['Poppins', 'sans-serif'] },
        },
      },
    };
  </script>
  <script src="https://kit.fontawesome.com/a2d9d5eada.js" crossorigin="anonymous"></script>
</head>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white">

  <!-- Layout -->
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-white dark:bg-gray-800 shadow-md flex flex-col p-4">
      <div class="flex flex-col items-center">
        <input type="file" id="profilePicInput" class="hidden" accept="image/*" onchange="changeProfilePic()">
        <img id="profilePic" src="https://via.placeholder.com/100" class="w-24 h-24 rounded-full object-cover">
        <button onclick="document.getElementById('profilePicInput').click()" class="mt-2 text-sm text-primary hover:underline">
          Alterar Foto
        </button>
        <h2 class="text-lg font-semibold mt-2">Teste Pessoa</h2>
        <p class="text-sm">Idade: 18 | Peso: 83kg | Altura: 178cm | Sangue: O+</p>
      </div>
      <nav class="mt-6 space-y-4">
        <a href="agendamento.html" class="flex items-center gap-2 hover:text-primary">
          <i class="fas fa-calendar-plus"></i> Agendar Consulta
        </a>
        <button onclick="toggleExames()" class="flex items-center gap-2 hover:text-primary">
          <i class="fas fa-flask-vial"></i> Meus Exames
        </button>
        <button onclick="toggleReceitas()" class="flex items-center gap-2 hover:text-primary">
          <i class="fas fa-notes-medical"></i> Minhas Receitas
        </button>
      </nav>
      <div class="mt-auto">
        <button onclick="toggleDarkMode()" class="flex items-center gap-2 text-sm hover:text-primary">
          <i class="fas fa-moon"></i> Modo Claro/Escuro
        </button>
      </div>
    </aside>

    <!-- Conteúdo -->
    <main class="flex-1 p-6">
      <h1 class="text-2xl font-bold mb-4">Bem-vindo, Teste Pessoa</h1>

      <!-- Card Exames -->
      <div id="examesCard" class="hidden bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-4">
        <h2 class="text-xl font-semibold mb-2">Exames Agendados</h2>
        <ul class="list-disc ml-5 space-y-1">
          <li>Hemograma - 25/05/2025</li>
          <li>Raio-X - 30/05/2025</li>
          <li>Ultrassonografia - 10/06/2025</li>
        </ul>
      </div>

      <!-- Card Receitas -->
      <div id="receitasCard" class="hidden bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-4">
        <h2 class="text-xl font-semibold mb-2">Minhas Receitas</h2>
        <button onclick="gerarReceita()" class="bg-primary text-white px-4 py-2 rounded hover:bg-blue-600 mb-3">
          + Gerar Receita
        </button>
        <ul id="listaReceitas" class="list-disc ml-5 space-y-1">
          <li>Litio - 10/01/2025 <button class="text-secondary hover:underline ml-2">Renovar</button></li>
          <li>Metilfenidato - 20/01/2025 <button class="text-secondary hover:underline ml-2">Renovar</button></li>
        </ul>
      </div>

      <!-- Consultas -->
      <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Consultas Agendadas</h3>
          <p>26-07-2025 às 10:30 - Dra. Roberta Silva</p>
        </div>
        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Consultas Anteriores</h3>
          <p>18-08-2024 - Urologista | Dr. Tanaba</p>
          <p>30-01-2024 - Nefrologista | Dr. Andre</p>
        </div>
      </div>
    </main>
  </div>

  <script>
    // Troca de imagem de perfil
    function changeProfilePic() {
      const input = document.getElementById('profilePicInput');
      const img = document.getElementById('profilePic');
      const file = input.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = e => img.src = e.target.result;
        reader.readAsDataURL(file);
      }
    }

    // Toggle modo claro/escuro
    function toggleDarkMode() {
      document.documentElement.classList.toggle('dark');
    }

    // Toggle exames
    function toggleExames() {
      document.getElementById('examesCard').classList.toggle('hidden');
    }

    // Toggle receitas
    function toggleReceitas() {
      document.getElementById('receitasCard').classList.toggle('hidden');
    }

    // Gerar nova receita
    function gerarReceita() {
      const lista = document.getElementById('listaReceitas');
      const item = document.createElement('li');
      item.innerHTML = `Nova Receita - ${(new Date()).toLocaleDateString()} 
        <button class="text-secondary hover:underline ml-2">Renovar</button>`;
      lista.appendChild(item);
    }
  </script>
</body>
</html>
