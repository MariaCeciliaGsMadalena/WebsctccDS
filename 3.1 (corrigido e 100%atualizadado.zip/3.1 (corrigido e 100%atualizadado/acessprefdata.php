<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Painel da Prefeitura</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://kit.fontawesome.com/a2d9d5eada.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; }
  </style>
</head>

<body class="bg-gradient-to-br from-blue-100 to-purple-100 min-h-screen">

  <!-- Navbar Superior -->
  <header class="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md">
    <div class="container mx-auto flex justify-between items-center px-6 py-4">
      <div class="flex items-center gap-3">
        <i class="fas fa-city text-2xl"></i>
        <span class="text-2xl font-bold">Prefeitura Municipal</span>
      </div>
      <div class="flex gap-6">
        <a href="#" class="hover:text-gray-200 flex items-center gap-1"><i class="fas fa-home"></i> Início</a>
        <a href="#" class="hover:text-gray-200 flex items-center gap-1"><i class="fas fa-cogs"></i> Serviços</a>
        <a href="#" class="hover:text-gray-200 flex items-center gap-1"><i class="fas fa-users"></i> Médicos</a>
        <a href="#" class="hover:text-gray-200 flex items-center gap-1"><i class="fas fa-file"></i> Relatórios</a>
      </div>
    </div>
  </header>

  <!-- Conteúdo -->
  <main class="container mx-auto px-6 py-8">
    <h1 class="text-3xl font-bold mb-6 text-gray-800">Secrataria Munipical da Saúde</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <!-- Card Médicos -->
      <div class="bg-white rounded-xl shadow-lg p-5">
        <h2 class="text-xl font-semibold mb-3 flex items-center gap-2"><i class="fas fa-user-md text-blue-500"></i> Gestão de Médicos</h2>
        <ul class="space-y-2 text-blue-700">
          <li><button onclick="mostrarPainelMedico()" class="hover:underline">Médico A - 01/01/2023</button></li>
          <li>Médico B - 01/06/2023</li>
          <li>Médico C - 01/12/2023</li>
        </ul>
        <div class="mt-4">
          <h3 class="text-lg font-medium mb-2">Adicionar Novo Médico</h3>
          <input id="nome-medico" type="text" placeholder="Nome do médico" class="w-full border rounded px-3 py-2 mb-2">
          <button onclick="adicionarMedico()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
            Adicionar
          </button>
        </div>
      </div>

      <!-- Card Serviços -->
      <div class="bg-white rounded-xl shadow-lg p-5">
        <h2 class="text-xl font-semibold mb-3 flex items-center gap-2"><i class="fas fa-toolbox text-green-500"></i> Serviços</h2>
        <ul class="space-y-3">
          <li><a href="agendamento.html" class="text-blue-600 hover:underline flex items-center gap-2"><i class="fas fa-calendar-check"></i> Relatório de Horários</a></li>
          <li><button onclick="toggleExames()" class="text-blue-600 hover:underline flex items-center gap-2"><i class="fas fa-notes-medical"></i> Receitas Emitidas</button></li>
          <li><button onclick="toggleConsultas()" class="text-blue-600 hover:underline flex items-center gap-2"><i class="fas fa-stethoscope"></i> Quantidade de Consultas</button></li>
        </ul>
      </div>

      <!-- Card Gerador de Email -->
      <div class="bg-white rounded-xl shadow-lg p-5">
        <h2 class="text-xl font-semibold mb-3 flex items-center gap-2"><i class="fas fa-envelope text-purple-500"></i> Gerador de Email</h2>
        <div class="flex flex-col gap-3">
          <input id="nomeMedico" type="text" placeholder="Digite o nome do médico" class="border rounded px-3 py-2">
          <button onclick="gerarEmail()" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
            Gerar Email
          </button>
        </div>
        <div id="resultadoEmail" class="mt-3 text-gray-700 font-mono"></div>
      </div>
    </div>

    <!-- Cards Expansíveis -->
    <div class="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
      <!-- Receitas Emitidas -->
      <div id="cardExames" class="hidden bg-white rounded-xl shadow-lg p-5">
        <h3 class="text-xl font-bold mb-2 flex items-center gap-2"><i class="fas fa-file-prescription text-red-500"></i> Receitas Emitidas</h3>
        <ul class="list-disc ml-5 space-y-1">
          <li>Litio - Médico A - 20/05/2025</li>
          <li>Metilfenidato - Médico B - 25/05/2025</li>
          <li>Paracetamol - Médico C - 30/05/2025</li>
        </ul>
      </div>

      <!-- Consultas Realizadas -->
      <div id="cardConsultas" class="hidden bg-white rounded-xl shadow-lg p-5">
        <h3 class="text-xl font-bold mb-2 flex items-center gap-2"><i class="fas fa-calendar-alt text-yellow-500"></i> Consultas Realizadas</h3>
        <ul class="list-disc ml-5 space-y-1">
          <li>Consulta A - 20/05/2025</li>
          <li>Consulta B - 25/05/2025</li>
          <li>Consulta C - 30/05/2025</li>
        </ul>
      </div>
    </div>
  </main>
<section class="mt-8 bg-white p-6 rounded-lg shadow-lg">
  <h2 class="text-2xl font-bold mb-4 flex items-center">
    <i class="fas fa-pills text-blue-500 mr-2"></i> Controle de Estoque - Farmácias Municipais
  </h2>

  <!-- Seletor da Farmácia -->
  <div class="mb-4">
    <label for="farmacia" class="block text-sm font-medium text-gray-700">Selecione a Farmácia:</label>
    <select id="farmacia" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
      <option>Farmácia Central</option>
      <option>Farmácia Bairro 1</option>
      <option>Farmácia Bairro 2</option>
      <option>Farmácia Rural</option>
    </select>
  </div>

  <!-- Tabela de Medicamentos -->
  <div class="overflow-x-auto">
    <table class="min-w-full bg-white">
      <thead class="bg-blue-500 text-white">
        <tr>
          <th class="py-2 px-4">Medicamento</th>
          <th class="py-2 px-4">Quantidade</th>
          <th class="py-2 px-4">Status</th>
          <th class="py-2 px-4">Ações</th>
        </tr>
      </thead>
      <tbody id="estoque">
        <tr>
          <td class="py-2 px-4">Paracetamol 500mg</td>
          <td class="py-2 px-4">120</td>
          <td class="py-2 px-4"><span class="bg-green-100 text-green-800 px-2 py-1 rounded-full">OK</span></td>
          <td class="py-2 px-4">
            <button onclick="removerItem(this)" class="text-red-500 hover:underline"><i class="fas fa-trash"></i> Remover</button>
          </td>
        </tr>
        <tr>
          <td class="py-2 px-4">Coca 500mg</td>
          <td class="py-2 px-4">20</td>
          <td class="py-2 px-4"><span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Baixo</span></td>
          <td class="py-2 px-4">
            <button onclick="removerItem(this)" class="text-red-500 hover:underline"><i class="fas fa-trash"></i> Remover</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Adicionar Medicamento -->
  <div class="mt-6">
    <h3 class="text-lg font-semibold mb-2">Adicionar Medicamento</h3>
    <div class="flex flex-col md:flex-row gap-3">
      <input id="nome-medicamento" type="text" placeholder="Nome do Medicamento" class="border p-2 rounded w-full md:w-1/3">
      <input id="quantidade-medicamento" type="number" placeholder="Quantidade" class="border p-2 rounded w-full md:w-1/3">
      <button onclick="adicionarMedicamento()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
        <i class="fas fa-plus"></i> Adicionar
      </button>
    </div>
  </div>
</section>

  <!-- Scripts -->
  <script>
    function toggleExames() {
      const card = document.getElementById('cardExames');
      card.classList.toggle('hidden');
    }

    function toggleConsultas() {
      const card = document.getElementById('cardConsultas');
      card.classList.toggle('hidden');
    }

    function gerarEmail() {
      const nome = document.getElementById('nomeMedico').value.trim();
      if (nome) {
        const email = nome.toLowerCase().replace(/\s+/g, '.') + '@prefeitura.com.br';
        document.getElementById('resultadoEmail').innerText = `Email gerado: ${email}`;
      } else {
        document.getElementById('resultadoEmail').innerText = 'Digite o nome do médico.';
      }
    }

    function adicionarMedico() {
      const nome = document.getElementById('nome-medico').value.trim();
      if (nome) {
        alert(`Médico ${nome} adicionado com sucesso!`);
      } else {
        alert('Digite o nome do médico.');
      }
    }
     function adicionarMedicamento() {
    const nome = document.getElementById('nome-medicamento').value.trim();
    const quantidade = parseInt(document.getElementById('quantidade-medicamento').value.trim());
    const tabela = document.getElementById('estoque');

    if (!nome || isNaN(quantidade) || quantidade <= 0) {
      alert('Preencha corretamente os campos!');
      return;
    }

    const status = quantidade < 30
      ? '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Baixo</span>'
      : '<span class="bg-green-100 text-green-800 px-2 py-1 rounded-full">OK</span>';

    const novaLinha = `
      <tr>
        <td class="py-2 px-4">${nome}</td>
        <td class="py-2 px-4">${quantidade}</td>
        <td class="py-2 px-4">${status}</td>
        <td class="py-2 px-4">
          <button onclick="removerItem(this)" class="text-red-500 hover:underline">
            <i class="fas fa-trash"></i> Remover
          </button>
        </td>
      </tr>
    `;

    tabela.insertAdjacentHTML('beforeend', novaLinha);

    // Limpa os campos
    document.getElementById('nome-medicamento').value = '';
    document.getElementById('quantidade-medicamento').value = '';
  }

  function removerItem(botao) {
    if (confirm('Deseja realmente remover este medicamento?')) {
      const linha = botao.closest('tr');
      linha.remove();
    }
  }
  </script>

</body>
</html>
