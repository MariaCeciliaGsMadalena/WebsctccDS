<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Médico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            min-height: 100vh;
            display: flex;
        }
        .sidebar {
            min-width: 250px;
            background-color: #0d6efd;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: rgba(255,255,255,0.2);
            border-radius: 5px;
        }
        .profile {
            text-align: center;
            margin-bottom: 30px;
        }
        .profile i {
            font-size: 60px;
            color: white;
        }
        .profile h5 {
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar p-3">
        <!-- Perfil -->
        <div class="profile">
            <i class="fas fa-user-md"></i>
            <h5>Dr. Carlos</h5>
            <small>Clínico Geral</small>
        </div>

        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="#dashboard" class="nav-link">
                    <i class="fas fa-chart-line"></i> Visão Geral
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="#cronometro" class="nav-link">
                    <i class="fas fa-clock"></i> Consulta
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="#receita" class="nav-link">
                    <i class="fas fa-prescription-bottle-alt"></i> Receita
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="#historico" class="nav-link">
                    <i class="fas fa-history"></i> Histórico
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="#pacientes" class="nav-link">
                    <i class="fas fa-users"></i> Pacientes
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="#configuracoes" class="nav-link">
                    <i class="fas fa-cogs"></i> Configurações
                </a>
            </li>
        </ul>
    </div>

    <!-- Conteúdo -->
    <div class="container-fluid p-4">

        <!-- Dashboard -->
        <div id="dashboard">
            <h2>Visão Geral</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-header">Consultas de Hoje</div>
                        <div class="card-body">
                            <h5 class="card-title" id="consultasHoje">5</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-header">Tempo Médio das Últimas 10 Consultas</div>
                        <div class="card-body">
                            <h5 class="card-title" id="tempoMedio">18 min</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-dark bg-warning mb-3">
                        <div class="card-header">Próximo Paciente</div>
                        <div class="card-body">
                            <h5 class="card-title">João Silva</h5>
                            <p>Horário: 14:30</p>
                            <p>Motivo: Consulta de Rotina</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <hr>

        <!-- Cronômetro -->
        <div id="cronometro">
            <h2>Controle de Consulta</h2>
            <div class="card p-3">
                <h4 id="display">00:00:00</h4>
                <button class="btn btn-success" onclick="start()">Iniciar</button>
                <button class="btn btn-danger" onclick="pause()">Pausar</button>
                <button class="btn btn-secondary" onclick="reset()">Resetar</button>
            </div>
        </div>

        <hr>

        <!-- Receita -->
        <div id="receita">
            <h2>Gerar Receita</h2>
            <form action="gerar_receita.php" method="POST">
                <div class="mb-3">
                    <label>Nome do Paciente</label>
                    <input type="text" name="paciente" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Medicamento</label>
                    <input type="text" name="medicamento" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Dosagem</label>
                    <input type="text" name="dosagem" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Instruções</label>
                    <textarea name="instrucoes" class="form-control" rows="3" required></textarea>
                </div>
                <button class="btn btn-primary" type="submit">Gerar PDF</button>
            </form>
        </div>

        <hr>

        <!-- Histórico -->
        <div id="historico">
            <h2>Histórico de Consultas</h2>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Paciente</th>
                        <th>Tempo</th>
                        <th>Motivo</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>20/05/2025</td>
                        <td>Maria Souza</td>
                        <td>20 min</td>
                        <td>Rotina</td>
                    </tr>
                    <tr>
                        <td>19/05/2025</td>
                        <td>José Lima</td>
                        <td>15 min</td>
                        <td>Check-up</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <hr>

        <!-- Pacientes -->
        <div id="pacientes">
            <h2>Pacientes</h2>
            <ul class="list-group">
                <li class="list-group-item">João Silva</li>
                <li class="list-group-item">Maria Souza</li>
                <li class="list-group-item">José Lima</li>
            </ul>
        </div>

        <hr>

        <!-- Configurações -->
        <div id="configuracoes">
            <h2>Configurações</h2>
            <p>Ajustes de perfil, notificações, preferências e informações do sistema.</p>
            <button class="btn btn-outline-danger">Sair</button>
        </div>

    </div>

    <!-- Scripts -->
    <script>
        let [horas, minutos, segundos] = [0, 0, 0];
        let timer = null;

        function cronometro() {
            segundos++;
            if (segundos == 60) {
                segundos = 0;
                minutos++;
                if (minutos == 60) {
                    minutos = 0;
                    horas++;
                }
            }
            document.getElementById('display').innerHTML = 
                (horas < 10 ? "0" + horas : horas) + ":" +
                (minutos < 10 ? "0" + minutos : minutos) + ":" +
                (segundos < 10 ? "0" + segundos : segundos);
        }

        function start() {
            if (timer !== null) return;
            timer = setInterval(cronometro, 1000);
        }

        function pause() {
            clearInterval(timer);
            timer = null;
        }

        function reset() {
            clearInterval(timer);
            timer = null;
            [horas, minutos, segundos] = [0, 0, 0];
            document.getElementById('display').innerHTML = "00:00:00";
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
