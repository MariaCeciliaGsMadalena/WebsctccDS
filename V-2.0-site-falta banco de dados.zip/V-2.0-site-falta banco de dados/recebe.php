<?php
// Ativa exibição de erros (útil para debug)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Função segura para limpar input
function limpar($campo) {
    return htmlspecialchars(trim($campo));
}

// Coleta e limpa os dados
$nome         = limpar($_POST['nome'] ?? 'Não informado');
$parentesco   = limpar($_POST['parentesco'] ?? 'Não informado');
$idade        = limpar($_POST['idade'] ?? 'Não informado');
$motivo       = limpar($_POST['motivo'] ?? 'Não informado');
$rg           = limpar($_POST['rg'] ?? 'Não informado');
$urgencia     = limpar($_POST['urgencia'] ?? 'Não informado');
$especialidades = $_POST['especialidades'] ?? [];

// Confirmação da página
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <title>Confirmação de Agendamento</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f4f8;
            padding: 30px;
            color: #1e293b;
        }
        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        h1 {
            text-align: center;
            color: #2563eb;
            margin-bottom: 20px;
        }
        .info {
            margin-bottom: 12px;
            padding: 12px;
            background-color: #f9fafb;
            border-left: 4px solid #3b82f6;
            border-radius: 5px;
        }
        .chave {
            font-size: 1.2em;
            font-weight: bold;
            color: #10b981;
            text-align: center;
            margin-top: 30px;
        }
        .btn {
            display: block;
            width: 100%;
            margin-top: 25px;
            padding: 12px;
            text-align: center;
            background-color: #3b82f6;
            color: white;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #2563eb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-calendar-check"></i> Agendamento Confirmado</h1>
        <img src="https://leismunicipais.com.br/img/cidades/sp/brodowski.png" alt="Imagem de Confirmação" width="100" height="
        100">
       
        <div class="info"><strong>Nome:</strong> <?= $nome ?></div>
        <div class="info"><strong>Parentesco:</strong> <?= $parentesco ?></div>
        <div class="info"><strong>Idade:</strong> <?= $idade ?></div>
        <div class="info"><strong>Motivo:</strong> <?= $motivo ?></div>
        <div class="info"><strong>RG:</strong> <?= $rg ?></div>
        <div class="info"><strong>Nível de Urgência:</strong> <?= $urgencia ?></div>
        <div class="info"><strong>Especialidades:</strong>
            <?= count($especialidades) > 0 ? htmlspecialchars(implode(", ", $especialidades)) : 'Nenhuma selecionada' ?>
        </div>
        <?php
            // Chave aleatória de 5 dígitos
            $chave = str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);
            echo "<div class='chave'>Comprovante Nº: $chave</div>";
        ?>
        <a href="index.html" class="btn"><i class="fas fa-arrow-left"></i> Voltar para o início</a>
        <a href="index.html" class="btn"></i> Gerar pdf</a>
    </div>
</body>
</html>
